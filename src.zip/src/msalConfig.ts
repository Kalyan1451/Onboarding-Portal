import axios from 'axios'
import { PublicClientApplication, type Configuration } from '@azure/msal-browser'
let msalInstance: PublicClientApplication | null = null
let proxyUrl: null
let requestObjForApi: null
let logoUrls: any = []
import { useProxyDataStore } from '@/stores/proxy-data'
import { createPinia } from 'pinia'
import piniaPluginPersistedState from 'pinia-plugin-persistedstate'
const pinia = createPinia()
pinia.use(piniaPluginPersistedState)
const proxyDataStore: any = useProxyDataStore(pinia)

async function initializeMSAL(): Promise<any> {
  // const proxyDataStore: any = useProxyDataStore(pinia);
  // if (!msalInstance) {
  const proxyurl = 'https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD/proxyurl'
  //  const proxyurl = "/ONBRD/proxyurl";
  return axios.get(proxyurl).then((res: any) => {
    console.log(res.data)
    // console.log(res.data.appConfig)
    const tokenReqData = res.data.appConfig
    // const msalConfig: any = {
    //   auth: {
    //     clientId: res.data.appConfig.appId,
    //     authority: res.data.appConfig.authority,
    //     // redirectUri: res.data.redirectUrl,
    //     redirectUri: "http://localhost:5173",
    //     postLogoutRedirectUri: '/' // Must be registered as a SPA redirectURI on your app registration
    //   },
    //   cache: {
    //     cacheLocation: 'localStorage',
    //   },
    // }

    // requestObjForApi = converStringIntoArray(res.data.appConfig.scopesForBackendApi)

    // // console.log('msalConfig', msalConfig)
    // msalInstance = new PublicClientApplication(msalConfig as Configuration)

    // initializMsalInstance();

    proxyUrl = res.data.proxyurl
    // console.log('proxyUrl config', proxyUrl);
    // console.log(msalInstance)
    // comment

    generateToken(tokenReqData, proxyUrl)

    const url = 'https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD'
    // const url = window.location.href;
    let domain = new URL(url)
    console.log('domain', domain)
    domain = domain.hostname
    const reqUrl = proxyUrl + '/v3/organization?dnsName=' + domain
    console.log('domain', domain)
    axios.get(reqUrl).then((res: any) => {
      // console.log("Res", res);
      const orgId = res.data.orgId
      const msalConfig: any = {
        auth: {
          clientId: res.data.azureDetails.appId,
          authority: res.data.azureDetails.authority,
          // edirectUri: tokenReqData.redirectUrl,
          redirectUri: 'http://localhost:5173',
          // redirectUri: window.location.href,
          // redirectUri: "https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD",
          // redirectUri: window.location.origin + window.location.pathname,
          postLogoutRedirectUri: '/' // Must be registered as a SPA redirectURI on your app registration
        },
        cache: {
          cacheLocation: 'sessionStorage'
        }
      }
      requestObjForApi = converStringIntoArray(res.data.azureDetails.scopesForBackendApi)
      msalInstance = new PublicClientApplication(msalConfig as Configuration)
      initializMsalInstance()
      localStorage.setItem('orgId', orgId)
      // logoUrls = '/assets/innova/loginLogo.png'; // res.data.imageDetails;
      logoUrls = res.data.imageDetails
      // proxyDataStore.$patch({logoUrls: logoUrls})
      proxyDataStore.setLogoData(logoUrls)
      console.log('logoUrls', logoUrls)
      // const loginLogo = logoUrls; // logoUrls.filter((el) => el.imageName == 'loginLogo');
      // console.log("loginLogo", loginLogo)
    })
  })

  function converStringIntoArray(arrayString: any) {
    arrayString = arrayString.replace(/'/g, '"')
    const parsedArray = JSON.parse(arrayString)
    return parsedArray
  }

  // const msalInstance = new PublicClientApplication(msalConfig as Configuration);
  // console.log(msalInstance);
}

async function initializMsalInstance() {
  msalInstance?.initialize()
}

async function generateToken(tokenReqData: any, proxyUrl: any) {
  // const reqObj: any = requestObjForApi;
  // msalInstance?.acquireTokenPopup(reqObj).then((res) => {
  //   console.log("Response", res);
  //   localStorage.setItem('jwtToken', res.accessToken);
  // })
  // https://ol-npsitonboardingproxyftr.innovasolutions.com:29001/ONBRDPROXY/token
  const tenant_id = tokenReqData?.authority.replace('https://login.microsoftonline.com/', '')
  console.log('tenant_id', tenant_id)
  const reqTokenUrl = proxyUrl + '/token'
  const reqObj = {
    grant_type: tokenReqData.grantType,
    client_id: tokenReqData.appId,
    client_secret: tokenReqData.clientSecretId,
    scope: tokenReqData.scopeBackendtoken,
    tenant_id: tenant_id
  }
  axios.post(reqTokenUrl, reqObj).then((res: any) => {
    // console.log('Response Token', res.data.access_token);
    sessionStorage.setItem('jwtToken', res.data.access_token)
  })
}

export { initializeMSAL, msalInstance, proxyUrl, requestObjForApi, logoUrls }

// export default class EnvironmentService {
//   msalConfigs: any = {};
//   constructor() { }
//   getMsalConfig(appConfig: any, redirectUrl: any) {
//     console.log(appConfig)
//     console.log(redirectUrl)
//     this.msalConfigs = {
//       msalConfig: {
//         auth: {
//           clientId: appConfig.appId,
//           authority: appConfig.authority,
//           redirectUri: redirectUrl,
//         },
//         cache: {
//           cacheLocation: 'localStorage',
//           storeAuthStateInCookie: true
//         }
//       },
//       graphConfig: {
//         graphMeEndpoint: appConfig.graphEndPoint
//       },
//       requestObj: {
//         scopes: this.converStringIntoArray(appConfig.scopes)
//       },
//       requestObjForApi: {
//         scopes: this.converStringIntoArray(appConfig.scopesForBackendApi)
//       }
//     };
//     sessionStorage.setItem('MsalConfigData', JSON.stringify(this.msalConfigs));
//     return this.msalConfigs;
//   }

//   converStringIntoArray(arrayString: any) {
//     arrayString = arrayString.replace(/'/g, '"');
//     const parsedArray = JSON.parse(arrayString);
//     return parsedArray;
//   }

// }
