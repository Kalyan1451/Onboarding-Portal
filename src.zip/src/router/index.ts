import { createRouter, createWebHashHistory } from 'vue-router'
import ResetPassword from '../components/ResetPassword.vue'
import { LOCAL_STORAGE_VARIABLES } from '@/shared/constant/local-storage-variables'
import CompleteonboardingDocuments from '../components/CompleteonboardingDocuments.vue'
import PendingonboardingDocuments from '../components/PendingonboardingDocuments.vue'

const router = createRouter({
  history: createWebHashHistory('/ONBRD/'),
  linkActiveClass: 'active',
  routes: [
    {
      path: '/ONBRD',
      redirect: '/login'
    },
    {
      path: '/',
      redirect: '/login'
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue')
    },

    {
      // :userTrackerId/:token
      path: '/reset-password/:userTrackerId/:token',
      name: 'reset-password',
      component: () => import('@/components/ResetPassword.vue')

      // component: ResetPassword
    },
    {
      path: '/change-password/:trackId',
      name: 'change-password',
      component: () => import('@/components/ResetPassword.vue')
    },
    {
      path: '/forgot-password',
      name: 'forgot-password',
      component: () => import('@/components/ResetPassword.vue')
    },

    {
      path: '/onb',
      component: () => import('@/views/ContentView.vue'),
      beforeEnter: routeGuard,
      children: [
        {
          path: 'create-template',
          name: 'create-template',
          component: () => import('@/components/CreateTemplate.vue')
        },
        {
          path: 'create-agreement',
          name: 'create-agreement',
          component: () => import('@/components/ConsultantDocumentUpload.vue')
        },
        {
          path: 'pending-documents',
          name: 'pending-documents',
          component: PendingonboardingDocuments,
          beforeEnter: routeGuard
        },
        {
          path: 'welcome-item',
          name: 'welcome-item',
          component: () => import('@/components/TheWelcome.vue')
          // beforeEnter: routeGuard
        },
        {
          path: 'complete-documents',
          name: 'complete-documents',
          component: CompleteonboardingDocuments,
          beforeEnter: routeGuard
        },
        {
          path: 'consultant-dashboard',
          name: 'consultant-dashboard',
          component: () => import('@/pages/ConsultantDashboard.vue'),
          beforeEnter: routeGuard
        },
        {
          path: 'onb-spl',
          name: 'onbspl',
          component: () => import('@/pages/OnboardingSpecialistDashboard.vue'),
          meta: {
            auth: true
          },
          props: true,
          beforeEnter: routeGuard
        },
        {
          path: 'my-profile',
          name: 'my-profile',
          component: () => import('@/pages/MyProfile.vue'),
          meta: {
            auth: true
          },
          props: true,

          beforeEnter: routeGuard
        },

        {
          path: 'my-profile-data/:id',
          name: 'my-profile-onb',
          component: () => import('@/pages/MyProfile.vue'),
          meta: {
            auth: true
          },
          props: true,

          beforeEnter: routeGuard
        },
        {
          path: 'initiate-info',
          name: 'initiate-info',
          component: () => import('@/pages/ConsultantInitiatoryInformation.vue'),
          beforeEnter: routeGuard
        },
        {
          path: 'submit-onboarding-docs',
          name: 'submit-onboarding-docs',
          component: () => import('@/pages/SubmitOnboardingDocument.vue'),
          beforeEnter: routeGuard
        }
      ]
    }
  ]
})
function routeGuard(to: any, from: any, next: any) {
  const userDetails = sessionStorage?.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) //sessionStorage?.getItem('userDetails')
  const userLoginId = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_ID) //sessionStorage.getItem('loggedInUserId')

  if (userDetails && !userLoginId) {
    // User is authenticated, allow access
    next()
  } else if (userLoginId) {
    next()
  } else {
    // User is not authenticated, redirect to login
    if (to.path == '/onb/onb-spl') {
      next('/login?userType=innovaTeam')
    } else {
      next('/login')
    }
  }
}

export default router
