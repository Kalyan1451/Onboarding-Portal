<script setup lang="ts"></script>
<template>
  <div class="Banner">
    <div class="welcomeBanner">
      <div class="welcomeMsg">
        <!-- <img class="innovaImg mt-2 ml-5" src="../assets/logo 1.png" /> -->
        <img class="innovaImg mt-2 ml-5" :src="getLogoPath(navLogoUrl)" />
        <div style="position: relative">
          <img class="aboveimg" src="../assets/images/new2.jpg" />
        </div>
        <div class="caption">
          <h2 class="msg">{{ $t('Welcome') }}</h2>
          <h1 class="username">{{ userName }}</h1>
          <p class="info">{{ $t('Welcome_Msg') }}</p>
        </div>
      </div>
    </div>
    <div class="container-welcome">
      <img class="welcomeimg" src="../assets/welcome3.png" />
      <p class="createProfile">{{ $t('boxWelcomeMsg') }} <br />{{ $t('createProfileMsg') }}</p>
      <button class="btn" @click="switchToDashboard">
        <span class="btn-msg">{{ $t('Start') }}<i class="pi pi-arrow-right init-arrow"></i></span>
      </button>
    </div>
  </div>
</template>
<script lang="ts">
import { FILE_PATH } from '../shared/constant/file-path'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import { useProxyDataStore } from '@/stores/proxy-data'
import { computed, ref } from 'vue'

export default {
  setup() {
    const proxyDataStore: any = useProxyDataStore()
    const logUrls = ref([])
    const loginLogo = ref(null)
    logUrls.value = proxyDataStore.getLogos
    // loginLogo.value = logUrls.value.filter((el: any) => el.imageName == 'loginLogo');
    // logUrls = proxyDataStore.logoUrls;
    // console.log("loginLogo", loginLogo.value);
    // console.log("getLogos", logUrls);
    const navLogoUrl = computed(() => proxyDataStore.$state.navLogo)
    return {
      proxyDataStore,
      logUrls,
      loginLogo,
      navLogoUrl
    }
  },
  data() {
    return {
      userName: ''
    }
  },
  mounted() {
    const uName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME)
    this.userName = uName
  },
  methods: {
    getLogoPath(img: string): string {
      const defaultLogoUrl: string = '/innova/navBarLogo.png'
      img = img ? img : defaultLogoUrl
      return img ? new URL(img, import.meta.url).href : ''
    },
    switchToDashboard() {
      this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
    }
  }
}
</script>

<style scoped></style>
