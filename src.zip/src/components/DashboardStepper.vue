<template>
  <div class="stepper">
    <div style="width: -webkit-fill-available" class="horizontal-stepper">
      <div
        :class="[
          activeStatus == 0
            ? 'activeStatusOne'
            : activeStatus == 1
              ? 'activeStatusTwo'
              : activeStatus == 2
                ? 'activeStatusThree'
                : null
        ]"
      >
        <Timeline :value="taskNames" layout="horizontal" align="top">
          <template #content="slotProps">
            <div class="timeline-text">{{ slotProps.item }}</div>
          </template>
        </Timeline>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import onbService from '../shared/services/OnbService'
export default {
  props: ['stepperItems', 'ConsultId'],
  data() {
    return {
      dashboardDetails: [],
      taskStatuses: [] as string[],
      taskNames: [] as string[],
      empId: '',
      activeStatus: -1 as number
    }
  },
  beforeCreate() {
    const userDetails = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = this.ConsultId ? this.ConsultId : userDetails.employeeId
    onbService
      .getDashboardData(this.empId)
      .then((res: any) => {
        console.log('res', res)

        this.dashboardDetails = res?.data?.data?.employeeTaskDetails
        this.dashboardDetails.forEach((item: any) => {
          this.taskStatuses.push(item.taskStatus.name)
          this.taskNames.push(item.task.taskName)
        })

        this.activeStatus = this.taskStatuses.lastIndexOf('Completed')
      })

      .catch((error: any) => {
        console.log(error)
      })
  }
}
</script>

<style lang="scss" scoped>
.stepper {
  display: flex;
  align-items: center;
  width: 100%;
  margin: 0 auto;
  justify-content: center;
  padding: 25px 0px 25px 90px;
  border-radius: 20px;
  background-color: #f1f8ff;
}
.horizontal-stepper {
  width: 100%;
}

.horizontal-stepper :deep {
  .p-timeline-event {
    .p-timeline-event-separator {
      .p-timeline-event-marker {
        height: 25px;
        width: 25px;
      }
    }
  }

  .activeStatusOne {
    .p-timeline-event:first-child {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          background-color: rgb(4, 195, 135);
          border-color: rgb(4, 195, 135);
        }
      }
    }

    .p-timeline-event:nth-child(2) {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          background-color: coral;
          border-color: coral;
        }
      }
    }
  }

  .activeStatusTwo {
    .p-timeline-event:first-child,
    .p-timeline-event:nth-child(2) {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          background-color: rgb(4, 195, 135);
          border-color: rgb(4, 195, 135);
        }
      }
    }

    .p-timeline-event:last-child {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          background-color: coral;
          border-color: coral;
        }
      }
    }
  }

  .activeStatusThree {
    .p-timeline-event:first-child,
    .p-timeline-event:nth-child(2),
    .p-timeline-event:last-child {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          background-color: rgb(4, 195, 135);
          border-color: rgb(4, 195, 135);
        }
      }
    }
  }

  @media only screen and (max-width: 750px) {
    .timeline-text:first-child {
      width: 100px;
      margin-left: -30px;
      display: flex;
      flex-direction: row;
      font-size: 10px;
    }

    .p-timeline-event {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          height: 20px;
          width: 20px;
        }
      }
    }
  }

  @media only screen and (max-width: 520px) {
    .timeline-text:first-child {
      width: 50px;
      margin-left: -15px;
      display: flex;
      flex-direction: row;
      font-size: 10px;
    }

    .p-timeline-event {
      .p-timeline-event-separator {
        .p-timeline-event-marker {
          height: 15px;
          width: 15px;
        }
      }
    }
  }
}

@media only screen and (max-width: 750px) {
  .timeline-text:first-child {
    width: 100px;
    margin-left: -30px;
    display: flex;
    flex-direction: row;
    font-size: 10px;
  }

  .stepper {
    padding: 25px 0px 25px 35px;
  }

  .p-timeline-event {
    .p-timeline-event-separator {
      .p-timeline-event-marker {
        height: 20px;
        width: 20px;
      }
    }
  }
}

@media only screen and (max-width: 520px) {
  .stepper {
    padding: 25px 10px 25px 30px;
  }
}

.timeline-text {
  width: 200px;
  margin: 20px 0 0 -85px;
  display: flex;
  flex-direction: column;
  color: #144684;
  font-size: 15px;
}

.stepper :deep {
  .p-timeline {
    flex-direction: row;
  }

  .p-timeline.p-timeline-horizontal .p-timeline-event-opposite,
  .p-timeline.p-timeline-horizontal .p-timeline-event-content {
    padding: 0px;
  }

  .p-timeline-event-separator {
    flex-direction: row;
  }

  .p-timeline.p-timeline-horizontal {
    .p-timeline-event-connector {
      background-color: #0070cd;
    }
  }

  .p-timeline .p-timeline-event-marker {
    border-color: #ddd;
    background-color: #ddd;
  }
}
</style>
