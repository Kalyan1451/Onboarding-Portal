import moment from 'moment'

export class globalUtilfunction {
  getCurrentDateTimeByUTC(utcTime: string) {
    return moment.utc(utcTime).local().format('MM/DD/YYYY HH:mm:ss')
  }
}
