export const ErrorMessages = {
  mandatory: 'Please fill mandatory field',
  startDateErrorMsg: 'From date can not be after to date',
  passwordmatched: 'New password and Confirm new password doesn’t match.',
  zipValidationMsg: 'Please fill mandatory field without characters'
}
