<template>
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <div class="chart-container">
    <div class="chart">
      <h2 style="text-align: left" class="text-above-taskstable">{{ $t('viewOnboardingDoc') }}</h2>
      <DataTable
        :value="taskNameArr"
        scrollable
        scrollHeight="400px"
        tableStyle="width: 100%"
        class="data-table candidate-dashboard-table"
      >
        <Column>
          <template #body="slotProps">
            <!-- {{ this.taskNameArr[slotProps.index].taskName }} -->
            <i class="pi pi-check-circle"></i>
            {{ this.taskNameArr[slotProps.index] }}
          </template>
        </Column>
        <Column :frozen="true" :style="{ width: '30%' }">
          <template #body>
            <!-- <Button :label="$t('edit')" @click="handleStarClick(slotProps)"></Button> -->
            <i class="pi pi-eye eyeicon" :title="$t('viewDetails')" data-placement="top" />
          </template>
        </Column>
      </DataTable>
      <p v-if="taskNameArr.length === 0">No Records Found</p>
    </div>
  </div>
</template>

<script lang="ts">
import onbService from '@/shared/services/OnbService'

export default {
  data() {
    return {
      showSpinner: false,
      empId: '',
      taskNameArr: [],
      taskStatus: []
    }
  },
  methods: {
    handleStarClick(index: any) {
      let taskName
      if (index.data.taskName) {
        taskName = index.data.taskName //If it is complete Profile the it will assign
      } else {
        taskName = index.data.templateName //If it is not complete profile it will assign corresponding document name
      }
      onbService
        .startTaskRemainderEmail(this.loggedEmpId, taskName)
        .finally(() => {
          setTimeout(() => {}, 1000)
        })
        .catch((error) => {
          console.error(error)
        })
      if (index.data.templateId || index.data.taskName == 'Pending Onboarding Documents') {
        this.$router.push('/onb/initiate-info')
      }
      if (index.data.taskName == 'Complete Profile') {
        this.$router.push('/onb/my-profile')
      }
    }
  },
  mounted() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    this.showSpinner = true
    onbService
      .getOnboardingDocuments(this.empId)
      .then((res: any) => {
        const arr = res.data.data
          .map((item, index) => {
            return item.employeeDocumentsList
          })
          .map((res: any, index: any) => {
            res.map((doc: any, index: any) => {
              if (doc?.statusId == 4) {
                this.taskNameArr.push(doc.templatePackage.template.templateName)
              }
            })
            console.log(this.taskNameArr)
          })
        //this.taskNameArr=this.sortedArray(this.taskNameArr);
      })
      .finally(() => {
        setTimeout(() => {
          this.showSpinner = false
        }, 1000)
      })
      .catch((error) => {
        this.showSpinner = false
        //console.error('There was an error!', error);
      })
  }
}
</script>

<style scoped lang="scss">
.pi-eye {
  cursor: not-allowed;
}
.pi-check-circle {
  font-weight: bold;
  color: green;
  margin-right: 5px;
}
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}
.text-above-taskstable {
  font-weight: 400;
  color: #000000;
  font-size: 20px;
  letter-spacing: 0.2px;
  // line-height: 50px;
}

.candidate-dashboard-table :deep {
  .p-datatable-thead {
    display: none;
  }
}
</style>
