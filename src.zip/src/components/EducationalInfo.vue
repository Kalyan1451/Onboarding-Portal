<template>
  <Toast />
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <Panel :header="$t('educationInformation')">
    <div v-for="(item, index) in forms" :key="index">
      <form>
        <div v-if="item.isDeleted != 'Y'">
          <Fieldset :legend="$t('educationLabel')">
            <div class="grid p-fluid">
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorSchool ? 'error' : 'valid'"
                  >{{ $t('schoolUniversity') }}<span class="text-danger">*</span></label
                >
                <InputText
                  :class="item.errorSchool ? 'error' : 'valid'"
                  @input="validateSchool(item)"
                  type="text"
                  v-model="item.universityName"
                  :disabled="disableField"
                />
                <small v-if="item.errorSchool" class="error">{{ item.errorSchool }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorDegree ? 'error' : 'valid'"
                  >{{ $t('degree') }}<span class="text-danger">*</span></label
                >
                <InputText
                  type="text"
                  :class="item.errorDegree ? 'error' : 'valid'"
                  v-model="item.educationType"
                  @input="validateDegree(item)"
                  :disabled="disableField"
                />
                <small v-if="item.errorDegree" class="error">{{ item.errorDegree }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorCountry ? 'error' : 'valid'"
                  >{{ $t('country') }}<span class="text-danger">*</span></label
                >
                <Dropdown
                  :options="countryList"
                  optionLabel="name"
                  optionValue="countryId"
                  :placeholder="$t('selectCountry')"
                  v-model="item.countryId"
                  @change="
                    getState(item.countryId, index)
                    validateCountry(item)
                  "
                  :class="item.errorCountry ? 'error' : 'valid'"
                  :disabled="disableField"
                />
                <small v-if="item.errorCountry" class="error">{{ item.errorCountry }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorState ? 'error' : 'valid'"
                  >{{ $t('state') }}<span class="text-danger">*</span></label
                >
                <Dropdown
                  :options="stateList[index]"
                  optionLabel="name"
                  optionValue="stateId"
                  :placeholder="$t('selectState')"
                  :class="item.errorState ? 'error' : 'valid'"
                  v-model="item.stateId"
                  :disabled="disableField"
                  @change="validateState(item)"
                />
                <small :class="item.errorState ? 'error' : 'valid'">{{ item.errorState }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorCity ? 'error' : 'valid'"
                  >{{ $t('city') }}<span class="text-danger">*</span></label
                >
                <InputText
                  :class="item.errorCity ? 'error' : 'valid'"
                  :maxlength="50"
                  type="text"
                  v-model="item.city"
                  @input="validateCity(item)"
                  :disabled="disableField"
                />
                <small v-if="item.errorCity" class="error">{{ item.errorCity }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label :class="item.errorZip ? 'error' : 'valid'"
                  >{{ $t('zip') }}<span class="text-danger">*</span></label
                >
                <InputText
                  :class="item.errorZip ? 'error' : 'valid'"
                  :maxlength="6"
                  type="text"
                  v-model="item.zipCode"
                  @input="validateZip(item)"
                  :disabled="disableField"
                />
                <small v-if="item.errorZip" class="error">{{ item.errorZip }}</small>
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label>{{ $t('from') }}</label>
                <Calendar
                  :maxDate="maxDate"
                  view="year"
                  dateFormat="yy"
                  showIcon
                  v-model="item.startDate"
                  :disabled="disableField"
                />
              </div>
              <div class="field col-12 md:col-4 lg:col-4 mb-0">
                <label>{{ $t('to') }}</label>
                <Calendar
                  :maxDate="maxDate"
                  view="year"
                  dateFormat="yy"
                  showIcon
                  v-model="item.endDate"
                  :disabled="disableField"
                />
              </div>
            </div>
            <div class="remove-form" v-if="!disableField && !isConsultantInfoPage">
              <span>
                <Button
                  icon="pi pi-fw pi-plus"
                  :label="$t('add')"
                  tooltipPosition="left"
                  @click="addForm"
                />
              </span>
              <span>
                <Button
                  icon="pi pi-fw pi-trash"
                  :label="$t('delete')"
                  severity="danger"
                  pTooltip="Remove Education details"
                  tooltipPosition="left"
                  class="btn"
                  @click="removeData(index)"
                />
              </span>
            </div>
          </Fieldset>
        </div>
      </form>
    </div>
  </Panel>
  <div
    style="display: flex; justify-content: flex-end; column-gap: 10px; margin-top: 15px"
    v-if="!disableField && !isConsultantInfoPage"
  >
    <Button :label="$t('previous')" @click="goToPrevious" />
    <Button :label="$t('saveAndExit')" @click="saveEducationalData" />
    <Button :label="$t('next')" @click="saveEducationalData('next')" />
  </div>
</template>
<script lang="ts">
import { reactive } from 'vue'
import { ErrorMessages } from '../shared/constant/error-messages-constants'
import OnbService from '../shared/services/OnbService'
import { useToast } from 'primevue/usetoast'
import moment from 'moment'
import { GLOBAL_ENUM } from '../shared/enum/global.enum'
import { CONSULTANT_CONST_INFO } from '../shared/constant/consultant_const_info'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import { FILE_PATH } from '../shared/constant/file-path'
export default {
  props: {
    disableField: Boolean,
    ConsultId: Number
  },
  inject: ['isConsultantInfoPage'],
  data() {
    return {
      empId: '',
      employeeId: '',
      showErrorToDate: false,
      showErrorFromDate: false,
      isZipValid: false,
      errorMsg: ErrorMessages,
      maxDate: new Date(new Date().getFullYear(), 0, 1),
      toDateMin: moment(new Date()).format('YY'),
      forms: reactive([]),
      defaultEducation: {
        createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
        createdDate: '11/20/2023',
        employeeId: this.empId ? this.empId : this.employeeId,
        universityName: '',
        educationType: '',
        employeeEducationId: '',
        countryId: '',
        city: '',
        stateId: '',
        zipCode: '',
        startDate: '',
        endDate: '',
        yearOfPass: GLOBAL_ENUM.DEFAULT_YEAR_OF_PASS, //'2015',
        externalId: null,
        gardePercentage: GLOBAL_ENUM.DEFAULT_GRADE_PERCENTAGE, //70,
        isActive: CONSULTANT_CONST_INFO.YES, //'Y',
        isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
        modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, //1,
        modifiedDate: null,
        organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
        ownerId: null,
        errorSchool: '',
        errorDegree: '',
        errorCity: '',
        errorZip: '',
        errorCountry: '',
        errorState: ''
      },
      keysToRemove: [
        'errorSchool',
        'errorDegree',
        'errorCity',
        'errorZip',
        'errorCountry',
        'errorState'
      ],
      showSpinner: false,
      excuseDeletedEducationForm: false,
      toast: useToast(),
      personalSubTaskObj: {},
      WorkExperienceSubTaskObj: {},
      previewSubTaskObj: {},
      completeProfileSubTaskObj: {},
      createProfileObj: {},
      educationalSubTaskObj: {},
      subTaskPercentage: '',
      school: '',
      degree: '',
      country: '',
      city: '',
      state: '',
      zip: '',
      from: '',
      to: '',
      countryList: [],
      stateList: [],
      status: [],
      isSchoolInvalid: false,
      isDegreeInvalid: false,
      isCountryInvalid: false,
      isCityInvalid: false,
      isStateInvalid: false,
      isZipInvalid: false,
      workHistoryData: [],
      employeeAllData: {
        city: '',
        dateOfBirth: '',
        email: '',
        genderId: '',
        stateId: '',
        countryId: '',
        county: '',
        firstName: '',
        middleName: '',
        lastName: '',
        ssn: '',
        address1: '',
        address2: '',
        preferredName: '',
        zipcode: '',
        preferredLanguageId: '',
        preferredContactMethodId: '',
        phone2: '',
        phone: '',
        progress: '',
        ssnReason: '',
        emergencyPersonName: '',
        emergencyContactNumber: ''
      }
    }
  },
  watch: {
    forms(newValue) {
      this.$emit('updatedEducation', newValue)
    },
    isZipValid(newValue) {
      this.$emit('isZipValid', newValue)
    }
  },

  beforeCreate() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.employeeId = userDetails.employeeId
  },

  mounted() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.empId = userDetails.employeeId
    this.employeeId = userDetails.employeeId
    OnbService.getStatus().then((response: any) => {
      this.status = response.data.data[1].status
    })
    OnbService.getCountryList().then((response: any) => {
      this.countryList = response.data.data
    })

    if (this.ConsultId) {
      OnbService.getEmployeeData(this.ConsultId).then((response: any) => {
        this.forms = response.data.data.educationDetails
        if (this.forms == null || this.forms.length == 0) {
          this.forms.push(this.defaultEducation)
        }
        this.forms.map((a) =>
          a.startDate != null && a.startDate != '' ? moment(a.startDate).format('YY') : ''
        )
        this.forms.map((a) =>
          a.endDate != null && a.endDate != '' ? moment(a.endDate).format('YY') : ''
        )
      })
    }

    if (!this.ConsultId) {
      this.showSpinner = true
      OnbService.getEmployeeData(this.empId)
        .then((response: any) => {
          this.employeeAllData = response.data.data
          this.forms = response.data.data.educationDetails
          if (this.forms == null || this.forms.length == 0) {
            this.forms.push(this.defaultEducation)
          }
          this.forms.map((a) =>
            a.startDate != null && a.startDate != '' ? moment(a.startDate).format('YY') : ''
          )
          this.forms.map((a) =>
            a.endDate != null && a.endDate != '' ? moment(a.endDate).format('YY') : ''
          )
          const myProfileInfoTaskObj = response.data.data.employeeTaskDetails[1]
          this.createProfileObj = myProfileInfoTaskObj.taskStatus
          this.personalSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[0].taskStatus
          this.educationalSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[1].taskStatus
          this.WorkExperienceSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[2].taskStatus
          this.previewSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[3].taskStatus
          this.completeProfileSubTaskObj =
            myProfileInfoTaskObj.subTask.subEmployeeTask[4].taskStatus
          this.subTaskPercentage = myProfileInfoTaskObj.subTask.percentage
          this.workHistoryData = response.data.data.employeeWorkHistory
          this.forms.forEach((res: any, indexForms: any) => {
            response.data.data.educationDetails.map((a: any, index: any) => {
              if (res.countryId == a.countryId && indexForms == index) {
                res.countryId = a.countryId
                this.getState(a.countryId, index)
                res.stateId = a.stateId
              }
            })
          })
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    }
  },

  methods: {
    validateSchool(field: any) {
      !field.universityName
        ? (field.errorSchool = this.$t('ErrorMessages.mandatory'))
        : (field.errorSchool = '')
    },
    validateDegree(field: any) {
      !field.educationType
        ? (field.errorDegree = this.$t('ErrorMessages.mandatory'))
        : (field.errorDegree = '')
    },
    validateCity(field: any) {
      !field.city ? (field.errorCity = this.$t('ErrorMessages.mandatory')) : (field.errorCity = '')
    },
    validateZip(field: any) {
      if (field.zipCode !== '' && field.zipCode != null) {
        if (!this.isNumber(field.zipCode)) {
          this.isZipValid = true
          field.errorZip = this.$t('ErrorMessages.zipValidationMsg')
        } else {
          field.errorZip = ''
        }
      } else {
        field.errorZip = this.$t('ErrorMessages.mandatory')
      }
    },
    isNumber(value?: string | number): boolean {
      return !isNaN(Number(value.toString()))
    },
    validateState(field: any) {
      !field.stateId ? (field.errorZip = this.$t('ErrorMessages.mandatory')) : (field.errorZip = '')
    },
    validateCountry(field: any) {
      !field.countryId
        ? (field.errorCountry = this.$t('ErrorMessages.mandatory'))
        : (field.errorCountry = '')
    },
    validFromTo() {
      let flag = false
      for (let i = 0; i < this.forms.length; i++) {
        if (this.forms[i].startDate > this.forms[i].endDate) {
          flag = true
        }
      }
      if (flag) {
        this.showErrorFromDate = true
        this.toast.add({
          severity: 'error',
          summary: 'error',
          detail: this.errorMsg.startDateErrorMsg,
          life: 3000
        })
      } else {
        this.showErrorFromDate = false
      }
    },
    addForm() {
      let formsArr = []
      this.forms.filter((item: any) => {
        if (item.isDeleted != CONSULTANT_CONST_INFO.YES) {
          //'Y'
          formsArr.push(item)
        }
      })
      if (formsArr.length < 5) {
        this.forms.push({
          createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
          createdDate: '11/20/2023',
          employeeId: this.empId ? this.empId : this.employeeId,
          universityName: '',
          educationType: '',
          employeeEducationId: '',
          countryId: '',
          city: '',
          stateId: '',
          zipCode: '',
          startDate: '',
          endDate: '',
          yearOfPass: GLOBAL_ENUM.DEFAULT_YEAR_OF_PASS, //'2015',
          externalId: null,
          gardePercentage: GLOBAL_ENUM.DEFAULT_GRADE_PERCENTAGE, //70,
          isActive: CONSULTANT_CONST_INFO.YES, //'Y',
          isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
          modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, //1,
          modifiedDate: null,
          organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
          ownerId: null,
          errorSchool: '',
          errorDegree: '',
          errorCity: '',
          errorZip: '',
          errorCountry: '',
          errorState: ''
        })
      }
    },
    removeData(index: any) {
      let formsArr = []
      this.forms.filter((item: any) => {
        if (item.isDeleted != CONSULTANT_CONST_INFO.YES) {
          //'Y'
          formsArr.push(item)
        }
      })
      if (formsArr.length > 1) {
        ;(this.forms[index].isActive = CONSULTANT_CONST_INFO.NO), //'N'
          (this.forms[index].isDeleted = CONSULTANT_CONST_INFO.YES) //'Y'
      }
    },
    getState(countryId: any, index?: any) {
      let stList: any = this.countryList.filter((res: any) => {
        return res.countryId == countryId
      })
      this.stateList[index] = stList[0]?.state
    },
    getStatus() {
      let openStatusObj = this.status[0] //---> open status
      let completeStatusObj = this.status[3] //---> complete status
      let progressStatusObj = this.status[1] //---> progress status
      let submittedObj = this.status[2] //---> submitted status
      if (this.city && this.school && this.degree && this.zip && this.state && this.country) {
        return completeStatusObj
      }
      if (this.city || this.school || this.degree || this.zip || this.state || this.country) {
        return progressStatusObj
      } else {
        return openStatusObj
      }
    },
    getSignupStatus() {
      let completeStatusObj = this.status[3] //---> complete status
      return completeStatusObj
    },
    goToPrevious() {
      this.$emit('backToPersonalInfo', 'personal-info')
    },
    saveEducationalData(getNext?: any) {
      this.isZipValid = false
      this.forms.map((a) => {
        if (a.startDate != null && a.startDate != '') {
          let date = new Date(a.startDate)
          let dateMDY = `${date.getFullYear()}`
          a.startDate = dateMDY
        } else {
          a.startDate = ''
        }
      })
      this.forms.map((a) => {
        if (a.endDate != null && a.endDate != '') {
          let date = new Date(a.endDate)
          let dateMDY = `${date.getFullYear()}`
          a.endDate = dateMDY
        } else {
          a.endDate = ''
        }
      })
      if (getNext == CONSULTANT_CONST_INFO.GET_NEXT) {
        this.validFromTo()
      }

      const invalidEdutype = this.forms.filter((item: any) => {
        if (getNext == CONSULTANT_CONST_INFO.GET_NEXT) {
          this.validateSchool(item)
          this.validateCountry(item)
          this.validateState(item)
          this.validateCity(item)
          this.validateZip(item)
          this.validateDegree(item)
        }
        return (
          (item.educationType == '' ||
            item.educationType == null ||
            item.universityName == '' ||
            item.universityName == null ||
            item.countryId == '' ||
            item.countryId == null ||
            item.city == '' ||
            item.city == null ||
            item.stateId == '' ||
            item.stateId == null ||
            item.zipCode == '' ||
            item.zipCode == null) &&
          item.isDeleted == CONSULTANT_CONST_INFO.NO //'N'
        )
      })

      const { keysToRemove, forms } = this
      const modifiedArray = forms.map((obj) => {
        const newObj = Object.fromEntries(
          Object.entries(obj).filter(([key]) => !keysToRemove.includes(key))
        )
        return newObj
      })
      if (
        (invalidEdutype.length <= 0 && !this.isZipValid && !this.showErrorFromDate) ||
        getNext != CONSULTANT_CONST_INFO.GET_NEXT
      ) {
        this.showSpinner = true
        let payload = {
          employeeId: this.employeeId,
          ownerId: 1,
          createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
          modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, //1,
          dateOfBirth:
            this.employeeAllData.dateOfBirth != null && this.employeeAllData.dateOfBirth != ''
              ? moment(this.employeeAllData.dateOfBirth).format('MM/DD/YYYY')
              : '',
          departmentId: null,
          locationId: null,
          organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
          genderId: this.employeeAllData.genderId,
          stateId: this.employeeAllData.stateId,
          countryId: this.employeeAllData.countryId,
          county: this.employeeAllData.county,
          secondaryStateId: null,
          secondaryCountryId: null,
          createdDate: '11/16/2023 23:58:46.000',
          modifiedDate: '11/22/2023 23:58:46.000',
          isActive: CONSULTANT_CONST_INFO.YES, //'Y',
          isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
          secondaryAddress1: null,
          secondaryAddress2: null,
          firstName: this.employeeAllData.firstName,
          middleName: this.employeeAllData.middleName,
          lastName: this.employeeAllData.lastName,
          ssn: this.employeeAllData.ssn,
          email: this.employeeAllData.email,
          email1: null,
          address1: this.employeeAllData.address1,
          address2: this.employeeAllData.address2,
          externalId: null,
          preferredName: this.employeeAllData.preferredName,
          phone: this.employeeAllData.phone,
          phone2: this.employeeAllData.phone2,
          ssnReason: this.employeeAllData.ssnReason,
          emergencyPersonName: this.employeeAllData.emergencyPersonName,
          emergencyContactNumber: this.employeeAllData.emergencyContactNumber,
          city: this.employeeAllData.city,
          zipcode: this.employeeAllData.zipcode,
          scondaryZipcode: null,
          preferredLanguageId: this.employeeAllData.preferredLanguageId,
          preferredContactMethodId: this.employeeAllData.preferredContactMethodId,
          educationDetails: modifiedArray,
          employeeWorkHistory: this.workHistoryData,
          employeeTaskDetails: [
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[0].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[0].employeeTaskId
                : '',
              employeeId: this.employeeId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
              task: {
                taskId: GLOBAL_ENUM.TASK_ONE_ID, //1,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, //1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:40:51.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.CONSULTANT_SIGNUP, //'Consultant Signup',
                externalId: null,
                subTask: null
              },
              taskStatus: this.getSignupStatus(),
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, //1,
              createdDate: '11/17/2023 00:02:37.000',
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, //'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[1].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[1].employeeTaskId
                : '',
              employeeId: this.employeeId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
              task: {
                taskId: GLOBAL_ENUM.TASK_TWO_ID, //2,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:40:52.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.CREATE_PROFILE, //'Create Profile',
                externalId: null,
                subTask: null
              },
              taskStatus: this.createProfileObj,
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/17/2023 00:03:22.000',
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, //'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
              comments: null,
              externalId: null,
              subTask: {
                percentage: this.subTaskPercentage,
                subEmployeeTask: [
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[0].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[0]
                          .employeeTaskId
                      : '',
                    employeeId: this.employeeId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_SIX_ID, // 6,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                      createdDate: '11/16/2023 21:41:18.000',
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                      taskName: CONSULTANT_CONST_INFO.PERSONAL_INFO, //'Personal Information',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.personalSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/17/2023 00:03:27.000',
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[1].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[1]
                          .employeeTaskId
                      : '',
                    employeeId: this.employeeId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_SEVEN_ID, // 7,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                      createdDate: '11/16/2023 21:41:20.000',
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                      taskName: CONSULTANT_CONST_INFO.EDUCATION, //'Education',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus:
                      getNext == CONSULTANT_CONST_INFO.GET_NEXT
                        ? this.status[3]
                        : this.educationalSubTaskObj
                          ? this.educationalSubTaskObj
                          : this.status[1],
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/17/2023 00:03:28.000',
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[2].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[2]
                          .employeeTaskId
                      : '',
                    employeeId: this.employeeId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_EIGHT_ID, // 8,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                      createdDate: '11/16/2023 21:41:21.000',
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                      taskName: CONSULTANT_CONST_INFO.WORK_EXPERIENCE, //'Work Experience',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.WorkExperienceSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/17/2023 00:03:30.000',
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[3].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[3]
                          .employeeTaskId
                      : '',
                    employeeId: this.employeeId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_NINE_ID, // 9,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                      createdDate: '11/16/2023 21:41:22.000',
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                      taskName: CONSULTANT_CONST_INFO.PREVIEW, //'Preview',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.previewSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/17/2023 00:03:31.000',
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[4].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[4]
                          .employeeTaskId
                      : '',
                    employeeId: this.employeeId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_TEN_ID, // 10,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                      createdDate: '11/16/2023 21:41:24.000',
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                      taskName: CONSULTANT_CONST_INFO.COMPLETE_PROFILE, //'Complete Profile',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.completeProfileSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/17/2023 00:03:34.000',
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  }
                ]
              }
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[2].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[2].employeeTaskId
                : '',
              employeeId: this.employeeId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
              task: {
                taskId: GLOBAL_ENUM.TASK_THREE_ID, // 3,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:40:54.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.INITIATE_ONB_STEPS, //'Initiate Onboarding Steps',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, // 2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN //'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/17/2023 00:03:24.000',
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, //'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[3].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[3].employeeTaskId
                : '',
              employeeId: this.employeeId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
              task: {
                taskId: GLOBAL_ENUM.TASK_FOUR_ID, // 4,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:40:56.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.SUBMIT_ONB_DOCUMENTS, //'Submit Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, //2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN //'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/17/2023 00:03:25.000',
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, //'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[4].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[4].employeeTaskId
                : '',
              employeeId: this.employeeId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
              task: {
                taskId: GLOBAL_ENUM.TASK_FIVE_ID, // 5,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:40:58.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.ONB_APPROVED, //'Onboarding Approved',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, //1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, // 2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, //1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN //'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, //1,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/17/2023 00:03:26.000',
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, //'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
              comments: null,
              externalId: null,
              subTask: null
            }
          ],
          user: null,
          progress: this.employeeAllData.progress
        }
        //let url = 'https://ol-npqaonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/employee/save';
        OnbService.employeeSave(payload)
          .then((response: any) => {
            this.subTaskPercentage =
              response.data.data.data.employeeTaskDetails[1].subTask.percentage
            this.$emit('subTaskPercentageEducation', this.subTaskPercentage)
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.educationalInfoUpdated'),
              life: 2000
            })
            setTimeout(() => {
              if (response.data.data && getNext != CONSULTANT_CONST_INFO.GET_NEXT) {
                this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD) //'/onb/consultant-dashboard'
              }
              if (response.data.data && getNext == CONSULTANT_CONST_INFO.GET_NEXT) {
                this.$emit('navigateToWorkExp', 'work-info')
                this.emitter.emit('setWorkExpTabActive', { eventContent: 'workExp-active' })
                this.$emit('completeEducation', 2)
              }
            }, 2000)
          })
          .finally(() => {
            setTimeout(() => {
              this.showSpinner = false
            }, 1000)
          })
          .catch((error) => {
            this.showSpinner = false
            console.error(error.message)
          })
      }
    }
  }
}
</script>
<style scoped>
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.error {
  color: red;
  border-color: red;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

.p-invalid {
  border-color: red;
  color: red;
}

.remove-form {
  display: flex;
  justify-content: flex-end;
  position: relative;
  bottom: 6px;
  margin-top: 10px;
  column-gap: 15px;
}

.add-form {
  display: flex;
  justify-content: flex-end;
  position: relative;
  bottom: 4px;
  right: 30px;
}
@media (max-width: 550px) {
  .add-form {
    margin-right: -18rem;
  }
}

.btn {
  background-color: red;
  border: none;
  /* padding: 7px 5px; */
}
</style>
