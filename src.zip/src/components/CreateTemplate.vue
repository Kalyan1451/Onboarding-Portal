<template>
  <Toast />
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <Panel :header="$t('createTemplate')">
    <form>
      <div class="grid p-fluid">
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <label>{{ $t('uploadDoc') }}</label>
          <input type="file" @change="customBase64Uploader($event)" />
        </div>
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <label>{{ $t('DocName') }}</label>
          <InputText type="text" v-model="docName" />
        </div>
        <div class="clearfix"></div>
        <div class="field col-12 md:col-4 lg:col-4 mb-0">
          <label>{{ $t('addCustomeFields') }}</label
          >&nbsp;&nbsp;
          <Button icon="pi pi-fw pi-plus" @click="addForm" />
        </div>
      </div>
      <div class="grid p-fluid" v-for="(item, index) in forms">
        <!-- <i  class="pi pi-circle-fill"></i> -->
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <label>{{ $t('labelName') }}</label>
          <InputText type="text" v-model="item.question" />
        </div>
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <label>{{ $t('fieldName') }}</label>
          <InputText type="text" v-model="item.fieldName" />
        </div>
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <label>{{ $t('fieldType') }}</label>
          <Dropdown
            :options="filedtypeOptions"
            optionLabel="label"
            optionValue="value"
            v-model="item.fieldType"
            @change="getFieldType(item.fieldType)"
            placeholder="Select"
          ></Dropdown>
        </div>
        <div class="field flex align-items-center flex-column col-2 md:col-2 lg:col-1 mb-0">
          <label>{{ $t('mandatory') }}</label>
          <InputSwitch v-model="item.mandatory" />
        </div>
        <Button class="trashRow" icon="pi pi-trash" @click="deleteRow(index)" />
      </div>
      <div class="grid p-fluid" v-if="showCheckBoxField">
        <div class="field col-12 md:col-4 lg:col-3 mb-0" v-for="(item, index) in optionsForm">
          <label>{{ $t('options') }}</label>
          <InputText type="text" v-model="item.appFieldName" />
          <Button class="trash" icon="pi pi-trash" @click="deleteOptions(index)" />
        </div>
        <div class="clearfix"></div>
        <div class="field col-12 md:col-4 lg:col-3 mb-0">
          <Button icon="pi pi-fw pi-plus" label="Add Options" @click="addOptions" />
        </div>
      </div>
      <br />
      <Button
        class="creatbtn"
        v-if="showSubmit"
        :label="$t('createTemplate')"
        @click="showTemplate"
      />
    </form>
  </Panel>
  <Divider></Divider>
  <DataTable
    :value="templateListArr"
    showGridlines
    tableStyle="width: 100%"
    class="data-table"
    :rows="10"
    :rowsPerPageOptions="[5, 10, 25, 50]"
    removableSort
    :emptyMessage="'No records found'"
    paginatorTemplate=" FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink RowsPerPageDropdown"
    currentPageReportTemplate="{first} to {last} of {totalRecords}"
    :totalRecords="templateListArr.length"
  >
    <Column :header="$t('tempName')">
      <template #body="slotProps">
        {{ this.templateListArr[slotProps.index].templateName }}
      </template>
    </Column>
    <Column :header="$t('tempCreateDate')" :frozen="true" :style="{ width: '30%' }">
      <template #body="slotProps">
        {{ this.templateListArr[slotProps.index].createdDate }}
        <!-- <Button class="btn">Edit</Button> .split(' ')[0] -->
      </template>
    </Column>
  </DataTable>
</template>
<script lang="ts">
import { useToast } from 'primevue/usetoast'
import { reactive } from 'vue'
import OnbService from '../shared/services/OnbService'
export default {
  data() {
    return {
      toast: useToast(),
      showCheckBoxField: false,
      fileName: '',
      filedtypeOptions: [
        { label: 'Text', value: 'text' },
        { label: 'Checkbox', value: 'checkbox' }
      ],
      docName: '',
      forms: reactive([]),
      optionsForm: reactive([]),
      flowMsg: '',
      client: new HelloSign({
        clientId: '1c3b71bf90f213797a51e29bd4a1b25a',
        skipDomainVerification: true,
        testMode: true,
        allowCancel: false
      }),
      showSubmit: true,
      templateListArr: [],
      showSpinner: false
    }
  },
  mounted() {
    this.getTemplateList()
  },
  methods: {
    sortedArray(array: any[]) {
      return array.slice().sort(function (a, b) {
        return a.createdDate < b.createdDate ? 1 : -1
      })
    },
    customBase64Uploader(eve: any) {
      this.fileName = eve?.srcElement?.files[0]
      console.log(eve.srcElement.files[0].name)
    },
    getFieldType(eve: any) {
      if (eve == 'checkbox') {
        this.addOptions()
        this.showCheckBoxField = true
      }
    },
    addOptions() {
      this.optionsForm.push({
        appFieldName: ''
      })
    },
    deleteOptions(index: any) {
      this.optionsForm.splice(index, 1)
    },
    addForm() {
      this.forms.push({
        question: '',
        fieldName: '',
        fieldType: '',
        mandatory: true,
        fieldOptions: this.optionsForm?.length >= 1 ? this.optionsForm : []
      })
    },
    deleteRow(index: any) {
      this.forms.splice(index, 1)
    },
    showTemplate() {
      let newObj = { fieldData: this.getCustomData(this.forms) }
      const formData: FormData = new FormData()
      formData.append('file', this.fileName)
      formData.append('doc_name', this.docName)
      formData.set('fieldMappings', JSON.stringify(newObj))
      // let payload={
      //   file:this.fileName,
      //   doc_name:this.docName,
      //   fieldMappings:newObj
      // }
      console.log(formData)
      let errorMsg = ''
      this.showSpinner = true
      OnbService.createTemplate(formData)
        .then((response: any) => {
          let templateUrl = response?.data?.data?.templateUrl
          errorMsg = response.data.message
          this.client.open(templateUrl)

          this.client.on(HelloSign.events.CREATE_TEMPLATE, (data: any) => {
            console.log('Template ID: ' + data.templateId)
            this.docName = ''
            this.forms = []
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.docSaved'),
              life: 2000
            })
            // setTimeout(() => {
            //   this.$router.push('/onb/onb-spl');
            // }, 2000);
            this.getTemplateList()
          })
          this.client.on(HelloSign.events.CANCEL, () => {
            this.flowMsg = 'Document save has been cancelled'
            this.toast.add({
              severity: 'error',
              summary: this.$t('ErrorMessages.error'),
              detail: this.$t('ErrorMessages.docNotSaved'),
              life: 2000
            })
          })
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          this.toast.add({
            severity: 'error',
            summary: this.$t('ErrorMessages.error'),
            detail: errorMsg ? errorMsg : this.$t('ErrorMessages.uploadFile'),
            life: 4000
          })
        })
    },
    getCustomData(forms: []) {
      let fieldData: any = []
      forms?.map((item: any, index: any) => {
        let obj = {
          question: item.question,
          fieldName: item.fieldName,
          fieldType: item.fieldType,
          mandatory: item.mandatory,
          fieldOptions:
            this.optionsForm?.length >= 1 && item.fieldType == 'checkbox' ? this.optionsForm : []
        }

        fieldData.push(obj)
      })
      return fieldData
    },
    getTemplateList() {
      this.showSpinner = true
      OnbService.getTemplateList()
        .then((res: any) => {
          console.log(res.data.data)
          this.templateListArr = res.data.data
          this.templateListArr = this.sortedArray(this.templateListArr)
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          //console.error('There was an error!', error);
        })
    }
  }
}
</script>
<style scoped>
.alignText {
  display: flex;
  align-items: center;
}
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}
.clearfix {
  display: flex;
  width: 100%;
}
.field {
  /* float: left; */
  margin-bottom: 1rem;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
}
.p-inputtext {
  width: 100%;
  height: 1.875rem;
  padding: 5px 10px !important;
  box-shadow: none;
  font-size: 13px !important;
  font-weight: 400 !important;
}
.pi-circle-fill {
  color: gray;
  margin-top: 8px;
}
.creatbtn {
  float: right;
}
.trash {
  margin-top: 5px;
  background: red;
  border: none;
}
.trashRow {
  background: red;
  border: none;
  margin-top: 32px;
  margin-left: 18px;
}
</style>
