<template>
  <Toast />
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <form>
    <div id="acco">
      <Accordion
        class="accordian-align"
        :multiple="true"
        :activeIndex="activeIndexArray"
        :class="{ 'disable-fields-alignment': isDiasble }"
      >
        <AccordionTab :header="$t('personalInformation')" :class="accordion - tab">
          <div
            class="grid p-fluid"
            id="personal-info"
            :class="{ 'disable-personalInfo-tab': isDiasble }"
          >
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{
                  'p-invalid': isFirstNameInvalid && userDetails?.userRole !== 'InnovaTeam'
                }"
                >{{ $t('firstName') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  type="text"
                  v-model="firstName"
                  :maxlength="50"
                  class="inputTxt"
                  :class="{ 'p-invalid': isFirstNameInvalid, 'disable-field': isDiasble }"
                  @input="validateFirstName()"
                />
                <i :class="{ 'pi pi-user': !isDiasble }"></i>
              </span>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isFirstNameInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isFirstNameInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >

            <!-- </div> -->

            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('middleName') }}</label>
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  type="text"
                  :maxlength="50"
                  v-model="middleName"
                  class="inputTxt"
                  :class="{ 'disable-field': isDiasble }"
                />
                <i :class="{ 'pi pi-user': !isDiasble }"></i>
              </span>
            </div>
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isLastNameInvalid }"
                >{{ $t('lastName') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  :maxlength="50"
                  class="inputTxt"
                  :class="{ 'p-invalid': isLastNameInvalid, 'disable-field': isDiasble }"
                  type="text"
                  v-model="lastName"
                  @input="validateLastName()"
                />
                <i :class="{ 'pi pi-user': !isDiasble }"></i>
              </span>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isLastNameInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isLastNameInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('preferredName') }}</label>
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  :maxlength="50"
                  type="text"
                  v-model="preferredName"
                  class="inputTxt"
                  :class="{ 'disable-field': isDiasble }"
                />
                <i :class="{ 'pi pi-user': !isDiasble }"></i>
              </span>
            </div>
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt" :class="{ 'p-invalid': isTaxInvalid }"
                >{{ $t('ssnNumber') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <div
                class="aligntext col-12 md:col-6 lg:col-6"
                style="display: flex; align-items: center"
              >
                <!-- <Checkbox v-model="ssnCheckbox" :binary="true" v-if="!isDiasble"
                                @click="handleSSN(ssnCheckbox)" /> -->
                <InputText
                  pattern="[0-9]+"
                  :minlength=9
                  :maxlength=9
                  class="inputTxt"
                  :class="{ 'p-invalid': isTaxInvalid, 'disable-field': isDiasble }"
                  type="text"
                  v-model="taxId"
                  @input="validateTaxId()"
                @keypress="validateNumberr($event)" />
              </div>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isTaxInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isTaxInvalid }"
              >{{ $t('ErrorMessages.ssnValidationMsg') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo calenderTxt">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isBirthDateInvalid }"
                >{{ $t('birthDate') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <div class="col-12 md:col-6 lg:col-6">
                <div v-if="!isDiasble" class="calendarError">
                  <Calendar
                    class="calendarDate"
                    showIcon
                    dateFormat="mm/dd/yy"
                    :class="{ 'p-invalid': isBirthDateInvalid, 'disable-field': isDiasble }"
                    v-model="birthDate"
                    :maxDate="maxSelectableDate"
                    @date-select="validateDateOfBirth()"
                    @input="clearDate()"
                  />
                </div>
                <div v-if="isDiasble" class="disableDate">{{ birthDate }}</div>
              </div>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isBirthDateInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isBirthDateInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
          </div>
        </AccordionTab>
        <AccordionTab :header="$t('contactInformation')">
          <div class="grid p-fluid" id="contact-info">
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isHomePhoneInvalid }"
                >{{ $t('primaryPhone')
                }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <div class="col-12 md:col-6 lg:col-6">
                <div v-if="!isDiasble">
                  <div class="p-inputgroup">
                    <Dropdown
                      class="dropdownTxt countryCode"
                      v-model="selectedCountry"
                      :class="{ 'p-invalid': isCountryCodeValid, 'disable-field': isDiasble }"
                      :options="countryCode"
                      optionLabel="countryCode"
                      optionValue="countryId"
                      @change="validateCountryCode()"
                    />
                    <span class="p-input-icon-right countryTxt">
                      <InputText
                        class="inputTxt"
                        pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                        :maxlength="12"
                        :class="{ 'p-invalid': isHomePhoneInvalid, 'disable-field': isDiasble }"
                        type="text"
                        v-model="homePhone"
                        placeholder="xxx-xxx-xxxx"
                        @input="formatHomePhone()"
                        @keypress="validateNumberr($event)"
                      />
                      <i :class="{ 'pi pi-phone': !isDiasble }"></i>
                    </span>
                  </div>
                </div>
                <div v-if="isDiasble" class="contactField">
                  {{ primaryContact }}
                </div>
              </div>
            </div>
            <small
              class="error-Msg"
              v-if="isHomePhoneInvalid"
              :class="{ 'p-invalid': isHomePhoneInvalid }"
              >{{ $t('ErrorMessages.contactErrorMsg') }}</small
            >
            <!-- <div class="mb-3"> -->
            <!-- </div> -->
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('secondaryPhone') }}</label>
              <div class="col-12 md:col-6 lg:col-6">
                <div v-if="!isDiasble">
                  <div class="p-inputgroup">
                    <Dropdown
                      class="dropdownTxt countryCode"
                      v-model="selectedSecondaryPhone"
                      :class="{
                        'p-invalid': isCountryCodeValidSecoundaryPhone,
                        'disable-field': isDiasble
                      }"
                      :options="countryCode"
                      optionLabel="countryCode"
                      optionValue="countryId"
                      @change="validateMobileCountryCode()"
                    />
                    <span class="p-input-icon-right countryTxt">
                      <InputText
                        class="inputTxt"
                        pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                        :maxlength="12"
                        type="text"
                        :class="{ 'p-invalid': isMobilePhoneInvalid, 'disable-field': isDiasble }"
                        v-model="mobilePhone"
                        placeholder="xxx-xxx-xxxx"
                        @input="formatHomePhone()"
                        @keypress="validateNumberr($event)"
                      />
                      <i :class="{ 'pi pi-phone': !isDiasble }"></i>
                    </span>
                  </div>
                </div>
                <div v-if="isDiasble" class="contactField">{{ secondaryContact }}</div>
              </div>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isMobilePhoneInvalid"
              :class="{ 'p-invalid': isMobilePhoneInvalid }"
              >{{ $t('ErrorMessages.contactErrorMsg') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isEmailInvalid }"
                >{{ $t('primaryEmail')
                }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  class="inputTxt"
                  :class="{ 'p-invalid': isEmailInvalid, 'disable-field': isDiasble }"
                  type="text"
                  v-model="primaryEmail"
                  @input="validatePrimaryEmail()"
                />
                <i :class="{ 'pi pi-envelope': !isDiasble }"></i>
              </span>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isEmailInvalid"
              :class="{ 'p-invalid': isEmailInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isprefferredContactInvalid }"
                >{{ $t('preferredContactMethod')
                }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <Dropdown
                class="col-12 md:col-6 lg:col-6 dropdownTxt"
                :class="{ 'p-invalid': isprefferredContactInvalid, 'disable-field': isDiasble }"
                :options="preferredContact"
                optionLabel="name"
                optionValue="preferredContactMethodId"
                @change="validatePrefferredContact()"
                placeholder="Select Contact"
                v-model="prefferredContact"
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isprefferredContactInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isprefferredContactInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <!-- <div v-if="!isDiasble"> -->
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('preferredLanguage') }}</label>
              <Dropdown
                class="col-12 md:col-6 lg:col-6 dropdownTxt"
                :options="languages"
                optionLabel="name"
                optionValue="languageId"
                :class="{ 'disable-field': isDiasble, hidetrigger: isDiasble }"
                placeholder="Select Language"
                v-model="prefferredLanguage"
              />
              <!-- </div>  -->
              <div v-if="isDiasble">
                {{ languages['prefferredLanguage'] }}
              </div>
            </div>
          </div>
        </AccordionTab>

        <AccordionTab :header="$t('EmergencyContact')">
          <div class="grid p-fluid" id="emergency-info">
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{
                $t('emergencyContactName')
              }}</label>
              <span class="p-input-icon-right col-12 md:col-6 lg:col-6">
                <InputText
                  class="inputTxt"
                  type="text"
                  :maxlength="50"
                  v-model="emergencyContactName"
                  :class="{ 'disable-field': isDiasble }"
                />
                <i :class="{ 'pi pi-user': !isDiasble }"></i>
              </span>
            </div>
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{
                $t('emergencyContactNumber')
              }}</label>
              <div class="col-12 md:col-6 lg:col-6">
                <div v-if="!isDiasble">
                  <div class="p-inputgroup">
                    <Dropdown
                      class="dropdownTxt countryCode"
                      v-model="selectedEmergencyContact"
                      :options="countryCode"
                      optionLabel="countryCode"
                      optionValue="countryId"
                      :class="{
                        'p-invalid': isCountryCodeValidEmergencyContact,
                        'disable-field': isDiasble
                      }"
                      @change="validateEmergencyCountryCode()"
                    />

                    <span class="p-input-icon-right countryTxt">
                      <InputText
                        :maxlength="12"
                        placeholder="xxx-xxx-xxxx"
                        class="inputTxt"
                        type="text"
                        v-model="emergencyContactNumber"
                        @input="formatHomePhone()"
                        @keypress="validateNumberr($event)"
                        :class="{
                          'p-invalid': isEmergencyContactInvalid,
                          'disable-field': isDiasble
                        }"
                      />
                      <i :class="{ 'pi pi-phone': !isDiasble }"></i>
                    </span>
                  </div>
                </div>
                <div v-if="isDiasble" class="contactField">{{ emergencyContact }}</div>
              </div>
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isEmergencyContactInvalid"
              :class="{ 'p-invalid': isEmergencyContactInvalid }"
              >{{ $t('ErrorMessages.contactErrorMsg') }}</small
            >
            <!-- </div> -->
          </div>
        </AccordionTab>
        <!-- <div class="" id="3">

            </div> -->
        <!-- <div class="" id="home-info"> -->
        <AccordionTab :header="$t('homeAddress')">
          <div class="grid p-fluid" id="home-info">
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isStreetAddress1Invalid }"
                >{{ $t('streetAddress1')
                }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <InputText
                class="col-12 md:col-6 lg:col-6 inputTxt"
                :maxlength="50"
                type="text"
                v-model="streetAddress1"
                :class="{ 'p-invalid': isStreetAddress1Invalid, 'disable-field': isDiasble }"
                @input="validateStAddress1()"
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isStreetAddress1Invalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isStreetAddress1Invalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('streetAddress2') }}</label>
              <InputText
                class="col-12 md:col-6 lg:col-6 inputTxt"
                :maxlength="50"
                type="text"
                :class="{ 'disable-field': isDiasble }"
                v-model="streetAddress2"
              />
            </div>
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt">{{ $t('county') }}</label>
              <InputText
                class="col-12 md:col-6 lg:col-6 inputTxt"
                :maxlength="50"
                type="text"
                v-model="county"
                :class="{ 'disable-field': isDiasble }"
              />
            </div>
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isCityInvalid }"
                >{{ $t('city') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <InputText
                class="col-12 md:col-6 lg:col-6 inputTxt"
                :maxlength="50"
                type="text"
                v-model="city"
                :class="{ 'p-invalid': isCityInvalid, 'disable-field': isDiasble }"
                @input="validateCity()"
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isCityInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isCityInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isCountryInvalid }"
                >{{ $t('country') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <Dropdown
                class="col-12 md:col-6 lg:col-6 dropdownTxt"
                :options="countryList"
                optionLabel="name"
                optionValue="countryId"
                placeholder="Select Country"
                :class="{ 'p-invalid': isCountryInvalid, 'disable-field': isDiasble }"
                v-model="country"
                @change="
                  getState(country);
                  validateCountry()
                "
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isCountryInvalid"
              :class="{ 'p-invalid': isCountryInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label
                class="col-5 md:col-4 lg:col-2 labelTxt"
                :class="{ 'p-invalid': isStateInvalid }"
                >{{ $t('state') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <Dropdown
                class="col-12 md:col-6 lg:col-6 dropdownTxt"
                :options="stateList"
                optionLabel="name"
                optionValue="stateId"
                v-model="state"
                @change="validateState()"
                :class="{ 'p-invalid': isStateInvalid, 'disable-field': isDiasble }"
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isStateInvalid"
              :class="{ 'p-invalid': isStateInvalid }"
              >{{ $t('ErrorMessages.mandatory') }}</small
            >
            <!-- </div> -->
            <div class="field contactInfo">
              <label class="col-5 md:col-4 lg:col-2 labelTxt" :class="{ 'p-invalid': isZipInvalid }"
                >{{ $t('zip') }}<span v-if="!isDiasble" class="text-danger"> *</span></label
              >
              <!-- <InputNumber :max="6" v-model="zip" inputId="withoutgrouping" :useGrouping="false" :class="{ 'p-invalid': isZipInvalid }" @input="validateZip"  /> -->
              <InputText
                class="col-12 md:col-6 lg:col-6 inputTxt"
                v-model="zip"
                :class="{ 'p-invalid': isZipInvalid, 'disable-field': isDiasble }"
                :maxlength="6"
                type="text"
                @input="validateZip()"
              />
            </div>
            <!-- <div class="mb-3"> -->
            <small
              class="error-Msg"
              v-if="isZipInvalid && userDetails?.userRole !== 'InnovaTeam'"
              :class="{ 'p-invalid': isZipInvalid }"
              >{{ $t('ErrorMessages.zipValidationMsg') }}</small
            >
            <!-- </div> -->
          </div>
        </AccordionTab>
        <!-- </div> -->
      </Accordion>
    </div>
  </form>

  <div v-if="onPreviewPage != 'preview'" style="column-gap: 10px; margin-top: 15px">
    <Button :label="$t('saveAndExit')" @click="savePersonalInfo" class="mr-2" />
    <Button :label="$t('proceed')" @click="savePersonalInfo('next')" />
  </div>
</template>
<script lang="ts">
import { useToast } from 'primevue/usetoast'
import axios from 'axios'
import { ErrorMessages } from '../shared/constant/error-messages-constants'
import moment from 'moment'
import OnbService from '../shared/services/OnbService'
import { sidebarStore } from '@/stores/side-bar'
import { computed, ref } from 'vue'

export default {
  setup() {
    const sidebarStoreData: any = sidebarStore()
    const progress = ref(0)
    const progressValue = computed(() => sidebarStoreData.$state.activeIndex)
    return {
      sidebarStoreData,
      progressValue,
      progress
    }
  },
  props: {
    disableField: Boolean,
    ConsultId: Number,
    isDiasbled: Boolean,
    onPreviewSubmit: Boolean,
    onPreviewPage: String
  },
  inject: ['isConsultantInfoPage'],
  data() {
    return {
      activeIndexArray: [0, 1, 2, 3],
      userDetails: '',
      empId: '',
      employeeId: '',
      maxDate: moment(new Date()).format('MM/DD/YYYY'),
      showSpinner: false,
      toast: useToast(),
      onbConsultId: '',
      selectedCountry: '',
      selectedSecondaryPhone: '',
      employeeAllData: {
        progress: ''
      },
      countryOptions: [
        { label: '+1 (USA)', value: '1' },
        { label: '+44 (UK)', value: '44' }
      ],
      workHistoryData: [],
      educationalData: [],
      WorkExperienceSubTaskObj: {},
      previewSubTaskObj: {},
      educationalSubTaskObj: {},
      completeProfileSubTaskObj: {},
      createProfileObj: {},
      personalInformationObj: {},
      subTaskPercentage: '',
      firstName: '',
      middleName: '',
      lastName: '',
      preferredName: '',
      prefferredLanguage: '',
      selectedEmergencyContact: '',
      taxId: '',
      taxReason: '',
      birthDate: '',
      homePhone: '',
      mobilePhone: '',
      primaryEmail: '',
      primaryContact: '',
      secondaryContact: '',
      emergencyContact: '',
      prefferredContact: '',
      streetAddress1: '',
      streetAddress2: '',
      country: '',
      county: '',
      state: '',
      city: '',
      zip: '',
      countryList: [],
      stateList: [],
      preferredContact: [],
      emergencyContactName: '',
      emergencyContactNumber: '',
      languages: [],
      status: [],
      errorMsg: ErrorMessages,
      isFirstNameInvalid: false,
      isLastNameInvalid: false,
      isTaxInvalid: false,
      isBirthDateInvalid: false,
      isHomePhoneInvalid: false,
      isMobilePhoneInvalid: false,
      isEmergencyPhoneInvalid: false,
      isEmergencyContactInvalid: false,
      isEmailInvalid: false,
      isCountryCodeValid: false,
      isCountryCodeValidSecoundaryPhone: false,
      isCountryCodeValidEmergencyContact: false,
      isStreetAddress1Invalid: false,
      isCountryInvalid: false,
      isStateInvalid: false,
      isCityInvalid: false,
      isZipInvalid: false,
      isprefferredContactInvalid: false,
      ssnCheckbox: true,
      reasonCheckbox: false,
      reasonInvalid: false,
      disablessn: false,
      isDiasble: false,
      isPreviewSubmit: false,
      isPreviePage: ''
    }
  },
  created() {
    this.emitter.on('myProfile', (evt: any) => {
      console.log('val', evt)
      // const id = evt
      this.scrollToDivById(evt.value)
      // this.divId = evt
    })

    this.emitter.emit('disableForm', (evt: any) => {
      console.log('val', evt)
      this.isPreviePage = 'preview'
    })
    this.emitter.on('submitPreviewForm', (evt: any) => {
      console.log('val', evt)
      // this.isPreviewSubmit = evt;
      // if(this.isPreviewSubmit){
      //     this.savePersonalInfo('next');
      // }
    })
  },
  watch: {
    onPreviewSubmit(val) {
      this.isPreviewSubmit = val
      if (val) {
        if (this.ConsultId) {
          this.savePersonalInfo()
        } else {
          this.savePersonalInfo('next')
        }
      }
    },
    isDiasbled(val) {
      // if(val){
      this.isDiasble = val
      // this.savePersonalInfo('next');
      // }
    },
    onPreviewPage(val) {
      console.log('onPreviewPage', val)
      this.isPreviePage = 'preview'
    },

        firstName(newValue) {
            this.$emit('firstName', newValue);
        },
        middleName(newValue) {
            this.$emit('middleName', newValue);
        },
        lastName(newValue) {
            this.$emit('lastName', newValue);
        },
        preferredName(newValue) {
            this.$emit('preferredName', newValue);
        },
        prefferredLanguage(newValue) {
            this.$emit('prefferredLanguage', newValue);
        },
        taxId(newValue) {
            this.$emit('taxId', newValue);
        },
        taxReason(newValue) {
            this.$emit('taxReason', newValue);
        },
        isTaxInvalid(newValue) {
            this.$emit('isTaxInvalid', newValue);
        },
        birthDate(newValue) {
            this.$emit('birthDate', newValue);
        },
        homePhone(newValue) {
            this.$emit('homePhone', newValue);
        },
        mobilePhone(newValue) {
            this.$emit('mobilePhone', newValue);
        },
        primaryEmail(newValue) {
            this.$emit('primaryEmail', newValue);
        },
        prefferredContact(newValue) {
            this.$emit('prefferredContact', newValue);
        },
        emergencyContactName(newValue) {
            this.$emit('emergencyContactName', newValue);
        },
        emergencyContactNumber(newValue) {
            this.$emit('emergencyContactNumber', newValue);
        },
        streetAddress1(newValue) {
            this.$emit('streetAddress1', newValue);
        },
        streetAddress2(newValue) {
            this.$emit('streetAddress2', newValue);
        },
        country(newValue) {
            this.$emit('country', newValue);
        },
        county(newValue) {
            this.$emit('county', newValue);
        },
        state(newValue) {
            this.$emit('state', newValue);
        },
        city(newValue) {
            this.$emit('city', newValue);
        },
        zip(newValue) {
            this.$emit('zip', newValue);
        },
        isZipInvalid(newValue) {
            this.$emit('isZipInvalid', newValue);
        },
        isHomePhoneInvalid(newValue) {
            this.$emit('isHomePhoneInvalid', newValue)
        },
        isMobilePhoneInvalid(newValue) {
            this.$emit('isMobilePhoneInvalid', newValue)
        },
        isEmergencyContactInvalid(newValue) {
            this.$emit('isEmergencyContactInvalid', newValue)
        },
        selectedCountry(newValue) {
            this.$emit('selectedCountry', newValue)
        },
        isCountryCodeValid(newValue) {
            this.$emit('isCountryCodeValid', newValue)
        },
        selectedSecondaryPhone(newValue) {
            this.$emit('selectedSecondaryPhone', newValue)
        },
        isCountryCodeValidSecoundaryPhone(newValue) {
            this.$emit('isCountryCodeValidSecoundaryPhone', newValue)
        },
        selectedEmergencyContact(newValue) {
            this.$emit('selectedEmergencyContact', newValue)
        },
        isCountryCodeValidEmergencyContact(newValue) {
            this.$emit('isCountryCodeValidEmergencyContact', newValue)
        },


    },

  beforeCreate() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    console.log(userDetails)
    this.employeeId = userDetails?.employeeId
  },
  computed: {
    maxSelectableDate() {
      // Calculate the date from the end of 2010
      const maxDate = new Date(2010, 11, 31) // December 31, 2010
      return maxDate
    }
  },
  mounted() {
    // this.emitter.on('myProfile', (evt: any) => {
    //     console.log("val", evt);
    //     const id = evt
    //     this.scrollToDivById(id)
    //     // this.divId = evt
    // })
    // setTimeout(() => {
    //     this.scrollToDivById('home-info')
    // }, 5000);
    console.log(this.ConsultId)
    if (this.ConsultId) {
      // console.log("...............",this.countryCode)
      OnbService.getEmployeeData(this.ConsultId).then((response: any) => {
        this.employeeAllData = response.data.data
        const myProfileInfoTaskObj = response?.data?.data?.employeeTaskDetails[0]
        this.createProfileObj = myProfileInfoTaskObj?.taskStatus
        console.log('createProfileObj', this.createProfileObj)
        this.personalInformationObj = myProfileInfoTaskObj?.subTask?.subEmployeeTask[0]?.taskStatus
        this.previewSubTaskObj = myProfileInfoTaskObj?.subTask?.subEmployeeTask[1]?.taskStatus
        this.firstName = response?.data?.data?.firstName
        this.middleName = response?.data?.data?.middleName
        this.lastName = response?.data?.data?.lastName
        this.selectedCountry = response?.data?.data?.primaryExt
        this.selectedSecondaryPhone = response?.data?.data?.secondaryExt
        this.selectedEmergencyContact = response?.data?.data?.emergencyExt
        this.preferredName = response?.data?.data?.preferredName
        this.prefferredLanguage = response?.data?.data?.preferredLanguageId
        this.prefferredContact = response?.data?.data?.preferredContactMethodId
        this.taxId = response?.data?.data?.ssn
        this.birthDate =
          response?.data?.data?.dateOfBirth != '' && response?.data?.data?.dateOfBirth != null
            ? moment(response?.data?.data?.dateOfBirth, 'MM/DD/YYYY').format('MM/DD/YYYY')
            : ''
        this.homePhone = response?.data?.data?.phone
        console.log(this.countryExtension)
        this.mobilePhone = response?.data?.data?.phone2
        this.emergencyContactNumber = response?.data?.data?.emergencyContactNumber
        this.primaryEmail = response?.data?.data?.email
        this.streetAddress1 = response?.data?.data?.address1
        this.streetAddress2 = response?.data?.data?.address2
        this.city = response?.data?.data?.city
        this.zip = response?.data?.data?.zipcode
        this.country = response?.data?.data?.countryId
        this.primaryContact = this.contactExtension(this.homePhone, this.selectedCountry)
        this.secondaryContact = this.contactExtension(this.mobilePhone, this.selectedSecondaryPhone)
        this.emergencyContact = this.contactExtension(
          this.emergencyContactNumber,
          this.selectedEmergencyContact
        )

        this.getState(response?.data?.data?.countryId)
        this.stateList?.forEach((item: any) => {
          if (item.stateId == response?.data?.data?.stateId) {
            this.state = item.stateId
          }
        })
        this.taxReason = response?.data?.data?.ssnReason
        if (
          response?.data?.data?.ssnReason &&
          response?.data?.data?.ssnReason != '' &&
          response?.data?.data?.ssnReason != null
        ) {
          this.ssnCheckbox = false
          this.reasonCheckbox = true
        }
        this.emergencyContactNumber = response?.data?.data?.emergencyContactNumber
        this.emergencyContactName = response?.data?.data?.emergencyPersonName

        this.workHistoryData = []
        this.educationalData = []
      })
    }

    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.userDetails = userDetails
    //this.empId = userDetails.employeeId
    this.empId = this.ConsultId ? parseInt(this.ConsultId) : userDetails.employeeId
    // this.employeeId = userDetails.employeeId;
    OnbService.getStatus().then((response: any) => {
      console.log('response', response)
      this.status = response?.data?.data[1]?.status
      console.log(this.status[0])
    })
    OnbService.getCountryList().then((response: any) => {
      this.countryList = response?.data?.data
      this.countryCode = this.countryList.map((res) => {
        return { countryCode: res.countryExt + ' ' + res.countryCode, countryId: res.countryId }
      })
      this.countryExtension = this.countryList.map((res) => {
        return { CountryExtention: res.countryExt, countryId: res.countryId }
      })
      this.countryCode.unshift({ countryCode: 'None', countryId: null })
    })
    // OnbService.getCountryList().then((response: any) => {
    //     this.countryList = response.data.data;
    // });
    OnbService.getPreferredContact().then((response: any) => {
      this.preferredContact = response.data.data
    })
    OnbService.getLanguages().then((response: any) => {
      this.languages = response.data.data
    })

    if (!this.ConsultId) {
      this.showSpinner = true
      OnbService.getEmployeeData(this.empId)
        .then((response: any) => {
          console.log('response', response)
          console.log('create', this.countryCode)
          this.employeeAllData = response?.data?.data
          console.log(this.employeeAllData?.employeeTaskDetails[0]?.employeeTaskId)
          const myProfileInfoTaskObj = response?.data?.data?.employeeTaskDetails[0]
          this.createProfileObj = myProfileInfoTaskObj?.taskStatus
          console.log('createProfileObj', this.createProfileObj)
          this.personalInformationObj =
            myProfileInfoTaskObj?.subTask?.subEmployeeTask[0]?.taskStatus
          // this.educationalSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[1].taskStatus;
          // this.WorkExperienceSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[2].taskStatus;
          this.previewSubTaskObj = myProfileInfoTaskObj?.subTask?.subEmployeeTask[1]?.taskStatus
          // this.completeProfileSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[4].taskStatus;
          this.subTaskPercentage = myProfileInfoTaskObj?.subTask?.percentage
          this.workHistoryData = []
          this.educationalData = []
          this.firstName = response?.data?.data?.firstName
          this.middleName = response?.data?.data?.middleName
          this.lastName = response?.data?.data?.lastName
          this.selectedCountry = response?.data?.data?.primaryExt
          this.selectedSecondaryPhone = response?.data?.data?.secondaryExt
          this.selectedEmergencyContact = response?.data?.data?.emergencyExt
          this.preferredName = response?.data?.data?.preferredName
          this.prefferredLanguage = response?.data?.data?.preferredLanguageId
          this.prefferredContact = response?.data?.data?.preferredContactMethodId
          this.taxId = response?.data?.data?.ssn
          this.taxReason = response?.data?.data?.ssnReason
          if (
            response?.data?.data?.ssnReason &&
            response?.data?.data?.ssnReason != '' &&
            response?.data?.data?.ssnReason != null
          ) {
            this.ssnCheckbox = false
            this.reasonCheckbox = true
          }
          this.emergencyContactNumber = response?.data?.data?.emergencyContactNumber
          this.emergencyContactName = response?.data?.data?.emergencyPersonName
          this.birthDate =
            response?.data?.data?.dateOfBirth != '' && response?.data?.data?.dateOfBirth != null
              ? moment(response?.data?.data?.dateOfBirth, 'MM/DD/YYYY').format('MM/DD/YYYY')
              : ''
          this.homePhone = response?.data?.data?.phone
          this.mobilePhone = response?.data?.data?.phone2
          this.primaryEmail = response?.data?.data?.email
          this.streetAddress1 = response?.data?.data?.address1
          this.streetAddress2 = response?.data?.data?.address2
          this.country = response?.data?.data?.countryId
          this.county = response?.data?.data?.county
          this.city = response?.data?.data?.city
          this.zip = response?.data?.data?.zipcode
          this.getState(response?.data?.data?.countryId)
          this.primaryContact = this.contactExtension(this.homePhone, this.selectedCountry)
          this.secondaryContact = this.contactExtension(
            this.mobilePhone,
            this.selectedSecondaryPhone
          )
          this.emergencyContact = this.contactExtension(
            this.emergencyContactNumber,
            this.selectedEmergencyContact
          )

          console.log(this.countryExtension, this.primaryContact)
          this.stateList?.forEach((item: any) => {
            if (item.stateId == response?.data?.data?.stateId) {
              this.state = item?.stateId
            }
          })
          //this.state = response?.data?.data?.stateId;
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    }
  },
  methods: {
    scrollToDivById(divId: any) {
      // divId = 3
      // let element = document.getElementById(divId)
      let element = document.getElementById('acco')?.getElementsByClassName('p-accordion-tab')[
        divId
      ]
      element?.scrollIntoView({ behavior: 'smooth' })
      // element?.scrollIntoView({behavior: 'smooth'})
    },
    contactExtension(phonenumber, selectedCountryId) {
      var contactExtention = selectedCountryId
        ? this.countryExtension.find((res) => res.countryId == selectedCountryId)
        : ''
      var contactNumber = ''
      if (contactExtention != '' && phonenumber != '') {
        contactNumber = contactExtention.CountryExtention + ' ' + phonenumber
      }
      return contactNumber
    },
    checkMethod() {
      console.log('Checked')
    },
    validateNumberr(evt) {
      const charCode = evt.which ? evt.which : evt.keyCode
      if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 46) {
        evt.preventDefault()
      }
    },
    validateMobileCountryCode() {
      if (this.mobilePhone) {
        if (!this.selectedSecondaryPhone) {
          this.isCountryCodeValidSecoundaryPhone = true
        } else {
          this.isCountryCodeValidSecoundaryPhone = false
        }
      } else {
        this.isCountryCodeValidSecoundaryPhone = false
      }
    },
    validateEmergencyCountryCode() {
      if (this.emergencyContactNumber) {
        if (!this.selectedEmergencyContact) {
          this.isCountryCodeValidEmergencyContact = true
        } else {
          this.isCountryCodeValidEmergencyContact = false
        }
      } else {
        this.isCountryCodeValidEmergencyContact = false
      }
    },
    formatHomePhone() {
      // Remove existing hyphens and non-numeric characters
      let formattedPhone = String(this.homePhone).replace(/[^0-9]/g, '')
      let formatMobilePhone = String(this.mobilePhone).replace(/[^0-9]/g, '')
      let formatEmergencyContact = String(this.emergencyContactNumber).replace(/[^0-9]/g, '')

      // Apply the desired format (xxx-xxx-xxxx)
      if (formattedPhone.length >= 3) {
        formattedPhone = formattedPhone.slice(0, 3) + '-' + formattedPhone.slice(3)
      }
      if (formattedPhone.length >= 7) {
        formattedPhone = formattedPhone.slice(0, 7) + '-' + formattedPhone.slice(7)
      }
      if (formatMobilePhone.length >= 3) {
        formatMobilePhone = formatMobilePhone.slice(0, 3) + '-' + formatMobilePhone.slice(3)
      }
      if (formatMobilePhone.length >= 7) {
        formatMobilePhone = formatMobilePhone.slice(0, 7) + '-' + formatMobilePhone.slice(7)
      }
      if (formatEmergencyContact.length >= 3) {
        formatEmergencyContact =
          formatEmergencyContact.slice(0, 3) + '-' + formatEmergencyContact.slice(3)
      }
      if (formatEmergencyContact.length >= 7) {
        formatEmergencyContact =
          formatEmergencyContact.slice(0, 7) + '-' + formatEmergencyContact.slice(7)
      }

      // Update the model
      this.homePhone = formattedPhone
      this.mobilePhone = formatMobilePhone
      this.emergencyContactNumber = formatEmergencyContact

      // Validate the formatted phone number
      if (this.homePhone) {
        this.validateHomePhone()
        if (!this.selectedCountry) {
          this.isCountryCodeValid = true
        } else {
          this.isCountryCodeValid = false
        }
      } else {
        this.isHomePhoneInvalid = false
        this.isCountryCodeValid = false
      }
      if (this.mobilePhone) {
        this.validateMobilePhone()
        if (!this.selectedSecondaryPhone) {
          this.isCountryCodeValidSecoundaryPhone = true
        } else {
          this.isCountryCodeValidSecoundaryPhone = false
        }
      } else {
        this.isMobilePhoneInvalid = false
        this.isCountryCodeValidSecoundaryPhone = false
      }
      if (this.emergencyContactNumber) {
        this.validateEmergencytPhone()
        if (!this.selectedEmergencyContact) {
          this.isCountryCodeValidEmergencyContact = true
        } else {
          this.isCountryCodeValidEmergencyContact = false
        }
      } else {
        this.isCountryCodeValidEmergencyContact = false
        this.isEmergencyContactInvalid = false
      }
    },
    navigateToOnb() {
      this.$router.push('/onb/onb-spl')
    },
    /*handleSSN(ssnCheckbox: any) {
      if (ssnCheckbox == true) {
        this.reasonCheckbox = true
        // this.$props.disableField= true;
        this.taxId = ''
      } else {
        this.reasonCheckbox = false
        this.isTaxInvalid = false
        this.disablessn = false
      }
      console.log(ssnCheckbox)
    },*/
    editToPersonalInfo() {
      // this.isDiasble=false;
    },
    getStatus() {
      let openStatusObj = this.status[0] //---> open status
      let completeStatusObj = this.status[3] //---> complete status
      let progressStatusObj = this.status[1] //---> progress status
      let submittedObj = this.status[2] //---> submitted status
      if (
        this.firstName &&
        this.lastName &&
        this.state &&
        this.zip &&
        this.taxId &&
        this.country &&
        this.birthDate &&
        this.homePhone &&
        this.primaryEmail &&
        this.streetAddress1 &&
        this.city
      ) {
        return completeStatusObj
      }
      if (
        this.firstName &&
        this.lastName &&
        this.state &&
        this.zip &&
        this.taxId &&
        this.country &&
        this.birthDate &&
        this.homePhone &&
        this.primaryEmail &&
        this.streetAddress1 &&
        this.city
      ) {
        return progressStatusObj
      } else {
        return openStatusObj
      }
    },
    getSignupStatus() {
      let completeStatusObj = this.status[3] //---> complete status
      return completeStatusObj
    },
    getState(countryId: any) {
      this.state = ''
      let stList: any = this.countryList.filter((res: any) => {
        return res.countryId == countryId
      })
      this.stateList = stList[0]?.state
    },

    validateFirstName() {
      console.log("this.firstName.trim() === ''", this.firstName.trim() === '')
      this.isFirstNameInvalid =
        this.firstName.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    ValidityState() {
      this.isStateInvalid = this.state.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateLastName() {
      this.isLastNameInvalid =
        this.lastName.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateTaxId() {
      if (!this.reasonCheckbox) {
        this.isTaxInvalid = this.taxId.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
      } else {
        this.isTaxInvalid = false
      }
    },
    validateReason() {
      this.reasonInvalid =
        this.taxReason.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },

    validateDateOfBirth() {
      this.birthDate = this.birthDate ? moment(this.birthDate).format('MM/DD/YYYY') : ''
      this.isBirthDateInvalid =
        this.birthDate || this.userDetails?.userRole == 'InnovaTeam' ? false : true
    },
    clearDate() {
      this.isBirthDateInvalid =
        (this.birthDate == '' || this.birthDate == null) &&
        this.userDetails?.userRole !== 'InnovaTeam'
          ? true
          : false
    },
    validateHomePhone() {
      if (!this.homePhone) {
        this.isHomePhoneInvalid = true
      } else if (this.homePhone !== '' && this.homePhone !== null) {
        const phoneno = /[0-9]{3}-[0-9]{3}-[0-9]{4}/
        if (this.homePhone?.match(phoneno)) {
          this.isHomePhoneInvalid = false
        } else {
          this.isHomePhoneInvalid = true
        }
      } else {
        this.isHomePhoneInvalid = true
      }
      //this.isHomePhoneInvalid = this.homePhone.trim() === '';
      console.log(this.isHomePhoneInvalid)
    },
    validateMobilePhone() {
      if (this.mobilePhone !== '' && this.mobilePhone !== null) {
        const phoneno = /[0-9]{3}-[0-9]{3}-[0-9]{4}/
        if (this.mobilePhone?.match(phoneno)) {
          this.isMobilePhoneInvalid = false
        } else {
          this.isMobilePhoneInvalid = true
        }
      } else if (this.mobilePhone == '') {
        this.isMobilePhoneInvalid = false
      } else {
        this.isMobilePhoneInvalid = true
      }
    },
    validateEmergencytPhone() {
      if (this.emergencyContactNumber !== '' && this.emergencyContactNumber !== null) {
        const phoneno = /[0-9]{3}-[0-9]{3}-[0-9]{4}/
        if (this.emergencyContactNumber?.match(phoneno)) {
          this.isEmergencyContactInvalid = false
        } else {
          this.isEmergencyContactInvalid = true
        }
      } else if (this.emergencyContactName == '') {
        this.isEmergencyContactInvalid = false
      } else {
        this.isEmergencyContactInvalid = true
      }
    },
    validatePrimaryEmail() {
      this.isEmailInvalid =
        this.primaryEmail.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateCountryCode() {
      if (this.homePhone) {
        if (!this.selectedCountry) {
          this.isCountryCodeValid = true
        } else {
          this.isCountryCodeValid = false
        }
      } else {
        this.isCountryCodeValid = false
      }
    },
    validateStAddress1() {
      this.isStreetAddress1Invalid =
        this.streetAddress1.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateCountry() {
      this.isCountryInvalid = this.country == '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateState() {
      // if (this.state && this.userDetails?.userRole !=='InnovaTeam') {
      //     this.isStateInvalid = false;
      // } else {
      //     this.isStateInvalid = true;
      // }
      //this.isStateInvalid = this.state == '';
      this.isStateInvalid = this.state == '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateCity() {
      this.isCityInvalid = this.city.trim() === '' && this.userDetails?.userRole !== 'InnovaTeam'
    },
    validateZip() {
      if (this.userDetails?.userRole == 'InnovaTeam') {
        this.isZipInvalid = false
      } else if (this.zip !== '' && this.zip !== null ) {
        if (!this.isNumber(this.zip) || this.zip.length < 6) {
          this.isZipInvalid = true
        } else {
          this.isZipInvalid = false
        }
      } else {
        this.isZipInvalid = true
      }
    },
    isNumber(value?: string | number): boolean {
      return !isNaN(Number(value.toString()))
    },
    validatePrefferredContact() {
      this.isprefferredContactInvalid = this.prefferredContact == ''
    },

    savePersonalInfo(getNext?: any) {
      console.log('employeeId', this.empId)

      if (!this.firstName && getNext == 'next') {
        this.isFirstNameInvalid = true
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.lastName && getNext == 'next') {
        this.isLastNameInvalid = true
        // this.activeIndexArray = [0];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.state && getNext == 'next') {
        this.isStateInvalid = true
        // this.activeIndexArray = [3];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.country && getNext == 'next') {
        this.isCountryInvalid = true
        // this.activeIndexArray = [3];
        this.activeIndexArray = [0, 1, 2, 3]
      }
            if(this.taxId && getNext !== 'next'){
                this.validateTaxId();
            }
      if (!this.taxId && getNext == 'next') {
        this.isTaxInvalid = true
        // this.activeIndexArray = [0];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (getNext == 'next') {
                this.validateTaxId();
            }
            // if (this.reasonCheckbox && !this.taxReason && getNext == 'next') {
    //     this.reasonInvalid = true
    //     // this.activeIndexArray = [0];
    //     this.activeIndexArray = [0, 1, 2, 3]
      // }
      if (!this.birthDate && getNext == 'next') {
        this.isBirthDateInvalid = true
        // this.activeIndexArray = [0];
        this.activeIndexArray = [0, 1, 2, 3]
      }

      if (!this.primaryEmail && getNext == 'next') {
        this.isEmailInvalid = true
        // this.activeIndexArray = [1];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.selectedCountry && getNext == 'next') {
        this.isCountryCodeValid = true
        // this.activeIndexArray = [1];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.streetAddress1 && getNext == 'next') {
        this.isStreetAddress1Invalid = true
        // this.activeIndexArray = [3];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.zip && getNext == 'next') {
        this.isZipInvalid = true
        // this.activeIndexArray = [3];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.city && getNext == 'next') {
        this.isCityInvalid = true
        // this.activeIndexArray = [3];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (!this.prefferredContact && getNext == 'next') {
        this.isprefferredContactInvalid = true
        // this.activeIndexArray = [2];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (getNext == 'next') {
        this.validateHomePhone()
      }
      if (this.homePhone && getNext != 'next') {
        this.validateHomePhone()
      }
      if (this.mobilePhone && getNext != 'next') {
        this.validateHomePhone()
      }
      if (this.emergencyContactNumber && getNext != 'next') {
        this.validateEmergencytPhone()
      }
      if (!this.homePhone && getNext == 'next') {
        this.isHomePhoneInvalid = true
        // this.activeIndexArray = [1];
        this.activeIndexArray = [0, 1, 2, 3]
      }
      if (
        (this.city &&
          !this.isZipInvalid &&
          this.streetAddress1 &&
          !this.isMobilePhoneInvalid &&
          !this.isEmergencyContactInvalid &&
          this.primaryEmail &&
          !this.isHomePhoneInvalid &&
          !this.isTaxInvalid &&
          !this.reasonInvalid &&
          this.birthDate &&
          this.country &&
          this.homePhone &&
          this.selectedCountry &&
          this.state &&
          this.lastName &&
          this.firstName &&
          this.prefferredContact &&
          !this.isEmergencyContactInvalid &&
          !this.isCountryCodeValid &&
          !this.isCountryCodeValidSecoundaryPhone &&
          !this.isCountryCodeValidEmergencyContact &&
          !this.isMobilePhoneInvalid &&
          getNext == 'next') ||
        (getNext != 'next' &&
          !this.isMobilePhoneInvalid &&
          !this.isEmergencyContactInvalid &&
          !this.isHomePhoneInvalid &&
          !this.isCountryCodeValid &&
          !this.isCountryCodeValidSecoundaryPhone &&
          !this.isCountryCodeValidEmergencyContact)
      ) {
        this.showSpinner = true
        console.log('EMPLOYEE DATA:', this.employeeAllData)
        // if (this.isPreviewSubmit) {
        //     this.previewSubTaskObj.name = 'Completed';
        //     this.previewSubTaskObj.statusId = 4;
        //     this.createProfileObj.name = 'Completed';
        //     this.createProfileObj.statusId = 4;
        // }
        let payload = {
          employeeId: this.empId,
          ownerId: 1,
          createdBy: 1,
          modifiedBy: 1,
          dateOfBirth: this.birthDate ? moment(this.birthDate).format('MM/DD/YYYY') : '',
          departmentId: null,
          locationId: null,
          organizationId: 1,
          genderId: '',
          stateId: this.state,
          countryId: this.country,
          county: this.county,
          secondaryStateId: null,
          secondaryCountryId: null,
          createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
          modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
          isActive: 'Y',
          isDeleted: 'N',
          secondaryAddress1: null,
          secondaryAddress2: null,
          firstName: this.firstName,
          middleName: this.middleName,
          lastName: this.lastName,
          primaryExt: this.selectedCountry,
          ssn: this.taxId,
          ssnReason: this.reasonCheckbox ? this.taxReason : '',
          emergencyPersonName: this.emergencyContactName,
          emergencyContactNumber: this.emergencyContactNumber,
          email: this.primaryEmail,
          email1: null,
          secondaryExt: this.selectedSecondaryPhone,
          emergencyExt: this.selectedEmergencyContact,
          address1: this.streetAddress1,
          address2: this.streetAddress2,
          externalId: null,
          preferredName: this.preferredName,
          phone: this.homePhone,
          phone2: this.mobilePhone,
          city: this.city,
          zipcode: this.zip,
          scondaryZipcode: null,
          preferredLanguageId: this.prefferredLanguage,
          preferredContactMethodId: this.prefferredContact,
          educationDetails: [],
          employeeWorkHistory: [],
          employeeTaskDetails: [
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[0]?.employeeTaskId
                ? this.employeeAllData?.employeeTaskDetails[0]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 2,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Complete Profile',
                externalId: null,
                subTask: null
              },
              taskStatus: this.status[3],
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[1]?.employeeTaskId
                ? this.employeeAllData?.employeeTaskDetails[1]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 3,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Pending Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                statusTypeId: 2,
                organizationId: 1,
                createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                isActive: 'Y',
                name: 'Open'
              },
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[2]?.employeeTaskId
                ? this.employeeAllData?.employeeTaskDetails[2]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 4,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Complete Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                statusTypeId: 2,
                organizationId: 1,
                createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
                isActive: 'Y',
                name: 'Open'
              },
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              modifiedDate: moment(new Date()).format('MM/DD/YYYY h:mm:ss.SSS'),
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            }
          ],
          user: null,
          progress: this.employeeAllData?.progress
        }

        OnbService.employeeSave(payload)
          .then((response: any) => {
            console.log(response)
                        //if(response.code==200){
            // this.subTaskPercentage = response?.data?.data?.data?.employeeTaskDetails[0]?.subTask?.percentage;
            // this.$emit('subTaskPercentage', this.subTaskPercentage);
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.personalDetails'),
              life: 2000
            })
            setTimeout(() => {
              console.log('The response is', response)

              if (response.data.data && getNext == 'next' && !this.isPreviewSubmit) {
                this.isPreviewSubmit = false
                console.log('next Button is navigated')
                this.$emit('navigateToPreview', 'preview')
                this.emitter.emit('setPreviewTabActive', { eventContent: 'preview-active' })
              }
              if (this.isPreviewSubmit && response.data.data && this.ConsultId) {
                // this.isPreviewSubmit = false;
                console.log('Onb Login')
                this.isDiasble = true
                this.$emit('eventname', true)
                window.location.reload()
              }
              if (response.data.data && getNext != 'next' && !this.ConsultId) {
                this.$router.push('/onb/consultant-dashboard')
              }
              if (
                this.isPreviewSubmit &&
                response.data.data &&
                getNext == 'next' &&
                !this.ConsultId
              ) {
                this.isPreviewSubmit = false
                this.$router.push('/onb/consultant-dashboard')
              }
            }, 2000)
          })
          .finally(() => {
            setTimeout(() => {
              this.showSpinner = false
              // this.isPreviewSubmit =  false;
            }, 1000)
          })
          .catch((error) => {
            this.showSpinner = false
            // this.isPreviewSubmit =  false;
            console.error('There was an error!', error)
          })
      } else {
        // this.isPreviewSubmit = false;
        this.isDiasble = false
        this.$emit('eventname', false)
        return
      }

      // this.$emit('education', false)
      this.$emit('preview', false)
    }
  }
}
</script>
<style lang="scss" scoped>
.alignText {
  display: flex;
  align-items: center;
}

.disable {
  pointer-events: none;
  color: #aaa;
}

.disableDate {
  font-size: 13px;
  margin-left: 11px;
  text-align: left;
  // margin-top: 22px;
  font-weight: 600;
}

.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

.knob {
  float: left;
  position: relative;
  top: -16px;
}

.p-checkbox {
  margin-right: 5px;
  height: 25px;
  width: 25px;
}

.p-invalid {
  border-color: red !important;
  color: red;
}
.p-warning {
  border-color: gray;
  color: gray;
}
.grid {
  display: grid;
  margin-top: 0;
  // margin:0;
}
/* .p-inputgroup{
    widows: 0px;
} */
.field label {
  margin-top: 5px;
}

// .field.col-12.md\:col-4.lg\:col-4.mb-0 {
//     display: flex;
//     white-space: nowrap;
// }
/* input.p-inputtext.p-component {
    width: fit-content;
} */

.p-fluid .p-dropdown {
  display: inline-flex;
}
.dropdownTxt {
  height: 40px;
  border-color: #0070cd;
  text-align: left;
}
.disable-field :deep {
  span.p-dropdown-label.p-inputtext {
    font-size: 13px !important;
    font-weight: 600 !important;
    overflow: visible;
  }
}
// .disable-field{
//     margin-left: 20px;
// }
.col-12 {
  padding: 0px;
}
a {
  color: #0070cd;
}
@media (max-width: 768px) {
  .contactInfo {
    display: inline-flex;
    flex-direction: column !important;
  }
  .labelTxt {
    display: flex;
    justify-content: flex-start !important;
  }
}
.contactInfo {
  white-space: nowrap;
  display: inline-flex;
  justify-content: center;
  align-items: baseline;
  align-content: center;
}
.inputTxt {
  // margin-top: 6px;
  height: 40px;
  border-radius: 5px;
  border-color: #0070cd;
}
// .inputTextField{
//     margin-top: 14px;
// }
.labelTxt {
  display: flex;
  justify-content: flex-end;
}
.p-dropdown.p-component.p-inputwrapper.dropdownTxt.countryCode {
  width: 150px;
  margin-right: 3px;
}
// .countryTxt :deep{
// input.p-inputtext.p-component.inputTxt.disable-field {
//   margin-left: -75px;
//     margin-top: -2px;
// }
// }

// input.p-inputtext.p-component.p-filled.inputTxt.disable-field {
//          margin-left: -170px;
//         margin-top: -2px;
// }

.calendarDate :deep {
  input.p-inputtext.p-component {
    border-top-right-radius: 1px;
    border-bottom-right-radius: 1px;
    height: 40px;
    border-color: #0070cd;
  }
}
.p-invalid :deep {
  input.p-inputtext.p-component {
    border-color: red !important;
  }
}
.calendarDate :deep {
  .p-button {
    padding: 11px 10px !important;
  }
}
.dropdownTxt :deep {
  span.p-dropdown-label.p-inputtext {
    margin-top: 5px;
  }
}
.accordian-align :deep {
  .p-accordion-header .p-accordion-header-link {
    display: flex !important;
    flex-direction: row-reverse;
    justify-content: space-between;
    border: none;
    height: 45px;
    color: #0070cd;
    border: none;
    margin-top: 20px;
  }
  .p-accordion-content {
    border: none;
  }
  .p-accordion-header {
    margin-bottom: -7px;
  }
}

.calendarDate :deep {
  .p-button {
    padding: 11px 15px !important;
  }
}
.disable-fields-alignment :deep {
  .p-accordion-content {
    // display: flex;
    // justify-content: center;
    // align-items: center;
    // overflow: hidden;
    margin-left: 100px;
  }
}
// .field.contactInfo {
//     margin-left: 100px !important;
// }
// .mb-3{
//     margin-left: 100px;
// }
// .calenderTxt :deep{
//     .labelTxt{
//  margin-left: 100px;
//     }
//     // .inputTxt{
//     //     margin-left: 100px;
//     // }

// }
.contactField {
  font-size: 13px;
  margin-left: 10px;
  text-align: left;
  //     // margin-top: 22px;
  font-weight: 600;
}
::-webkit-scrollbar {
  width: 4px;
}

::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb {
  background: #305faf;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: #305faf;
}
.accordian-align {
  height: 300px;
  overflow: auto;
  padding-right: 10px;
  scrollbar-width: thin;
  scrollbar-color: #305faf lightgrey;
  //  box-shadow: inset 0 0 5px grey;
}
.stepper {
  margin-top: -20px;
}
.error-Msg {
  margin-top: -10px;
  margin-bottom: 10px;
  margin-left: 70px;
}
@media (max-width: 2600px) {
    .accordian-align {
      max-height: 400px;
    }
  }

  @media (max-width: 2000px) {
    .accordian-align {
      max-height: 300px;
    }
  }

  @media (max-width: 1700px) {
    .accordian-align {
      max-height: 400px;
    }
  }

  @media (max-width: 1300px) {
    .accordian-align {
      max-height: 500px;
    }
  }
  @media (max-width: 500px) {
    .accordian-align {
      max-height: 450px;
    }
  }

  @media (max-width: 400px) {
    .accordian-align {
      max-height: 310px;
    }
  }
  @media (max-width: 360px) {
    .accordian-align {
      max-height: 360px;
    }
  }







</style>
