<template>
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <div class="chart-container">
    <div class="chart">
      <h2 style="text-align: left" class="text-above-taskstable">
        {{ $t('completeOnboardingProcess') }}
      </h2>
      <DataTable
        :value="taskNameArr"
        scrollable
        scrollHeight="400px"
        tableStyle="width: 100%"
        class="data-table candidate-dashboard-table"
      >
        <Column>
          <template #body="slotProps">
            <!-- <i  v-if="!slotProps.index" class="pi pi-circle"></i>
            <i v-if="slotProps.index" class="pi pi-circle-fill"></i> -->
            {{ taskNameArr[slotProps.index].templateName }}
          </template>
        </Column>
        <Column :frozen="true" :style="{ width: '30%' }">
          <template #body="slotProps">
            <Button
              :disabled="slotProps.index"
              @click="handleStarClick(slotProps), agrementStore.setDocumentData(slotProps)"
              >{{ taskStatus[slotProps.index] }}</Button
            >
          </template>
        </Column>
      </DataTable>
      <p v-if="taskNameArr.length === 0">No Records Found</p>
    </div>
  </div>
</template>

<script lang="ts">
import onbService from '@/shared/services/OnbService'
import { ref, provide } from 'vue'
import { useAgrementStore } from '@/stores/create-agrement'
import { Session } from 'inspector'
export default {
  setup() {
    const agrementStore = useAgrementStore()
    return {
      agrementStore
    }
  },

  data() {
    return {
      showSpinner: false,
      empId: '',
      taskNameArr: [],
      taskStatus: [],
      dataToshare: ref('hellloooo'),
      docDdata: ''
      // empDocId:''
    }
  },
  methods: {
    handleStarClick(index: any) {
      console.log('pendingdataa', index.data)
      this.docDdata = index.data
      // this.$router.push({ path: 'create-agreement/' , params: { index } })
      // this.emitter.emit('empDocumentData', index.data);
      console.log(index.data)

      sessionStorage.setItem('externaltemplateId', index.data.extTemplateId)
      sessionStorage.setItem('fieldJson', index.data.templateFieldMapping.fieldJson)
      sessionStorage.setItem('templateName', index.data.templateName)
      sessionStorage.setItem('templateId', index.data.templateId)
      let taskName
      if (index.data.taskName) {
        taskName = index.data.taskName //If it is complete Profile the it will assign
      } else {
        taskName = index.data.templateName //If it is not complete profile it will assign corresponding document name
      }
      onbService
        .startTaskRemainderEmail(this.loggedEmpId, taskName)
        .finally(() => {
          setTimeout(() => {}, 1000)
        })
        .catch((error) => {
          console.error(error)
        })
      if (index.data.templateId || index.data.taskName == 'Pending Onboarding Documents') {
        const empDocId = index.data
        this.$router.push({ path: 'initiate-info/', params: { userData: empDocId } })
        // this.$router.push('initiate-info')
      }
      if (index.data.taskName == 'Complete Profile') {
        this.$router.push('/onb/my-profile')
      }
    }
  },
  mounted() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    this.showSpinner = true
    onbService
      .getOnboardingDocuments(this.empId)
      .then((res: any) => {
        this.taskNameArr = []
        this.taskStatus = []
        const arr = res.data.data
          .map((item, index) => {
            return item.employeeDocumentsList
          })
          .map((res: any, index: any) => {
            res.map((doc: any, index: any) => {
              if (doc?.statusId != 4) {
                this.taskNameArr.push(doc.templatePackage.template)
              }
              if (doc?.statusId == null || doc?.statusId == 1) {
                this.taskStatus.push('START TASK')
              } else if (doc?.statusId == 2) {
                this.taskStatus.push('RESUME TASK')
              }
              // else{
              //     this.taskStatus.push(doc?.statusId)
              // }
            })
          })
        //this.taskNameArr=this.sortedArray(this.taskNameArr);
      })
      .finally(() => {
        setTimeout(() => {
          this.showSpinner = false
        }, 1000)
      })
      .catch((error) => {
        this.showSpinner = false
        //console.error('There was an error!', error);
      })
  },
  provide() {
    return {
      document: 'hello world'
    }
  }
}
</script>

<style scoped lang="scss">
.pi-circle-fill {
  color: gray;
  margin-right: 7px;
}
.pi-circle {
  margin-right: 7px;
}
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}
.text-above-taskstable {
  font-weight: 400;
  color: #000000;
  font-size: 20px;
  letter-spacing: 0.2px;
  // line-height: 50px;
}
.candidate-dashboard-table :deep {
  .p-datatable-thead {
    display: none;
  }
}
</style>
