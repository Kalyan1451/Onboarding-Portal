<template>
  <div class="preview-layout" v-if="ConsultId">
    <div>
      <Breadcrumb :model="items1" class="bread-crumb">
        <template #item="{ item, props }">
          <router-link v-if="item.route" v-slot="{ href, navigate }" :to="item.route" custom>
            <a :href="href" v-bind="props.action" @click="navigate">
              <span>{{ item.label }}</span>
            </a>
          </router-link>
          <a v-else :href="item.url" :target="item.target" v-bind="props.action">
            <span class="text-color">{{ item.label }}</span>
          </a>
        </template>
        <template #separator> / </template>
      </Breadcrumb>
    </div>
    <Card class="preview-card">
      <template #content>
        <div class="container">
          <div class="view-record">
            <Button
              class="pi pi-chevron-left"
              @click="navigateToOnb()"
              id="navigatedashboard-Style"
            />
            <!-- <i class="pi pi-chevron-left" :title="$t('viewDetails')" data-placement="top"  v-if="ConsultId"  @click="navigateToOnb()" /> -->
            <p class="view-style">{{ $t('viewcandidaterecord') }}</p>
          </div>
          <DashboardStepper :ConsultId="ConsultId" />
          <div v-if="ConsultId" class="stylepreview">
            <div class="panel-content" v-if="ConsultId">
              <div class="table custom-scroll-bar">
                <div class="onbheader">
                  <div class="header-color">{{ $t('onboardingDocumentsDetails') }}</div>
                  <div>
                    <Button
                      :label="$t('addOnboardingDocument')"
                      icon="pi pi-plus"
                      disable-field="true"
                      @click="addOnboardingdocument"
                      class="button-preview"
                    ></Button>
                  </div>
                </div>
                <DataTable
                  :value="taskNameArr"
                  showGridlines
                  tableStyle="min-width: 40rem"
                  class="preview-table"
                >
                  <Column :header="$t('headers.documentPackagee')">
                    <template #body="slotProps">
                      {{ this.taskNameArr[slotProps.index].templatePackage.template.templateName }}
                    </template>
                  </Column>
                  <Column :header="$t('headers.requestedByy')">
                    <template #body="slotProps">
                      {{ this.taskNameArr[slotProps.index].createdByName }}
                    </template>
                  </Column>
                  <Column :header="$t('headers.requestedOnn')">
                    <template #body="slotProps">
                      {{ convertingTime(this.taskNameArr[slotProps.index].createdDate) }}
                    </template>
                  </Column>
                  <Column :header="$t('headers.modifiedOnn')">
                    <template #body="slotProps">
                      {{ convertingTime(this.taskNameArr[slotProps.index].modifiedDate) }}
                    </template>
                  </Column>
                  <template #empty> {{ this.$t('emptyRecord') }} </template>
                  <Column field="status" key="index" :header="$t('headers.statuss')">
                    <template #body="slotProps">
                      {{ this.taskNameArr[slotProps.index].statusId }}
                    </template>
                  </Column>
                  <Column
                    field="edit"
                    :header="$t('headers.actionss')"
                    class="custom-column"
                    :style="{ width: '150px' }"
                    :frozen="true"
                  >
                    <template #body="slotProps">
                      <div class="action-style">
                        <i
                          class="pi pi-eye eyeicon"
                          :title="$t('viewDetails')"
                          data-placement="top"
                        />
                        <Button
                          type="button"
                          icon="pi pi-ellipsis-v"
                          @click="
                            toggle($event);
                            getdata(slotProps)
                          "
                          aria-haspopup="true"
                          aria-controls="overlay_menu"
                          class="style-button"
                          :title="$t('more')"
                          data-placement="top"
                        />
                        <!-- <div class="up-triangle"></div> -->
                        <!-- <Menu ref="menu" id="overlay_menu" :model="items" :popup="true" class="preview-resendmenu"/> -->
                        <OverlayPanel ref="op" class="overlay-style">
                          <!-- <Menu  :model="items"  class="preview-resendmenu"/> -->
                          <Menu :model="itemList" class="preview-menu" />
                        </OverlayPanel>
                      </div>
                    </template>
                  </Column>
                </DataTable>
              </div>
              <Dialog
                v-model:visible="addOnboardingDocuments"
                :header="$t('addOnboardingDocuments')"
                :style="{ width: '58vw' }"
                :modal="true"
                :draggable="false"
              >
                <Divider />
                <div class="dialogcontent">
                  <!-- <Panel :header="$t('sendDocuments')"> -->
                  <div class="grid p-fluid">
                    <div class="field col-12 md:col-6 lg:col-6 mb-0">
                      <label>{{ $t('selectPakages') }}</label>
                      <MultiSelect
                        :options="packageData"
                        optionLabel="packageName"
                        filter
                        optionValue="packageId"
                        v-model="packages"
                        :placeholder="$t('selectPakages')"
                        class="viewDropDown"
                      />
                    </div>
                    <div class="field col-12 md:col-6 lg:col-6 mb-0">
                      <label>{{ $t('selectForms') }}</label>
                      <MultiSelect
                        :options="getDocumentsList"
                        optionLabel="templateName"
                        filter
                        optionValue="templateId"
                        v-model="documents"
                        :placeholder="$t('selectForms')"
                        class="viewDropDown"
                      />
                    </div>
                  </div>
                </div>
                <template #footer>
                  <div class="button-footer">
                    <Button
                      :label="$t('clear')"
                      class="button-close"
                      icon="pi pi-times"
                      @click="closeDocumentPopUp"
                      severity="danger"
                    />
                    <Button
                      :label="$t('send')"
                      :disabled="isDisabled"
                      icon="pi pi-send"
                      severity="success"
                      @click="sendOnboardingdocument"
                    />
                  </div>
                </template>
              </Dialog>
            </div>
          </div>
          <div class="style-previewaccordion">
            <PersonalInformation
              :ConsultId="ConsultId"
              :isDiasbled="formValue"
              :onPreviewPage="pageName"
              @eventname="updateparent"
              :onPreviewSubmit="onFormSubmit"
              ref="myChild"
            />
            <!-- <EducationalInfo :ConsultId="ConsultId" disable-field="true" />
        <WorkExperience :ConsultId="ConsultId" disable-field="true" /> -->
            <div style="column-gap: 10px; margin: 15px 0">
              <!-- <Button v-if="ConsultId" :label="$t('back')" @click="navigateToOnb()" /> -->
              <!-- <Button v-if="!ConsultId" :label="$t('previous')" @click="goToPersonalInfo"></Button> -->
              <Button
                v-if="!isUpdate && userDetails?.userRole === 'Consultant'"
                :label="$t('edit')"
                class="mr-2"
                @click="editToPersonalInfo()"
              ></Button>
              <Button
                v-if="!isUpdate && userDetails?.userRole === 'InnovaTeam'"
                :label="$t('edit')"
                class="mr-2"
                @click="editToPersonalInfo()"
              ></Button>
              <!-- <Button v-if="isUpdate" :label="$t('update')" @click="updateToPersonalInfo(false)"></Button> -->
              <Button
                v-if="!ConsultId"
                :label="$t('previewLabelBtn')"
                class="mr-2"
                @click="navigateTodashbard"
              />
              <Button
                v-if="ConsultId"
                :label="$t('save')"
                class="mr-2"
                @click="navigateTodashbard"
              />
            </div>
          </div></div
      ></template>
    </Card>
  </div>
  <div v-if="!ConsultId">
    <PersonalInformation
      :ConsultId="ConsultId"
      :isDiasbled="formValue"
      :onPreviewPage="pageName"
      @eventname="updateparent"
      :onPreviewSubmit="onFormSubmit"
      ref="myChild"
    />
    <!-- <EducationalInfo :ConsultId="ConsultId" disable-field="true" />
        <WorkExperience :ConsultId="ConsultId" disable-field="true" /> -->
    <div style="display: flex; justify-content: center; column-gap: 10px; margin: 15px 0">
      <!-- <Button v-if="ConsultId" :label="$t('back')" @click="navigateToOnb()" /> -->
      <Button v-if="!ConsultId" :label="$t('previousLabel')" @click="goToPersonalInfo"></Button>
      <Button
        v-if="!isUpdate && userDetails?.userRole === 'Consultant'"
        :label="$t('editLabel')"
        @click="editToPersonalInfo()"
      ></Button>
      <Button
        v-if="!isUpdate && userDetails?.userRole === 'InnovaTeam'"
        :label="$t('editLabel')"
        @click="editToPersonalInfo()"
      ></Button>
      <!-- <Button v-if="isUpdate" :label="$t('update')" @click="updateToPersonalInfo(false)"></Button> -->
      <Button v-if="!ConsultId" :label="$t('previewLabel')" @click="navigateTodashbard" />
      <Button v-if="ConsultId" :label="$t('saveLabel')" @click="navigateTodashbard" />
    </div>
  </div>
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
  </div>
</template>

<script lang="ts">
import { ref } from 'vue'
import { globalUtilfunction } from '../../src/components/utils/globalfunctions'
// import WorkExperience from './WorkExperience.vue'
import PersonalInformation from './PersonalInformation.vue'
// import EducationalInfo from './EducationalInfo.vue'
import OnbService from '../shared/services/OnbService'
import { useToast } from 'primevue/usetoast'
import DashboardStepper from '@/components/DashboardStepper.vue'

import moment from 'moment'
import DataTable from 'primevue/datatable'
const myChild = ref(null)
const globalUtilfun = new globalUtilfunction()
export default {
  name: 'PreviewComponent',
  components: {
    // WorkExperience,
    PersonalInformation,
    // EducationalInfo,
    DataTable,
    DashboardStepper
  },
  props: {
    onPreviewSubmitForm: Boolean
  },
  data() {
    return {
      // disable:true
      pageName: 'preview',
      formValue: false,
      onFormSubmit: false,
      active: 0,
      showList: false,
      isUpdate: false,
      isDisable: true,
      employeeDocumentData: [],
      employeeDocumentData1: [],
      employeeDocumentIdList: [],
      items1: [
        { label: this.$t('dashboardLabel'), route: '/onb/onb-spl' },
        { label: this.$t('viewcandidaterecord') },
        { label: this.$t('createTemplate'), route: '/onb/create-template' }
      ],
      tableRowData: '',
      createdBy: '',
      selectedCity: '',
      selectedValue: '',
      payloadForResend: '',
      cities: [
        { name: 'View', code: 'NY' },
        { name: 'Resend', code: 'RM' },
        { name: 'Delete', code: 'LDN' }
      ],
      items: [
        {
          label: this.$t('resend'),
          icon: 'pi pi-send',
          command: () => {
            this.resendOnboardingDocuments(this.payloadForResend)
          }
        },
        {
          label: this.$t('deleteItem'),
          icon: 'pi pi-trash',
          command: () => {
            this.deleteOnboardingDocuments(this.tableRowData)
          }
        }
      ],
      itemList: [],
      empId: '',
      userDetails: '',
      employeeId: '',
      toast: useToast(),
      showSpinner: false,
      status: [],
      isDisabled: true,
      addOnboardingDocuments: false,
      educationalSubTaskObj: {},
      WorkExperienceSubTaskObj: {},
      completeProfileSubTaskObj: {},
      personalSubTaskObj: {},
      createProfileObj: {},
      workHistoryData: [],
      educationalData: [],
      subTaskPercentage: '',
      products: [
        { code: this.$t('completeProfileCreation'), edit: this.$t('data1') },
        { code: this.$t('completeDocumentation'), edit: this.$t('data2') },
        { code: this.$t('completeVerification'), edit: this.$t('data3') },
        { code: this.$t('completeEducationalInformation'), edit: this.$t('data3') }
      ],
      selectedSpecialist: null,
      employeeAllData: {
        progress: '',
        city: '',
        dateOfBirth: '',
        email: '',
        genderId: '',
        stateId: '',
        countryId: '',
        county: '',
        firstName: '',
        middleName: '',
        lastName: '',
        ssn: '',
        ssnReason: '',
        emergencyPersonName: '',
        emergencyContactNumber: '',
        address1: '',
        address2: '',
        preferredName: '',
        zipcode: '',
        preferredLanguageId: '',
        preferredContactMethodId: '',
        phone2: '',
        phone: ''
      },
      packageData: [],
      documentsData: '',
      packageDropDownData: [],
      getDocuments: [],
      getDocumentsList: [],
      packages: [],
      documents: [],
      isDropdownSelected: false,
      isWarningMessage: false,
      previewTableData: [],
      taskNameArr: []
    }
  },

  inject: ['ConsultId'],

  beforeCreate() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.employeeId = userDetails.employeeId
  },
  mounted() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.userDetails = userDetails
    console.log('userDetailsuserDetails', userDetails)
    this.selectedSpecialist = this.userDetails.employeId
    this.empId = this.userDetails.employeeId
    this.formValue = true
    this.emitter.emit('disableForm', { value: 'preview' })
    OnbService.getStatus().then((response: any) => {
      this.status = response.data.data[1].status
      console.log(this.status[0])
    })
    if (this.ConsultId) {
      this.getOnboardingDocuments()
    }
    // OnbService.getEmployeeData(this.empId).then((response: any) => {
    //     console.log(response);
    //     this.employeeAllData = response.data.data;
    //     const myProfileInfoTaskObj = response.data.data?.employeeTaskDetails[0]
    //     this.createProfileObj = myProfileInfoTaskObj.taskStatus;
    //     this.personalSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[0].taskStatus;
    //     this.subTaskPercentage = myProfileInfoTaskObj.subTask.percentage;
    //     this.workHistoryData = [];
    //     this.educationalData = [];

    // })
    // this.getOnboadingDocumentIds();
  },
  watch: {
    packages: 'checkDropdowns',
    documents: 'checkDropdowns',

    onPreviewSubmitForm(val) {
      if (val) {
        this.onFormSubmit = val
      }
    }
  },
  methods: {
    convertingTime(date: any) {
      if (!date) {
        return
      }
      let modifiedDate = moment(date, 'MM/DD/YYYY HH:mm:ss').format('YYYY-MM-DD HH:mm:ss')
      return globalUtilfun.getCurrentDateTimeByUTC(modifiedDate)
    },
    updateparent(val: any) {
      console.log('updateparent')
      if (!val) {
        this.onFormSubmit = val
        this.isUpdate = true
        this.formValue = false
      } else {
        this.onFormSubmit = false
        this.isUpdate = false
        this.formValue = true
      }
    },

    editToPersonalInfo() {
      console.log(this.formValue)
      this.isUpdate = true
      this.formValue = false
      // this.emitter.emit('disableForm', { value: false })
    },

    navigateToOnb() {
      this.$router.push('/onb/onb-spl')
    },
    toggle(event: any) {
      this.$refs.op.toggle(event)
      console.log('yaahhoo')
    },

    // toggle1(event: any) {
    //     console.log(event);
    //     this.$refs.menu.toggle(event);
    //     console.log("yaahhoo");

    // },
    // editToPersonalInfo(){
    //   this.isDisable=false
    // },
    getOnboardingDocuments() {
      OnbService.openPreviewDataTable(this.ConsultId)
        .then((res: any) => {
          this.showSpinner = true
          this.previewTableData = res.data.data
          this.taskNameArr = []
          this.previewTableData.forEach((item: any) => {
            console.log(
              'item -----------------------------------------',
              item.employeeDocumentsList
            )
            item.employeeDocumentsList.forEach((el: any) => {
              this.taskNameArr.push(el)
            })
            // tableDataArray= item.employeeDocumentsList;
            // this.taskNameArr=tableDataArray;
          })
          console.log('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^', this.taskNameArr)
          //let requestedBy = taskNameArr[]
          this.taskNameArr.map((res) => {
            if (res.statusId == 1) {
              res.statusId = 'Open'
            } else if (res.statusId == 2) {
              res.statusId = 'Resume Task'
            } else if (res.statusId == 3) {
              res.statusId = 'Submitted'
            } else if (res.statusId == 4) {
              res.statusId = 'Completed'
            }
          })
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    },
    getdata(ev: any) {
      const itemValues = this.items
      console.log('i ma working', ev.data)
      this.tableRowData = ev.data
      if (this.tableRowData.statusId !== 'Completed') {
        this.itemList = itemValues
      } else {
        const newArr: string[] = itemValues.filter((element) => {
          return element.label !== this.$t('deleteItem')
        })
        this.itemList = newArr
      }
      this.payloadForResend = {
        employeeId: ev.data.employeeId,
        employeeDocumentsId: [ev.data.employeeDocumentId] ? [ev.data.employeeDocumentId] : '',
        createdBy: ev.data.createdBy
      }
    },
    selectedItem(ev: any) {
      console.log(ev)
      console.log(ev.value)
    },
    resendOnboardingDocuments(payload: any) {
      this.showSpinner = true
      this.$refs.op.hide()
      OnbService.resendOnboardingDocuments(payload)
        .then((res) => {
          if (res) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.resendDocumentSuccessfully'),
              life: 2000
            })
            this.getOnboardingDocuments()
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
    },
    deleteOnboardingDocuments(rowData: any) {
      this.showSpinner = true
      this.$refs.op.hide()
      OnbService.deleteOnboardingDocuments(rowData.employeeDocumentId, rowData.employeeId)
        .then((res) => {
          if (res) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.documentDeletedSuccessfully'),
              life: 2000
            })
            this.getOnboardingDocuments()
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
    },
    goToPersonalInfo() {
      this.$emit('backToPersonalInfo', 'personal-info')
    },

    checkDropdowns() {
      if (this.getDocumentsList.length === 0 && this.packageData.length === 0) {
        this.isWarningMessage = true
      } else {
        this.isWarningMessage = false
      }
      this.isDisabled = !(this.packages.length > 0 || this.documents.length > 0)
    },
    closeDocumentPopUp() {
      this.packages = []
      this.documents = []
    },

    addOnboardingdocument() {
      this.showSpinner = true
      OnbService.addOnboardingDocumentsData(this.ConsultId)
        .then((res: any) => {
          this.showSpinner = true
          this.documentsData = res.data.data
          this.packages = []
          this.documents = []
          // this.getDocuments=res.data.data[0].documentList;
          console.log('getDocuments', this.getDocuments)
          this.packageData = this.documentsData.filter((item) => {
            return item.packageId !== 0
          })
          this.getDocuments = this.documentsData.filter((item) => {
            return item.packageId === 0
          })
          this.getDocumentsList = this.getDocuments[0].templateList

          console.log('Document List', this.getDocuments)
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
          this.addOnboardingDocuments = true
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    },
    sendOnboardingdocument() {
      this.showSpinner = true
      this.addOnboardingDocuments = false
      let payload = {
        employeeId: this.ConsultId,
        createdBy: this.selectedSpecialist,
        packages: this.packages,
        templates: this.documents
      }
      OnbService.sendOnboardingDocumentsData(payload)
        .then((res) => {
          if (res) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.addedDocumentSuccessfully'),
              life: 2000
            })
            this.packages = []
            this.documents = []
            this.getDocumentsList = []
            this.packageData = []
            this.getOnboardingDocuments()
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    },

    getSignupStatus() {
      let completeStatusObj = this.status[3] //---> complete status
      return completeStatusObj
    },

    navigateTodashbard() {
      this.onFormSubmit = true
      this.isUpdate = false
      this.formValue = true
    }
  }
}
</script>

<style scoped>
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.dialogcontent {
  /* padding:4px */
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

.field label {
  font-weight: bolder;
  margin-bottom: 3px;
  color: #777;
  font-size: 16px;
}

.button-footer {
  padding: 0.7rem 0.2rem 0.2rem 0rem;
}

.stylepreview {
  display: flex;
  flex-direction: column;
  row-gap: 10px;
}

.button-preview {
  float: right;
}

.button-close {
  background-color: red;
}

.abc {
  position: absolute;
  z-index: 10;
  left: 64px;
  /* bottom:10px; */
}

.more-btn {
  background: none;
  border: none;
  color: black;
}

.button-preview {
  background-color: #3895e2;
  font-size: 12px;
  font-weight: 600;
  padding: 10px;
  letter-spacing: 0.18px;
  border: none;
  position: relative;
  top: 10px;
  right: 10px;
}

.style-button {
  padding: 5px;
  color: white;
  background-color: #3895e2;
  border-radius: 50%;
}

.pi-eye {
  cursor: not-allowed;
  color: white;
}
.onbheader {
  display: flex;
  justify-content: space-between;
}
.table {
  height: auto;
  width: 1134px;
  height: 242px;
  background-color: #144684;
  border-radius: 15px;
  padding: 10px;
}
.header-color {
  width: 338px;
  height: 56px;
  font-weight: 400;
  color: #ffffff;
  font-size: 18px;
  text-align: center;
  letter-spacing: 0.18px;
  line-height: 50px;
  white-space: nowrap;
  margin-left: -23px;
}
.action-style {
  display: flex;
  column-gap: 10px;
  justify-content: center;
  align-items: center;
}
.style-previewaccordion {
  /* background-color: #f1f8ff; */
  width: 790px;
  height: 300px;
  /* overflow-y: auto; */
  padding-right: 10px;
  /* scrollbar-color: #305faf #777;
    -moz-appearance: button-like;
   scrollbar-width: thin; */
}
/* .style-previewaccordion::-moz-scrollbar-track {
  -moz-appearance: scrollbar-button;
  Additional styling for desired visual effects
} */
.up-triangle {
  width: 0;
  height: 0;
  border-bottom: 20px solid red; /* Change the color and width as needed */
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
}
.preview-layout {
  padding: 0%;
  margin: 0%;
  /* background: #305fafe6; */
  background: #eeedf3;
  /* height: 100vh; */
  width: 100%;
  height: auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* padding: 10px; */
  /* overflow: hidden */
}
.preview-card {
  display: flex;
  align-items: stretch;
  justify-content: center;
  width: 1223px;
  height: auto;
  background-color: #ffffff;
  border-radius: 20px;
  box-shadow: 0px 9px 30px 5px #00000026;
  margin-top: 17px;
  /* overflow-y: auto; */
  padding: 0 0 30px 0;
  /* overflow-y: scroll; */
}
.container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  row-gap: 20px;
}
/* .container:first-child{
    justify-content: flex-start;
} */
.view-record {
  display: flex;
  /* flex-direction: column; */
  justify-content: start;
  align-items: center;
  /* text-align: left; */
  width: 100%;
}
.view-style {
  /* font-family:"Poppins", Helvetica; */
  font-size: 20px;
  font-weight: 400;
  color: #000000;
  /* width: 466px;
    height: 46px; */
  /* position: relative; */
  /* bottom: 47px;
    right: 436px; */
}
#navigatedashboard-Style {
  /* width: 11px;
    height: 19px; */
  /* position: relative;
   top: 16px;
    right: 570px; */
  color: #777;
  background: none;
  border: none;
  font-size: 16px;
  font-weight: 700;
}
.preview-table {
  height: 150px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: #305faf lightgrey;
}
::-webkit-scrollbar {
  width: 2px;
}

::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb {
  background: #305faf;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: #305faf;
}
/* ::-webkit-scrollbar {
  width: 2px;
}
 
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}
 
 ::-moz-scrollbar-thumb {
  background: #305faf;
  border-radius: 10px;
}
 
::-moz-scrollbar-thumb:hover {
  background: #305faf;
} */
</style>
