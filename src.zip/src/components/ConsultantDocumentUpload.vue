<template>
  <Toast />
  <Panel :header="$t('createagreement')">
    <form v-for="(item, index) in customFieldJson" :key="index">
      <ng-container v-if="item.fieldType == 'text'">
        <div class="grid p-fluid">
          <div class="field contactInfo mb-3">
            <label for="username" class="col-5 md:col-4 lg:col-2 labelTxt">{{
              item.question
            }}</label>
            <InputText
              class="inputTxt"
              type="text"
              id="username"
              v-model="valueJson[item.fieldName]"
            />
          </div>
        </div>
      </ng-container>
      <ng-container v-if="item.fieldType == 'checkbox'">
        <div class="grid p-fluid">
          <div class="field contactInfo mb-3">
            <label class="col-5 md:col-4 lg:col-2 labelTxt" for="username">{{
              item.question
            }}</label>
            <div class="grid ownradio">
              <ng-container v-for="(options, index) in item.fieldOptions" :key="index">
                <div class="field col-12 md:col-4 lg:col-4 mb-0">
                  <RadioButton
                    v-model="valueJson[item.fieldName][options.appFieldName]"
                    inputId="{{options.appFieldName}}"
                    name="dynamic"
                    :value="true"
                  />
                  <label class="ownLabel" for="status">{{ options.appFieldName }}</label>
                </div>
              </ng-container>
            </div>
          </div>
        </div>
      </ng-container>
    </form>
    <div
      class="field col-12 md:col-4 lg:col-3 mb-0"
      style="display: flex; justify-content: flex-end; column-gap: 20px; margin-top: 15px"
    >
      <Button :label="$t('proceed')" @click="getDocument" />
    </div>
  </Panel>
</template>

<script lang="ts">
import { reactive } from 'vue'
import OnbService from '@/shared/services/OnbService'
import { useAgrementStore } from '@/stores/create-agrement'
import { useToast } from 'primevue/usetoast'
export default {
  setup() {
    const agrementStore = useAgrementStore()
    const agreementData = agrementStore.getDocumentData
    console.log(agrementStore)
    return {
      agrementStore,
      agreementData
    }
  },
  data() {
    return {
      toast: useToast(),
      empId: '',
      latest: 'nwjosmmwoewk',
      docData: [],
      userDetails: '',
      valueJson: {},
      ssn: '',
      questions: '',
      empDocList: [],
      customFieldJson: [],
      customFields: '',
      templateId: '',
      agreementName: '',
      empDocId: '',
      selectedOption: '',
      fieldjsons: '',
      // forms: reactive([]),
      question: '',
      fname: '',
      selectedType: '',
      checkvalue: true,
      documentName: '',
      selectedUserType: '',
      ingredient: '',
      client: new HelloSign({
        clientId: '1c3b71bf90f213797a51e29bd4a1b25a',
        skipDomainVerification: true,
        testMode: true
      })
    }
  },
  methods: {
    getEmittedData() {
      this.emitter.on('empDocumentData', (ev: any) => {
        this.docData = JSON.parse(ev.templateFieldMapping.fieldJson).fieldData
        console.log('insidecreate', this.docData)
      })
      // console.log("out",ev);
    },
    getDocument() {
      console.log(this.valueJson)
      const externalTemplateId = sessionStorage.getItem('externaltemplateId')
      const agreemnentName = sessionStorage.getItem('templateName')
      const fieldJson = sessionStorage.getItem('fieldJson')

      //  this.getEmittedData()
      // console.log("insideproceede",this.docData);
      // console.log(this.selectedOption);
      // this.customFieldJson=JSON.parse(this.agreementData.templateFieldMapping.fieldJson).fieldData
      //     let obj={
      //         "ssn":this.ssn,
      //         "marital status" : {
      //         "single":true
      // }
      //     }
      let payload = {
        templateId: externalTemplateId, //this.templateId,
        agreementName: agreemnentName, //this.agreementName,
        candidateDetail: {
          candidateEmail: this.userDetails.email,
          candidateId: this.userDetails.employeeId,
          firstName: this.userDetails.firstName,
          lastName: this.userDetails.lastName
        },
        customFields: fieldJson,
        customFieldValues: JSON.stringify(this.valueJson)
      }
      OnbService.createAgreement(payload, this.empDocId).then((res) => {
        if (res.data.data) {
          // console.log(signingUrl);
          let signingUrl = res.data.data.signingUrl
          this.client.open(signingUrl, {
            clientId: '1c3b71bf90f213797a51e29bd4a1b25a',
            skipDomainVerification: true,
            testMode: true
            // allowCancel :false
          })
          this.client.on(HelloSign.events.CANCEL, () => {
            OnbService.submitDocuments(this.empDocId, 2).then((res) => {
              this.$router.push('/onb/pending-documents')
            })
            this.flowMsg = 'Agreement creation has been cancelled'
            this.toast.add({
              severity: 'error',
              summary: 'Error',
              detail: 'not saved',
              life: 2000
            })
          })
          this.client.on(HelloSign.events.SIGN, (data: any) => {
            OnbService.submitDocuments(this.empDocId, 4).then((res) => {
              this.$router.push('/onb/pending-documents')
            })
            this.toast.add({
              severity: 'success',
              summary: 'success',
              detail: 'saved successfully',
              life: 3000
            })
            console.log(data)
          })
        }
      })
    }
  },
  mounted() {
    console.log('documentDataaaaaaaaaaaaaa', this.agreementData)
    const fieldJson = sessionStorage.getItem('fieldJson')
    // console.log(fieldJson));
    this.customFieldJson = JSON.parse(fieldJson).fieldData
    console.log(this.customFieldJson)
    this.customFieldJson.forEach((field: any) => {
      if (field.fieldType === 'checkbox') {
        this.valueJson[field.fieldName] = {}
      }
    })

    // const documentData =localStorage.getItem('empDocumentData');
    // console.log("empdocumentdatajkkkkkkkkkkkkkkkkkkkkkkk",documentData);

    //  this.getEmittedData()

    //  console.log(this.$route.params);

    // this.emitter.on('empDocumentData', (evt:any) => {
    //     this.fieldjsons=evt;
    //     console.log("inside", this.fieldjsons);
    //         })
    // console.log("val", this.fieldjsons);
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.userDetails = userDetails
    this.empId = this.userDetails.employeeId
    OnbService.getOnboardingDocuments(this.empId).then((response: any) => {
      response.data.data.forEach((item: any) => {
        item.employeeDocumentsList.forEach((item: any) => {
          this.empDocList.push(item)
          console.log(this.empDocList)
        })
      })
      const templateId = sessionStorage.getItem('templateId')

      this.empDocList.filter((doc: any) => {
        if (doc.templatePackage.template.templateId == templateId) {
          this.empDocId = doc.employeeDocumentId
          console.log(this.empDocId)
        }
      })

      //          this.empDocList[1].filter((item:any)=>{
      // const templateId=localStorage.getItem('templateId')
      //           console.log(templateId);
      //           console.log(item);

      //           // if(item.templatePackage.template.templateId == templateId ){
      //           //       this.empDocId=item.employeeDocumentId
      //           //       console.log(this.empDocId);
      //           // }

      //         // //  this.agreementName=item.document.documentName
      //         //  this.templateId=item.templatePackage.template.extTemplateId
      //         //  this.customFields=item.templatePackage.template.templateFieldMapping.fieldJson
      //         // this.customFieldJson= JSON.parse(item.templatePackage.template.templateFieldMapping.fieldJson).fieldData
      //          })
      //          console.log(this.customFieldJson);
    })
  }
}
</script>

<style scoped>
/* .remove-style{
    background: none;
    background-color: none;
    color: black;
    border: none;
} */
.inputTxt {
  height: 40px;
  border-radius: 5px;
  border-color: #0070cd;
}
.grid {
  display: grid;
}
.ownradio {
  padding-top: 0.5rem;
}
.ownLabel {
  padding-top: 3px;
  margin-left: 10px;
}
</style>
