<template>
  <Toast />
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner></ProgressSpinner>
  </div>
  <div class="panel">
    <Panel :header="$t('workExperienceLabel')">
      <Form ref="workForm">
        <div v-for="(item, index) in WorkExperienceform" :key="index">
          <div v-if="item.isDeleted != 'Y'">
            <Fieldset :legend="$t('workExperienceLabel')">
              <div class="grid p-fluid">
                <div class="field col-12 md:col-4 lg:col-4 mb-0">
                  <label :class="item.companyValidity ? 'error' : 'valid'"
                    >{{ $t('company') }}<span class="text-danger">*</span></label
                  >
                  <InputText
                    :class="item.companyValidity ? 'error' : 'valid'"
                    @input="validateCompanyName(item)"
                    :maxlength="50"
                    type="text"
                    v-model.trim="item.companyName"
                    :disabled="disableField"
                  />
                  <small v-if="item.companyValidity" class="error">{{
                    item.companyValidity
                  }}</small>
                </div>
                <div class="field col-12 md:col-4 lg:col-4 mb-0">
                  <label>{{ $t('location') }}</label>
                  <InputText
                    :maxlength="50"
                    type="text"
                    v-model.trim="item.locationName"
                    :disabled="disableField"
                  />
                </div>
                <div class="field col-12 md:col-4 lg:col-4 mb-0">
                  <label :class="item.jobtitleValidity ? 'error' : 'valid'"
                    >{{ $t('jobTitle') }}<span class="text-danger">*</span></label
                  >
                  <InputText
                    :class="item.jobtitleValidity ? 'error' : 'valid'"
                    @input="validateJobTitle(item)"
                    :maxlength="50"
                    type="text"
                    v-model.trim="item.jobTitle"
                    :disabled="disableField"
                  />
                  <small v-if="item.jobtitleValidity" class="error">{{
                    item.jobtitleValidity
                  }}</small>
                </div>
                <div class="col-12 md:col-10 lg:col-12 mb-0 textarea1">
                  <label :class="item.jobAndRolesvalidity ? 'error' : 'valid'"
                    >{{ $t('jobRolesResponsibility') }}<span class="text-danger">*</span>
                  </label>
                  <TextArea
                    :class="item.jobAndRolesvalidity ? 'error' : 'valid'"
                    autoResize
                    maxlength="1000"
                    @input="validateJobRoles(item)"
                    type="text"
                    v-model.trim="item.responsibilities"
                    :disabled="disableField"
                  />
                  <small v-if="item.jobAndRolesvalidity" class="error">{{
                    item.jobAndRolesvalidity
                  }}</small>
                </div>
                <div class="field col-12 md:col-4 lg:col-4 mb-0">
                  <label :class="item.statusValidity ? 'error' : 'valid'"
                    >{{ $t('currentlyWorkingHere') }}<span class="text-danger">*</span></label
                  >
                  <Dropdown
                    :class="item.statusValidity ? 'error' : 'valid'"
                    v-model.trim="item.currentlyWorkingHere"
                    :options="currentlyWorkingHere1"
                    optionLabel="name"
                    optionValue="id"
                    @change="validateStatus(item)"
                    :placeholder="$t('selectStatus')"
                    :disabled="disableField"
                  />
                  <small v-if="item.statusValidity" class="error">{{ item.statusValidity }}</small>
                </div>
                <div
                  class="field col-12 md:col-3 lg:col-4 mb-0"
                  v-show="item.currentlyWorkingHere != 1"
                >
                  <label :class="item.fromValidity ? 'error' : 'valid'"
                    >{{ $t('from') }}<span class="text-danger">*</span></label
                  >
                  <Calendar
                    :maxDate="minDate"
                    :class="item.fromValidity ? 'error' : 'valid'"
                    @click="validateFrom(item)"
                    @date-select="validateFrom(item)"
                    showIcon
                    lass="small-calendar"
                    focused="true"
                    dateFormat="mm/dd/yy"
                    v-model="item.startDate"
                    :disabled="disableField"
                  />
                  <small v-if="item.fromValidity" class="error">{{ item.fromValidity }}</small>
                </div>
                <div
                  class="field col-12 md:col-3 lg:col-4 mb-0"
                  v-show="item.currentlyWorkingHere != 1"
                >
                  <label :class="item.toValidity ? 'error' : 'valid'"
                    >{{ $t('to') }}<span class="text-danger">*</span></label
                  >
                  <Calendar
                    :minDate="toMinDate"
                    :class="item.toValidity ? 'error' : 'valid'"
                    @click="validateTo(item)"
                    @date-select="validateTo(item)"
                    showIcon
                    class="small-calendar"
                    dateFormat="mm/dd/yy"
                    v-model="item.endDate"
                    :disabled="disableField"
                  />
                  <small v-if="item.toValidity" class="error">{{ item.toValidity }}</small>
                </div>
              </div>

              <div class="remove-form">
                <span>
                  <Button
                    v-if="!disableField && !isConsultantInfoPage"
                    type="button"
                    :label="$t('add')"
                    icon="pi pi-plus"
                    @click="addRow"
                  ></Button>
                </span>
                <span>
                  <Button
                    v-if="!disableField && !isConsultantInfoPage"
                    type="button"
                    class="btn"
                    icon="pi pi-trash"
                    :label="$t('delete')"
                    @click="removeRow(index)"
                  ></Button>
                </span>
              </div>
            </Fieldset>
          </div>
        </div>
      </Form>
    </Panel>
  </div>
  <div
    style="display: flex; justify-content: flex-end; column-gap: 10px; margin-top: 15px"
    v-if="!disableField && !isConsultantInfoPage"
  >
    <Button :label="$t('previous')" @click="goToEducational" />
    <Button :label="$t('saveAndExit')" @click="saveWorkExperience" />
    <Button :label="$t('next')" @click="saveWorkExperience('next')" />
  </div>
</template>

<script lang="ts">
import { ErrorMessages } from '../shared/constant/error-messages-constants'
import OnbService from '../shared/services/OnbService'
import { useToast } from 'primevue/usetoast'
import moment from 'moment'
import { reactive } from 'vue'
import { GLOBAL_ENUM } from '../shared/enum/global.enum'
import { CONSULTANT_CONST_INFO } from '../shared/constant/consultant_const_info'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import { FILE_PATH } from '../shared/constant/file-path'
export default {
  name: 'WorkExperience',
  props: {
    disableField: Boolean,
    ConsultId: Number
  },
  inject: ['isConsultantInfoPage'],
  components: {},
  data() {
    return {
      empId: '',
      employeeId: '',
      maxDate: new Date(new Date().getFullYear(), 0, 1),
      forms: [],
      excuseDeletedWorkExpForm: false,
      showSpinner: false,
      companyValidityArray: [],
      minDate: new Date(),
      toMinDate: new Date(),
      toast: useToast(),
      educationalSubTaskObj: {},
      personalInfoSubTaskObj: {},
      previewSubTaskObj: {},
      workExperinceSubTaskObj: {},
      completeProfileSubTaskObj: {},
      createProfileObj: {},
      subTaskPercentage: '',
      WorkExperienceDetails: [],
      errorMsg: ErrorMessages,
      showErrorFromDate: false,
      keysToRemove: [
        'companyValidity',
        'fromValidity',
        'jobtitleValidity',
        'jobAndRolesvalidity',
        'statusValidity',
        'toValidity'
      ],
      currentlyWorkingHere1: [
        { name: 'Yes', id: '1' },
        { name: 'No', id: '2' }
      ],
      educationalData: [],
      employeeAllData: {
        city: '',
        dateOfBirth: '',
        email: '',
        genderId: '',
        stateId: '',
        countryId: '',
        county: '',
        firstName: '',
        middleName: '',
        lastName: '',
        ssn: '',
        ssnReason: '',
        emergencyPersonName: '',
        emergencyContactNumber: '',
        address1: '',
        address2: '',
        preferredName: '',
        zipcode: '',
        preferredLanguageId: '',
        preferredContactMethodId: '',
        phone2: '',
        phone: '',
        progress: ''
      },
      WorkExperienceform: reactive([]),
      defaultForm: {
        companyName: '',
        jobTitle: '',
        responsibilities: '',
        locationName: '',
        currentlyWorkingHere: 2,
        startDate: '',
        lastDate: '',
        endDate: '',
        employeeWorkHistoryId: '',
        employeeId: this.empId ? this.empId : this.employeeId,
        ownerId: null,
        createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
        modifiedBy: null,
        organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
        createdDate: '11/16/2023 21:40:51.000',
        modifiedDate: null,
        isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
        isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
        externalId: null,
        yearsOfExperience: '',
        companyValidity: '',
        jobtitleValidity: '',
        jobAndRolesvalidity: '',
        statusValidity: '',
        fromValidity: '',
        toValidity: ''
      },
      status: [],
      validationArray: []
    }
  },

  beforeCreate() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.employeeId = userDetails.employeeId
  },
  watch: {
    WorkExperienceform(newValue) {
      this.$emit('updatedWorkExperince', newValue)
    }
  },

  methods: {
    goToEducational() {
      this.$emit('backToEducation', 'education-info')
    },
    addRow() {
      let formsArr = []
      this.WorkExperienceform.filter((item: any) => {
        if (item.isDeleted != CONSULTANT_CONST_INFO.YES) {
          //'Y'
          formsArr.push(item)
        }
      })
      if (formsArr.length < 5) {
        this.WorkExperienceform.push({
          companyName: '',
          jobTitle: '',
          responsibilities: '',
          locationName: '',
          currentlyWorkingHere: 2,
          startDate: '',
          endDate: '',
          lastDate: '',
          employeeWorkHistoryId: '',
          employeeId: this.empId ? this.empId : this.employeeId,
          ownerId: null,
          createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
          modifiedBy: null,
          organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
          createdDate: '11/16/2023 21:40:51.000',
          modifiedDate: null,
          isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
          isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
          externalId: null,
          yearsOfExperience: '',
          companyValidity: '',
          jobtitleValidity: '',
          jobAndRolesvalidity: '',
          statusValidity: '',
          fromValidity: '',
          toValidity: ''
        })
      }
    },
    removeRow(index: any) {
      this.minDate = new Date()
      this.toMinDate = new Date()
      let formsArr = []
      this.WorkExperienceform.filter((item: any) => {
        if (item.isDeleted != CONSULTANT_CONST_INFO.YES) {
          // 'Y'
          formsArr.push(item)
        }
      })
      if (formsArr.length > 1) {
        ;(this.WorkExperienceform[index].isActive = CONSULTANT_CONST_INFO.NO), // 'N'
          (this.WorkExperienceform[index].isDeleted = CONSULTANT_CONST_INFO.YES) //'Y'
      }
    },
    validateFromnToDate() {
      this.WorkExperienceform.map((res: any) => {
        let stdate = new Date(res.startDate)
        let startDate = parseInt(`${stdate.getFullYear()}`)
        let fmdate = new Date(res.endDate)
        let fromDate = parseInt(`${fmdate.getFullYear()}`)
        if (startDate > fromDate) {
          this.showErrorFromDate = true
          this.toast.add({
            severity: 'error',
            summary: 'error',
            detail: this.errorMsg.startDateErrorMsg,
            life: 3000
          })
        } else {
          this.showErrorFromDate = false
        }
      })
    },
    validateCompanyName(field: any) {
      !field.companyName
        ? (field.companyValidity = this.$t('ErrorMessages.mandatory'))
        : (field.companyValidity = '')
    },
    validateJobTitle(field: any) {
      !field.jobTitle
        ? (field.jobtitleValidity = this.$t('ErrorMessages.mandatory'))
        : (field.jobtitleValidity = '')
    },
    validateJobRoles(field: any) {
      !field.responsibilities
        ? (field.jobAndRolesvalidity = this.$t('ErrorMessages.mandatory'))
        : (field.jobAndRolesvalidity = '')
    },
    validateStatus(field: any) {
      !field.currentlyWorkingHere
        ? (field.statusValidity = this.$t('ErrorMessages.mandatory'))
        : (field.statusValidity = '')
      if (field.currentlyWorkingHere == 1) {
        field.startDate = ''
        field.endDate = ''
      }
    },
    validateFrom(field: any) {
      this.toMinDate =
        field.startDate != '' && field.startDate != null ? new Date(field.startDate) : new Date()
      field.startDate == '' || field.startDate == null
        ? (field.fromValidity = this.$t('ErrorMessages.mandatory'))
        : (field.fromValidity = '')
    },
    validateTo(field: any) {
      if (field.endDate != '' && field.endDate != null) {
        field.toValidity = ''
        this.validateFrom(field)
      } else {
        if (field.startDate == '' || field.startDate == null) {
          field.toValidity = this.$t('ErrorMessages.mandatory')
        }
      }
    },
    getWorkexperienceData(id: any) {
      this.showSpinner = true
      OnbService.getDashboardData(id)
        .then((res) => {
          this.employeeAllData = res.data.data
          this.WorkExperienceform = res.data.data.employeeWorkHistory
          if (this.WorkExperienceform == null || this.WorkExperienceform.length == 0) {
            this.WorkExperienceform.push(this.defaultForm)
          }
          this.WorkExperienceform.map((a) =>
            a.startDate != null && a.startDate != '' ? moment(a.startDate).format('YY') : ''
          )
          this.WorkExperienceform.map((a) =>
            a.endDate != null && a.endDate != '' ? moment(a.endDate).format('YY') : ''
          )
          const myProfileInfoTaskObj = res.data.data.employeeTaskDetails[1]
          this.createProfileObj = myProfileInfoTaskObj.taskStatus
          this.educationalSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[1].taskStatus
          this.personalInfoSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[0].taskStatus
          this.workExperinceSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[2].taskStatus
          this.previewSubTaskObj = myProfileInfoTaskObj.subTask.subEmployeeTask[3].taskStatus
          this.completeProfileSubTaskObj =
            myProfileInfoTaskObj.subTask.subEmployeeTask[4].taskStatus
          this.subTaskPercentage = myProfileInfoTaskObj.subTask.percentage
          this.educationalData = res.data.data.educationDetails
          this.WorkExperienceDetails = res.data.data.employeeWorkHistory
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.error('There was an error!', error)
        })
    },
    getStatus() {
      let openStatusObj = this.status[0] //---> open status
      let completeStatusObj = this.status[3] //---> complete status
      let progressStatusObj = this.status[1] //---> progress status
      let submittedObj = this.status[2] //---> submitted status
    },
    getSignupStatus() {
      let completeStatusObj = this.status[3] //---> complete status
      return completeStatusObj
    },
    saveWorkExperience(getNext?: any) {
      if (getNext != CONSULTANT_CONST_INFO.GET_NEXT) {
        //'next'
        this.showSpinner = true
      }

      const invalidWorkExpType = this.WorkExperienceform.filter((item: any) => {
        if (getNext == CONSULTANT_CONST_INFO.GET_NEXT) {
          //'next'
          this.validateCompanyName(item)
          this.validateJobRoles(item)
          this.validateJobTitle(item)
          this.validateStatus(item)
          if (item.currentlyWorkingHere != 1) {
            this.validateFrom(item)
            this.validateTo(item)
          }
          this.validateFromnToDate()
        }
        if (item.currentlyWorkingHere != 1) {
          return (
            (item.companyName == '' ||
              item.companyName == null ||
              item.jobTitle == '' ||
              item.jobTitle == null ||
              item.responsibilities == '' ||
              item.responsibilities == null ||
              item.currentlyWorkingHere == '' ||
              item.currentlyWorkingHere == null ||
              item.startDate == '' ||
              item.startDate == null ||
              item.endDate == '' ||
              item.endDate == null) &&
            item.isDeleted == CONSULTANT_CONST_INFO.NO // 'N'
          )
        } else {
          return (
            item.companyName == '' ||
            item.companyName == null ||
            item.jobTitle == '' ||
            item.jobTitle == null ||
            item.responsibilities == '' ||
            item.responsibilities == null ||
            item.currentlyWorkingHere == '' ||
            (item.currentlyWorkingHere == null && item.isDeleted == CONSULTANT_CONST_INFO.NO) // 'N'
          )
        }
      })
      this.WorkExperienceform.map((a) => {
        if (a.startDate != null && a.startDate != '') {
          let date = new Date(a.startDate)
          let dateMDY = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`
          a.startDate = dateMDY
        }
      })
      this.WorkExperienceform.map((a) => {
        if (a.endDate != null && a.endDate != '') {
          let date = new Date(a.endDate)
          let dateMDY = `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`
          a.endDate = dateMDY
        }
      })
      const { keysToRemove, WorkExperienceform } = this
      const modifiedArray = WorkExperienceform.map((obj) => {
        const newObj = Object.fromEntries(
          Object.entries(obj).filter(([key]) => !keysToRemove.includes(key))
        )
        return newObj
      })

      if (
        (invalidWorkExpType.length <= 0 && !this.showErrorFromDate) ||
        getNext != CONSULTANT_CONST_INFO.GET_NEXT
      ) {
        //'next'
        this.showSpinner = true
        let payload = {
          employeeId: this.empId,
          ownerId: 1,
          createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
          modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, // 1,
          dateOfBirth:
            this.employeeAllData.dateOfBirth != null && this.employeeAllData.dateOfBirth != ''
              ? moment(this.employeeAllData.dateOfBirth).format('MM/DD/YYYY')
              : '',
          departmentId: null,
          locationId: null,
          organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
          genderId: this.employeeAllData.genderId,
          stateId: this.employeeAllData.stateId,
          countryId: this.employeeAllData.countryId,
          county: this.employeeAllData.county,
          secondaryStateId: null,
          secondaryCountryId: null,
          createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
          modifiedDate: '11/22/2023 23:58:46.000',
          isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
          isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
          secondaryAddress1: null,
          secondaryAddress2: null,
          firstName: this.employeeAllData.firstName,
          middleName: this.employeeAllData.middleName,
          lastName: this.employeeAllData.lastName,
          ssn: this.employeeAllData.ssn,
          ssnReason: this.employeeAllData.ssnReason,
          emergencyPersonName: this.employeeAllData.emergencyPersonName,
          emergencyContactNumber: this.employeeAllData.emergencyContactNumber,
          email: this.employeeAllData.email,
          email1: null,
          address1: this.employeeAllData.address1,
          address2: this.employeeAllData.address2,
          externalId: null,
          preferredName: this.employeeAllData.preferredName,
          phone: this.employeeAllData.phone,
          phone2: this.employeeAllData.phone2,
          city: this.employeeAllData.city,
          zipcode: this.employeeAllData.zipcode,
          scondaryZipcode: null,
          preferredLanguageId: this.employeeAllData.preferredLanguageId,
          preferredContactMethodId: this.employeeAllData.preferredContactMethodId,
          educationDetails: this.educationalData,
          employeeWorkHistory: modifiedArray,
          employeeTaskDetails: [
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[0].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[0].employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
              task: {
                taskId: GLOBAL_ENUM.TASK_ONE_ID, // 1,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                taskName: CONSULTANT_CONST_INFO.CONSULTANT_SIGNUP, //'Consultant Signup',
                externalId: null,
                subTask: null
              },
              taskStatus: this.getSignupStatus(),
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, //1,
              createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[1].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[1].employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
              task: {
                taskId: GLOBAL_ENUM.TASK_TWO_ID, //  2,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                taskName: CONSULTANT_CONST_INFO.CREATE_PROFILE, //'Create Profile',
                externalId: null,
                subTask: null
              },
              taskStatus: this.createProfileObj,
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
              comments: null,
              externalId: null,
              subTask: {
                percentage: this.subTaskPercentage,
                subEmployeeTask: [
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[0].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[0]
                          .employeeTaskId
                      : '',
                    employeeId: this.empId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_SIX_ID, //  6,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                      createdDate: '11/16/2023 21:40:51.000', //moment(new Date()).format('MM/DD/YYYY'),
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                      taskName: CONSULTANT_CONST_INFO.PERSONAL_INFO, //'Personal Information',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.personalInfoSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[1].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[1]
                          .employeeTaskId
                      : '',
                    employeeId: this.empId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_SEVEN_ID, //  7,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                      createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                      taskName: CONSULTANT_CONST_INFO.EDUCATION, //'Education',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.educationalSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, //1,
                    createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[2].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[2]
                          .employeeTaskId
                      : '',
                    employeeId: this.empId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_EIGHT_ID, //  8,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                      createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                      taskName: CONSULTANT_CONST_INFO.WORK_EXPERIENCE, //'Work Experience',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus:
                      getNext == CONSULTANT_CONST_INFO.GET_NEXT //'next'
                        ? this.status[3]
                        : this.workExperinceSubTaskObj
                          ? this.workExperinceSubTaskObj
                          : this.status[1],
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[3].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[3]
                          .employeeTaskId
                      : '',
                    employeeId: this.empId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_NINE_ID, //  9,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                      createdDate: '11/16/2023 21:40:51.000', //moment(new Date()).format('MM/DD/YYYY'),
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
                      taskName: CONSULTANT_CONST_INFO.PREVIEW, //'Preview',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.previewSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  },
                  {
                    employeeTaskId: this.employeeAllData.employeeTaskDetails[1].subTask
                      .subEmployeeTask[4].employeeTaskId
                      ? this.employeeAllData.employeeTaskDetails[1].subTask.subEmployeeTask[4]
                          .employeeTaskId
                      : '',
                    employeeId: this.empId,
                    organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                    task: {
                      taskId: GLOBAL_ENUM.TASK_TEN_ID, //  10,
                      taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                      ownerId: null,
                      createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
                      modifiedBy: null,
                      parentTaskId: GLOBAL_ENUM.DEFAULT_PARENTTASK_ID, // 2,
                      organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                      createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                      modifiedDate: null,
                      isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                      isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
                      taskName: CONSULTANT_CONST_INFO.COMPLETE_PROFILE, //'Complete Profile',
                      externalId: null,
                      subTask: null
                    },
                    taskStatus: this.completeProfileSubTaskObj,
                    ownerId: null,
                    createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                    modifiedBy: null,
                    assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
                    createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                    modifiedDate: null,
                    isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                    isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                    comments: null,
                    externalId: null,
                    subTask: null
                  }
                ]
              }
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[2].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[2].employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
              task: {
                taskId: GLOBAL_ENUM.TASK_THREE_ID, //  3,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
                taskName: CONSULTANT_CONST_INFO.INITIATE_ONB_STEPS, //'Initiate Onboarding Steps',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, // 2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN //'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, //  'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[3].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[3].employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
              task: {
                taskId: GLOBAL_ENUM.TASK_FOUR_ID, //  4,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, //'N',
                taskName: CONSULTANT_CONST_INFO.SUBMIT_ONB_DOCUMENTS, //'Submit Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, //  2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', //moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN //'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //  1,
              modifiedBy: null,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/16/2023 21:40:51.000', //moment(new Date()).format('MM/DD/YYYY'),
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData.employeeTaskDetails[4].employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[4].employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
              task: {
                taskId: GLOBAL_ENUM.TASK_FIVE_ID, // 5,
                taskTypeId: GLOBAL_ENUM.DEFAULT_TASKTYPE_ID, //1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, //'Y',
                isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
                taskName: CONSULTANT_CONST_INFO.ONB_APPROVED, //'Onboarding Approved',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: GLOBAL_ENUM.DEFAULT_STATUS_ID, // 1,
                ownerId: null,
                createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, // 1,
                modifiedBy: null,
                statusTypeId: GLOBAL_ENUM.DEFAULT_STATUSTYPE_ID, //  2,
                organizationId: GLOBAL_ENUM.DEFAULT_ORGANIZATION_ID, // 1,
                createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
                modifiedDate: null,
                isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
                name: CONSULTANT_CONST_INFO.STATUS_OPEN // 'Open'
              },
              ownerId: null,
              createdBy: GLOBAL_ENUM.DEFAULT_CREATED_BY_ID, //1,
              modifiedBy: GLOBAL_ENUM.DEFAULT_MODIFIED_BY_ID, // 1,
              assignedTo: GLOBAL_ENUM.DEFAULT_ASSIGNED_TO_ID, // 1,
              createdDate: '11/16/2023 21:40:51.000', // moment(new Date()).format('MM/DD/YYYY'),
              modifiedDate: null,
              isActive: CONSULTANT_CONST_INFO.YES, // 'Y',
              isDeleted: CONSULTANT_CONST_INFO.NO, // 'N',
              comments: null,
              externalId: null,
              subTask: null
            }
          ],
          user: null,
          progress: this.employeeAllData.progress
        }

        //let url = 'https://ol-npqaonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/employee/save';
        OnbService.employeeSave(payload)
          .then((response) => {
            this.subTaskPercentage =
              response.data.data.data.employeeTaskDetails[1].subTask.percentage
            this.$emit('subTaskPercentageEducation', this.subTaskPercentage)
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.workExperienceUpdate'),
              life: 2000
            })
            setTimeout(() => {
              if (response.data.data && getNext == CONSULTANT_CONST_INFO.GET_NEXT) {
                //'next'
                this.$emit('navigateToPreview', 'preview')
                this.emitter.emit('setPreviewTabActive', { eventContent: 'preview-active' })
              }
              if (response.data.data && getNext != CONSULTANT_CONST_INFO.GET_NEXT) {
                //'next'
                this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD) //'/onb/consultant-dashboard'
              }
            }, 2000)
          })
          .finally(() => {
            setTimeout(() => {
              this.showSpinner = false
            }, 1000)
          })
          .catch((error) => {
            this.showSpinner = false
            console.error(error.message)
          })
      }
    }
  },
  mounted() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.empId = userDetails.employeeId
    this.employeeId = userDetails.employeeId
    OnbService.getStatus().then((response) => {
      this.status = response.data.data[1].status
    })
    if (!this.ConsultId) {
      this.getWorkexperienceData(this.empId)
    }

    if (this.ConsultId) {
      OnbService.getEmployeeData(this.ConsultId).then((response: any) => {
        if (this.WorkExperienceform == null || this.WorkExperienceform.length == 0) {
          this.WorkExperienceform.push(this.defaultForm)
        }
        this.WorkExperienceform.map((a) =>
          a.startDate != null && a.startDate != '' ? moment(a.startDate).format('YY') : ''
        )
        this.WorkExperienceform.map((a) =>
          a.endDate != null && a.endDate != '' ? moment(a.endDate).format('YY') : ''
        )

        this.WorkExperienceform = response.data.data.employeeWorkHistory
      })
    }
  }
}
</script>

<style scoped>
.textarea1 {
  font-weight: 700;
  margin-bottom: 3px;
  color: #777;
  font-size: 12px;
  display: flex;
  flex-direction: column;
}

textarea {
  margin-top: 12px;
}

.error {
  color: red;
  border-color: red;
}

.error-message {
  color: red;
}

.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

.add-form {
  display: flex;
  justify-content: flex-end;
  position: relative;
  bottom: 4px;
  right: 30px;
}

.btn {
  background-color: red;
  border: none;
}

.remove-form {
  display: flex;
  justify-content: flex-end;
  position: relative;
  bottom: 6px;
  margin-top: 10px;
  column-gap: 15px;
}
</style>
