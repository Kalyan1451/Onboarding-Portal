<template>
  <div class="background-card">
    <Toast />
    <div
      :class="[
        showSuccessMsg == '' && showErrorMsg == '' && !isPasswordmatched
          ? null
          : 'show-error-message',
        'total-card'
      ]"
    >
      <div class="language">
        <SplitButton
          class="mr-3 splitButton"
          :label="$t('selectLanguage')"
          icon="pi pi-language"
          :model="item"
        />
        <!-- Translate -->
        <!-- <select v-model="selectedLanguage" @change="changeLanguage">
          <option :value="null" disabled hidden>ln</option>
          <option value="en">English</option>
          <option value="es">Spanish</option>
        </select> -->
      </div>
      <div>
        <Card>
          <template #content>
            <div class="flex flex-column md:flex-row">
              <div>
                <!-- <img class="login-logo" src="../assets/logo 1.png" /> -->
                <img class="login-logo" :src="getLogoPath(logoUrl)" />
                <h2 class="welcomeText">{{ $t('welcome') }}</h2>
                <h1 class="onboardingText">{{ $t('onboardingPortal') }}</h1>
                <!-- <h1>{{ $t('onboardingPortal') }}</h1> -->
              </div>
              <div class="w-full md:w-1">
                <img
                  src="../assets/images/line-10.svg"
                  class="hidden md:flex"
                  alt=""
                  width="1.5%"
                  height="98%"
                />
                <!-- <Divider layout="vertical" type="dashed" class="hidden md:flex"></Divider> -->
                <Divider
                  layout="horizontal"
                  type="dashed"
                  class="flex md:hidden"
                  align="center"
                ></Divider>
              </div>
              <div
                v-if="isResetPassword"
                class="w-full md:w-8 flex flex-column align-items-center justify-content-center gap-2 py-0"
              >
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <p class="reset-pass-text">{{ $t('resetpasswords') }}</p>
                </div>
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <i
                      class="pi pi-envelope absolute top-2/4 -mt-2 ml-2 text-surface-400 dark:text-surface-600"
                    />
                    <InputText
                      class="login-input"
                      type="email"
                      pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                      required
                      maxlength="200"
                      v-model="registeredEmail"
                      :placeholder="$t('emailplaceholderforgot')"
                      :disabled="true"
                    />
                  </span>
                </div>
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <i class="pi pi-lock"></i>
                    <span class="p-input-icon-right">
                      <i v-if="showEye" class="pi pi-eye" @click="switchVisibility"></i>
                      <i v-if="showSlash" class="pi pi-eye-slash" @click="switchVisibility"></i>
                      <InputText
                        class="login-input"
                        :type="passwordFieldType"
                        required
                        v-model="newPassword"
                        :placeholder="$t('newpswdplaceholder')"
                      />
                    </span>
                  </span>
                </div>
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <i class="pi pi-lock"></i>
                    <span class="p-input-icon-right">
                      <i
                        v-if="showConfirmEye"
                        class="pi pi-eye"
                        @click="switchConfirmVisibility"
                      ></i>
                      <i
                        v-if="showConfirmSlash"
                        class="pi pi-eye-slash"
                        @click="switchConfirmVisibility"
                      ></i>
                      <InputText
                        class="login-input"
                        :type="confirmPasswordFieldType"
                        required
                        v-model="confirmPassword"
                        :placeholder="$t('confirmswdplaceholder')"
                      />
                    </span>
                  </span>
                </div>
                <p class="designtext">{{ this.$t('pwdCriteria.PasswordReq') }}</p>
                <!-- flex flex-wrap justify-content-center align-items-center">
               <div> -->
                <div class="pass-align">
                  <div>
                    <p class="designtextpara">
                      <i
                        :class="
                          hasUppercase && hasLowercase
                            ? 'pi pi-check-circle ulCase'
                            : 'pi pi-check-circle'
                        "
                      ></i
                      ><small class="smallclass">{{ this.$t('pwdCriteria.upperLower') }}</small>
                    </p>
                    <p class="designtextpara" style="float: left">
                      <i :class="hasNumber ? 'pi pi-check-circle number' : 'pi pi-check-circle'"></i
                      ><small class="smallclass">{{ this.$t('pwdCriteria.includeNumber') }}</small>
                    </p>
                  </div>
                  <div class="validText">
                    <p class="designtextpara" style="margin-left: -1.5rem">
                      <i
                        :class="hasSpecialChar ? 'pi pi-check-circle symbol' : 'pi pi-check-circle'"
                      ></i
                      ><small class="smallclass">{{ this.$t('pwdCriteria.includeSymbol') }}</small>
                    </p>
                    <p class="designtextpara">
                      <i
                        :class="
                          newPassword.length >= 8 ? 'pi pi-check-circle min8' : 'pi pi-check-circle'
                        "
                      ></i>
                      <small class="smallclass">{{ this.$t('pwdCriteria.minChar') }}</small>
                    </p>
                  </div>
                </div>
                <!-- <div>
              <small v-if="isPasswordmatched" :class="{ 'p-invalid': isPasswordmatched }">{{
                $t('ErrorMessages.passwordmatched')
              }}</small>
            </div> -->

                <div>
                  <Button
                    class="forgot-button"
                    :label="$t('resetpasword')"
                    :disabled="!newPassword || !confirmPassword || !passwordCriteriaMet"
                    @click="changePassword()"
                    severity="secondary"
                  />
                </div>
              </div>
              <div
                v-if="!isResetPassword"
                class="w-full md:w-8 flex flex-column align-items-center justify-content-center gap-3 py-0"
              >
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <p class="reset-pass-text">{{ $t('forgotpasswords') }}</p>
                </div>
                <div class="reser-para">
                  <div>{{ $t('forgotpasswordpara1') }}</div>
                  <div>{{ $t('forgotpasswordpara2') }}</div>
                </div>
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <i
                      class="pi pi-envelope absolute top-2/4 -mt-2 ml-2 text-surface-400 dark:text-surface-600"
                    />
                    <InputText
                      class="login-input"
                      type="email"
                      pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                      required
                      maxlength="200"
                      v-model="resetEmailAddress"
                      :placeholder="$t('emailplaceholder')"
                    />
                  </span>
                </div>

                <div>
                  <small v-if="isPasswordmatched" :class="{ 'p-invalid': isPasswordmatched }">{{
                    $t('ErrorMessages.passwordmatched')
                  }}</small>
                </div>

                <div>
                  <Button
                    :label="$t('sendrequest')"
                    class="forgot-button"
                    @click="sendresetLink()"
                    :disabled="!resetEmailAddress"
                  />
                </div>
              </div>
            </div>
          </template>
        </Card>
        <Card v-if="isInnovaRoute">
          <template #content>
            <img src="../assets/logo 1.png" />
            <Divider />
            <h2>{{ $t('onboardingPortal') }}</h2>
            <Divider />
            <div>
              <Button :label="$t('loginWithSSO')" @click="SignIn" />
            </div>
          </template>
        </Card>
      </div>
      <div class="progress-spinner" v-if="showSpinner">
        <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
      </div>
      <!-- <div v-if="showSuccessMsg">
      <Message severity="success">{{ showSuccessMsg }}</Message>
    </div> -->
      <div v-if="showSuccessMsg" class="reset-password-success-message">
        <Message severity="success" @close="showSuccessMsg = ''">
          <div class="error-header">{{ $t('successMessages.success') }}</div>
          <div class="error-message">{{ showSuccessMsg }}</div>
        </Message>
      </div>
      <div v-else-if="showErrorMsg || isPasswordmatched" class="forgot-password-error-message">
        <Message severity="error" @close="showErrorMsg = ''">
          <div class="error-header">{{ $t('loginAlert') }}</div>
          <div class="error-message">
            {{ isPasswordmatched ? $t('ErrorMessages.passwordmatched') : showErrorMsg }}
          </div>
        </Message>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import OnbService from '../shared/services/OnbService'
import { useToast } from 'primevue/usetoast'
import { FILE_PATH } from '../shared/constant/file-path'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import { useProxyDataStore } from '@/stores/proxy-data'
import { computed, ref } from 'vue'
import { useCounterStore } from '@/stores/counter'
const storeEmail = useCounterStore()
export default {
  setup() {
    const proxyDataStore: any = useProxyDataStore()
    const loginLogo = ref(null)
    // logUrls.value = proxyDataStore.getLogos;
    // loginLogo.value = logUrls.value.filter((el: any) => el.imageName == 'loginLogo');
    // logUrls = proxyDataStore.logoUrls;
    // console.log("loginLogo", loginLogo.value);
    // console.log("getLogos", logUrls);
    const logoUrl = computed(() => proxyDataStore.$state.loginLogo)
    return {
      proxyDataStore,
      logoUrl,
      loginLogo
    }
  },
  data() {
    return {
      userTrackIdd: null,
      showErrorMsg: '',
      showSuccessMsg: '',
      passwordFieldType: 'password',
      confirmPasswordFieldType: 'password',
      showEye: false,
      showSlash: true,
      showConfirmEye: false,
      showConfirmSlash: true,
      password: '',
      confirmPassword: '',
      hasUppercase: false,
      hasLowercase: false,
      hasNumber: false,
      hasSpecialChar: false,
      passwordCriteriaMet: true,
      resetPassword: false,
      resetEmailAddress: '',
      isResetPassword: false,
      registeredEmail: '',
      newPassword: '',
      confirmPassword: '',
      showSpinner: false,
      showPasswordIcon: false,
      isPasswordmatched: false,
      userTrackId: '',
      toast: useToast(),
      token: '',
      item: [
        {
          label: 'English',
          command: ($event: any) => {
            this.changeLanguage('en')
          }
        },
        {
          label: 'Spanish (español) ',
          command: ($event: any) => {
            this.changeLanguage('sp')
          }
        },
        {
          label: 'Francais (French)',
          command: ($event: any) => {
            this.changeLanguage('fr')
          }
        }
      ]
    }
  },
  methods: {
    checkResetToken() {
      OnbService.tokenValidation(this.userTrackId, this.token)
        .then((res) => {
          if (res.data.data.Token == 'URL expired') {
            this.showErrorMsg = res.data.data.Token
            this.showSuccessMsg = ''
            // this.toast.add({
            //   severity: 'error',
            //   summary: this.$t('ErrorMessages.error'),
            //   detail: res.data.data.Token,
            //   life: 2000
            // })
          } else if (res.data.data.Token == 'Invalid token') {
            this.showErrorMsg = this.$t('ErrorMessages.resetPwd')
            this.showSuccessMsg = ''
            // this.toast.add({
            //   severity: 'error',
            //   summary: this.$t('ErrorMessages.error'),
            //   detail: this.$t('ErrorMessages.resetPwd'),
            //   life: 2000
            // })
          } else {
            this.registeredEmail = res.data.data.email
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error: any) => {
          this.showSpinner = false
          console.log(error)
        })
    },
    switchVisibility() {
      this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password'
      if (this.passwordFieldType === 'password') {
        this.showSlash = true
        this.showEye = false
      } else {
        this.showEye = true
        this.showSlash = false
      }
    },
    switchConfirmVisibility() {
      this.confirmPasswordFieldType =
        this.confirmPasswordFieldType === 'password' ? 'text' : 'password'
      if (this.confirmPasswordFieldType === 'password') {
        this.showConfirmSlash = true
        this.showConfirmEye = false
      } else {
        this.showConfirmEye = true
        this.showConfirmSlash = false
      }
    },
    getLogoPath(img: string): string {
      const defaultLogoUrl: string = '/innova/loginLogo.png'
      // img = defaultLogoUrl
      img = img ? img : defaultLogoUrl
      return img ? new URL(img, import.meta.url).href : ''
    },
    changeLanguage(event: any) {
      console.log('event-change', event)
      this.$i18n.locale = event
      sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.SELECTED_LANGUAGE, event) //'selectedLanguage'
    },
    sendresetLink() {
      // this.resetPassword = false
      OnbService.getResetPasswordLink(this.resetEmailAddress).then((res: any) => {
        if (res.data.data == 'User is not registered in Employee table') {
          this.showErrorMsg = this.$t('invalidErrorPopUpObs')
          this.showSuccessMsg = ''
          // this.toast.add({
          //   severity: 'error',
          //   summary: 'error',
          //   detail: this.$t('invalidErrorPopUpObs'),
          //   life: 3000
          // })
        } else {
          this.showSuccessMsg = this.$t('successMessages.sendresetlinks')
          this.showErrorMsg = ''
          // this.toast.add({
          //   severity: 'success',
          //   summary: this.$t('successMessages.success'),
          //   detail: this.$t('successMessages.sendresetlinks'),
          //   life: 3000
          // })
        }
      })
      this.resetEmailAddress = ''
    },
    closePopup() {
      this.resetPassword = false
      this.resetEmailAddress = ''
    },

    showpasswordIcon() {
      this.showPasswordIcon = true
    },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword
    },
    changePassword() {
      if (this.newPassword != this.confirmPassword) {
        this.isPasswordmatched = true
      } else {
        let payload = {
          emailId: this.registeredEmail,
          newPassword: this.newPassword,
          conformPassword: this.confirmPassword
        }
        // Service updates the Database with new Password
        OnbService.saveResetPassword(payload)
          .then((res: any) => {
            this.showSuccessMsg = this.$t('successMessages.passwordChanged')
            this.showErrorMsg = ''
            this.isPasswordmatched = true
            // this.toast.add({
            //   severity: 'success',
            //   summary: this.$t('successMessages.success'),
            //   detail: this.$t('successMessages.passwordChanged'),
            //   life: 3000
            // })
            setTimeout(() => {
              this.$router.push(FILE_PATH.LOGIN) // '/login'
            }, 2000)
          })
          .catch((error: any) => {
            console.log(error)
          })
      }
    }
  },
  watch: {
    newPassword(newVal) {
      // Check if password contains at least one uppercase letter
      this.hasUppercase = /[A-Z]/.test(newVal)

      // Check if password contains at least one lowercase letter
      this.hasLowercase = /[a-z]/.test(newVal)

      // Check if password contains at least one number
      this.hasNumber = /\d/.test(newVal)

      // Check if password contains at least one special character
      this.hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(newVal)

      // Update overall password criteria validation
      this.passwordCriteriaMet =
        this.hasUppercase &&
        this.hasLowercase &&
        this.hasNumber &&
        this.hasSpecialChar &&
        newVal.length >= 8
    }
  },
  mounted() {
    this.userTrackId = this.$route.params.userTrackerId
    this.token = this.$route.params.token
    this.userTrackIdd = this.$route.params.trackId
    // console.log("The details of the user are", this.trackEmail)
    if (this.userTrackIdd) {
      this.isResetPassword = true
      this.registeredEmail = storeEmail.email
    }
    if (this.userTrackId && this.token) {
      this.isResetPassword = true
    }
    this.showSpinner = true

    //service validates the token
    setTimeout(() => {
      this.checkResetToken()
    }, 2000)
  }
}
</script>

<style scoped lang="scss">
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}
.pass-align {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}
@media (min-width: 456px) {
  .validText {
    margin-right: -1rem;
    margin-left: 3rem;
  }
}
@media (max-width: 457px) {
  .validText {
    margin-right: 1rem;
    margin-left: -2.5rem;
  }
  .pass-align {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
}

.pi-lock {
  margin-left: 8px;
  color: #180583;
}
.pi-eye {
  color: #180583;
}
.pi-eye-slash {
  color: #180583;
}
.pi-check-circle {
  font-weight: bold;
  margin-right: 5px;
}
.pi-check-circle.ulCase {
  color: #00ff00;
  font-weight: bold;
  margin-right: 5px;
}
.pi-check-circle.number {
  color: #00ff00;
  font-weight: bold;
  margin-right: 5px;
}
.pi-check-circle.symbol {
  color: #00ff00;
  font-weight: bold;
  margin-right: 5px;
}
.pi-check-circle.min8 {
  color: #00ff00;
  font-weight: bold;
  margin-right: 5px;
}

.p-password.login-input {
  padding: 0;
}
@media (min-width: 456px) {
  .validText {
    margin-right: 0rem;
    margin-left: 5.5rem;
  }
}
@media (max-width: 457px) {
  .validText {
    margin-right: 1rem;
    margin-left: -1.5rem;
  }
}
@media (max-width: 457px) {
  .pass-align {
    flex-direction: column;
    margin-right: 9rem;
  }
}

@media (max-width: 410px) {
  .pass-align {
    flex-direction: column;
    margin-right: 5rem;
  }
}

.pass-align {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}
.reset-button {
  border: none;
  width: 50%;
  height: 30%;
}

.login-content {
  display: flex;
  flex-direction: column;
  row-gap: 13px;
}

::placeholder {
  color: #305faf;
  font-size: 13px;
  font-weight: 500;
}
a {
  color: #2096cd;
  text-decoration: underline;
}
.pi-envelope {
  color: #180583;
}
/*  */

.icons {
  display: flex;
  justify-content: center;
  column-gap: 40px;
  text-align: center;
}

.icons i {
  font-size: 30px;
}

/*  */

.close-btn {
  background-color: red;
  border: red;
}
.p-invalid {
  color: red;
  font-size: 12px;
  white-space: nowrap;
}
.reset-password {
  width: 220px !important;
}
.smallclass {
  font-weight: 400;
  color: #000000;
  font-size: 10px;
  letter-spacing: 0.22px;
}
.pi-check-circle {
  font-size: 12px;
}

.forgot-password-error-message,
.reset-password-success-message {
  margin: 0 10px;

  .error-header {
    display: flex;
    justify-content: center;
    margin-bottom: 15px;
    font-weight: 600;
    color: #cd0000;
    letter-spacing: 0.2px;
  }

  .error-message {
    display: flex;
    justify-content: center;
    color: black;
    margin-bottom: 1.75rem;
    font-size: 16px;
  }
}

.forgot-password-error-message :deep,
.reset-password-success-message :deep {
  .p-message.p-message-error .p-message-close,
  .p-message.p-message-success .p-message-close {
    color: #000000;
    margin-top: 30px;
    margin-right: 10px;
    height: 15px;
    width: 15px;
  }

  .p-message .p-message-text {
    width: 100%;
  }

  .p-message {
    margin: 0;
    border-radius: 0 0 20px 20px;
  }
  .p-message .p-message-wrapper {
    height: auto;
    width: 100%;
    padding-right: 0.1rem;
    padding-bottom: 0.1rem;
    border-radius: 0 0 20px 20px;
  }
  .p-message .p-icon:not(.p-message-close-icon) {
    display: none;
  }

  .p-message.p-message-error,
  .p-message.p-message-success {
    border: none;
  }
}
.show-error-message :deep {
  .p-card {
    border-radius: 20px 20px 0 0;
    margin-bottom: 0px;
  }
}

.forgot-password-error-message:deep {
  .p-message .p-message-wrapper {
    background-color: #fbcece;
  }
}

.reset-password-success-message :deep {
  .p-message .p-message-wrapper {
    // background-color: green;
  }
}

.forgot-password-error-message {
  .error-header {
    color: #cd0000;
  }
}

.reset-password-success-message {
  .error-header {
    color: green;
  }
}
</style>
