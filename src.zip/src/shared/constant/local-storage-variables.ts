export const LOCAL_STORAGE_VARIABLES = {
  JWT_TOKEN: 'jwtToken',
  USER_DETAILS: 'userDetails',
  LOGGED_IN_USER_NAME: 'loggedInUserName',
  OBS_LAST_LOGIN_DETAILS: 'lastLogindetailsObs',
  ROUTE_INNOVA_TEAM: 'routeInnovaTeam',
  APPTRACKDATA: 'AppTrackData',
  LOGGED_IN_USER_ID: 'loggedInUserId',
  SELECTED_LANGUAGE: 'selectedLanguage'
}
