export const FILE_PATH = {
  LOGIN: '/login',
  CONSULTANT_DASHBOARD: '/onb/consultant-dashboard',
  ONB_SPL: '/onb/onb-spl',
  INITIATE_INFO: '/onb/initiate-info',
  MY_PROFILE: '/onb/my-profile',
  SUBMIT_ONB_DOCS: '/onb/submit-onboarding-docs',
  MY_PROFILE_DATA: 'my-profile-data/',
  ONB_SPL_LOGIN: '/login?userType=innovaTeam',
  CHANGE_PWD: '/change-password/:tackId'
}
