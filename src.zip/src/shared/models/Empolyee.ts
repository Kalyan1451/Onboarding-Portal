export interface Employee {
  employeeId: number
  ownerId: number
  createdBy: number
  modifiedBy: number
  dateOfBirth: Date
  departmentId: number
  locationId: number
  organizationId: number
  genderId: number
  stateId: number
  countryId: number
  secondaryStateId: number
  secondaryCountryId: number
  createdDate: '2024-01-03T07:17:30.676Z'
  modifiedDate: '2024-01-03T07:17:30.676Z'
  isActive: string
  isDeleted: string
  secondaryAddress1: string
  secondaryAddress2: string
  firstName: string
  middleName: string
  lastName: string
  ssn: string
  email: string
  email1: string
  address1: string
  address2: string
  externalId: string
  preferredName: string
  phone: string
  phone2: string
  city: string
  zipcode: string
  scondaryZipcode: string
  preferredLanguageId: number
  preferredContactMethodId: number
  ssnReason: string
  emergencyContactNumber: string
  secondaryCity: string
  county: string
  secondaryCounty: string
  emergencyPersonName: string
  // educationDetails: [
  //   {
  //     employeeEducationId: number,
  //     employeeId: number,
  //     ownerId: number,
  //     createdBy: number,
  //     modifiedBy: number,
  //     gardePercentage: number,
  //     organizationId: number,
  //     createdDate: "2024-01-03T07:17:30.677Z",
  //     modifiedDate: "2024-01-03T07:17:30.677Z",
  //     isActive: string,
  //     isDeleted: string,
  //     externalId: string,
  //     educationType: string,
  //     yearOfPass: string,
  //     city: string,
  //     stateId: number,
  //     countryId: number,
  //     zipCode: string,
  //     universityName: string,
  //     startDate: "2024-01-03T07:17:30.677Z",
  //     endDate: "2024-01-03T07:17:30.677Z"
  //   }
  // ],
  // employeeWorkHistory: [
  //   {
  //     employeeWorkHistoryId: number,
  //     employeeId: number,
  //     ownerId: number,
  //     createdBy: number,
  //     modifiedBy: number,
  //     organizationId: number,
  //     startDate: "2024-01-03T07:17:30.678Z",
  //     endDate: "2024-01-03T07:17:30.678Z",
  //     createdDate: "2024-01-03T07:17:30.678Z",
  //     modifiedDate: "2024-01-03T07:17:30.678Z",
  //     isActive: string,
  //     isDeleted: string,
  //     externalId: string,
  //     companyName: string,
  //     jobTitle: string,
  //     yearsOfExperience: string,
  //     responsibilities: string,
  //     locationName: string,
  //     currentlyWorkingHere: string
  //   }
  // ],
  employeeTaskDetails: [
    {
      employeeTaskId: number
      employeeId: number
      organizationId: number
      task: {
        taskId: number
        taskTypeId: number
        ownerId: number
        createdBy: number
        modifiedBy: number
        parentTaskId: number
        organizationId: number
        createdDate: '2024-01-03T07:17:30.678Z'
        modifiedDate: '2024-01-03T07:17:30.678Z'
        isActive: string
        isDeleted: string
        taskName: string
        externalId: string
        subTask: [string]
      }
      taskStatus: {
        statusId: number
        ownerId: number
        createdBy: number
        modifiedBy: number
        statusTypeId: number
        organizationId: number
        createdDate: '2024-01-03T07:17:30.678Z'
        modifiedDate: '2024-01-03T07:17:30.678Z'
        isActive: string
        name: string
      }
      ownerId: number
      createdBy: number
      modifiedBy: number
      assignedTo: number
      createdDate: '2024-01-03T07:17:30.678Z'
      modifiedDate: '2024-01-03T07:17:30.678Z'
      isActive: string
      isDeleted: string
      comments: string
      externalId: string
      subTask: {
        percentage: number
        subEmployeeTask: [string]
      }
    }
  ]
  // user: {
  //   userId: number,
  //   employeeId: number,
  //   ownerId: number,
  //   createdBy: number,
  //   modifiedBy: number,
  //   organizationId: number,
  //   createdDate: "2024-01-03T07:17:30.678Z",
  //   modifiedDate: "2024-01-03T07:17:30.678Z",
  //   isActive: string,
  //   isDeleted: string,
  //   externalId: string,
  //   password: string
  // },
  progress: number
  // lastLoginDetails: {
  //   trackerId: number,
  //   userId: number,
  //   loginTime: "2024-01-03T07:17:30.678Z",
  //   logoutTime: "2024-01-03T07:17:30.678Z",
  //   ipAddress: string,
  //   isactive: string,
  //   createdDate: "2024-01-03T07:17:30.678Z",
  //   modifiedDate: "2024-01-03T07:17:30.678Z",
  //   ownerId: number,
  //   createdBy: number,
  //   modifiedBy: number,
  //   externalId: string,
  //   isDeleted: string,
  //   organizationId: number
  // }
}
