import { defineStore } from 'pinia'
import axios from 'axios'
import { PublicClientApplication, type Configuration } from '@azure/msal-browser'
// let msalInstance: PublicClientApplication | null = null;
// let proxyUrl: null
let requestObjForApi: null
// let logoUrls: any = [];

export const useProxyDataStore = defineStore('proxyData', {
  // id: 'proxyData',
  state: () => ({
    // proxyUrlData: { "Test": "Test Data" },
    logoUrls: [],
    loginLogo: '',
    navLogo: '',
    proxyUrl: '',
    msalInstanceData: null
  }),
  getters: {
    getLogos: (state) => state.logoUrls,
    getLoginLogo: (state) => {
      // const logoLogin = ''
      return state.logoUrls?.filter((el: any) => el?.imageName == 'loginLogo')[0]?.imagePath
      // return logoLogin
    },
    getNavLogo: (state) => {
      // const logoLogin = ''
      return state.logoUrls?.filter((el: any) => el?.imageName == 'navBarLogo')[0]?.imagePath
      // return logoLogin
    },
    sideBarLogo: (state) => {
      // const logoLogin = ''
      return state.logoUrls?.filter((el: any) => el?.imageName == 'sideBarLogo')[0]?.imagePath
      // return logoLogin
    },

    getProxyUrl: (state) => {
      return state.proxyUrl
    },

    getMsalInstance: (state) => {
      return state.msalInstanceData
    }
  },
  actions: {
    async getProxyData() {
      // console.log("Proxy Data", data)
      const proxyurl = 'https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD/proxyurl'
      //  const proxyurl = "/ONBRD/proxyurl";
      return axios.get(proxyurl).then((res: any) => {
        console.log(res.data)
        const tokenReqData = res.data.appConfig
        this.createMasalInstanceDynamic(tokenReqData)
        this.proxyUrl = res.data.proxyurl
        // console.log('proxyUrl config', proxyUrl);
        // console.log(msalInstance)

        // generateToken(tokenReqData, proxyUrl);

        const url = 'https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD'
        // const url = window.location.href;
        let domain = new URL(url)
        domain = domain.hostname
        const reqUrl = this.getProxyUrl + '/v3/organization?dnsName=' + domain
        console.log('domain', domain)
        axios.get(reqUrl).then((res: any) => {
          // console.log("Res", res);
          const orgId = res.data.orgId
          const msalConfig: any = {
            auth: {
              clientId: res.data.azureDetails.appId,
              authority: res.data.azureDetails.authority,
              // redirectUri: res.data.redirectUrl,
              redirectUri: 'http://localhost:5173',
              postLogoutRedirectUri: '/' // Must be registered as a SPA redirectURI on your app registration
            },
            cache: {
              cacheLocation: 'sessionStorage'
            }
          }
          console.log('msalConfig', msalConfig)
          requestObjForApi = converStringIntoArray(res.data.azureDetails.scopesForBackendApi)
          this.msalInstanceData = new PublicClientApplication(msalConfig as Configuration)
          this.initializMsalInstance()
          sessionStorage.setItem('orgId', orgId)
          this.logoUrls = res.data.imageDetails
          console.log('logoUrls', this.logoUrls)
        })
      })

      function converStringIntoArray(arrayString: any) {
        arrayString = arrayString.replace(/'/g, '"')
        const parsedArray = JSON.parse(arrayString)
        return parsedArray
      }
    },

    async initializMsalInstance() {
      this.msalInstanceData?.initialize()
    },

    async getLoginLog() {},

    async setProxyData(data: any) {
      console.log('Proxy Data', data)
      // this.counter++
    },

    async setLogoData(data: any) {
      console.log('Proxy Data', data)
      this.logoUrls = data
      this.loginLogo = this.getLoginLogo
      this.navLogo = this.getNavLogo
    },
    async createMasalInstanceDynamic(tokenReqData: any) {
      const tenant_id = tokenReqData.authority.replace('https://login.microsoftonline.com/', '')
      console.log('tenant_id', tenant_id)
      const reqTokenUrl = this.getProxyUrl + '/token'
      const reqObj = {
        grant_type: tokenReqData.grantType,
        client_id: tokenReqData.appId,
        client_secret: tokenReqData.clientSecretId,
        scope: tokenReqData.scopeBackendtoken,
        tenant_id: tenant_id
      }
      // axios.post(reqTokenUrl, reqObj).then((res: any) => {
      //     // console.log('Response Token', res.data.access_token);
      //     sessionStorage.setItem('jwtToken', res.data.access_token);
      // })
    }
  }
})
