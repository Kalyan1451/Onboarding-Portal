import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
// import piniaPluginPersistedState from "pinia-plugin-persistedstate"

export const sidebarStore = defineStore('sidebar', {
  state: () => ({
    sidebarData: {},
    progress: 0,
    activeIndex: 0
  }),
  getters: {
    getProgress: (state: any) => {
      console.log('progressVal', state.progress)
      if (!state.progress) {
        const progressVal = sessionStorage.getItem('progressValue')
        console.log('progressVal', progressVal)
        state.progress = progressVal ? progressVal : 0
      }
      return state.progress
    },
    getActiveIndex: (state: any) => {
      return state.progress
    }
  },
  actions: {
    setProgress(data: any) {
      console.log('sidebarStore', data)
      this.progress = data
      console.log('this.sidebarStore', this.progress)
      sessionStorage.setItem('progressValue', this.progress.toString())
      // this.counter++
    },
    setActiveIndex(data: any) {
      console.log('sidebarStore', data)
      this.activeIndex = data
      console.log('this.sidebarStore', this.progress)
      // this.counter++
    }
  },
  persist: {
    storage: sessionStorage // data in sessionStorage is cleared when the page session ends.
  }
})
