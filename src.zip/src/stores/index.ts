import { createPinia } from 'pinia'

export const pinia = createPinia()
