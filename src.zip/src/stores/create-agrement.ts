import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useAgrementStore = defineStore('agrement', {
  state: () => ({
    documentData: {}
  }),
  getters: {
    getDocumentData: (state: any) => {
      return state.documentData
    }
  },
  actions: {
    setDocumentData(data: any) {
      console.log('Proxy Data', data)
      this.documentData = data.data
      console.log('this.documentData', this.documentData)
      // this.counter++
    }
  }
})
