import { defineStore } from 'pinia'

export const useProxyDataStore = defineStore({
  id: 'proxyData',
  state: () => ({
    proxyUrlData: {}
  }),
  getters: {
    getLogos: (state) => state.proxyUrlData
  },
  actions: {
    setProxyData(data: any) {
      console.log('Proxy Data', data)
      // this.counter++
    }
  }
})
