/* eslint-disable vue/no-reserved-component-names */
/* eslint-disable vue/multi-word-component-names */
import './assets/main.scss'
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import PrimeVue from 'primevue/config'
import Avatar from 'primevue/avatar'
// import '../public/themes/soho-light/theme.css'
// import 'primevue/resources/themes/soho-dark/theme.css'
import 'primevue/resources/themes/soho-light/theme.css'
import 'primevue/resources/primevue.min.css'
import 'primeicons/primeicons.css'
import 'primeflex/primeflex.css'
import '../public/themes/soho-light/theme.css'
import Tooltip from 'primevue/tooltip'
import Steps from 'primevue/steps'
import InputText from 'primevue/inputtext'
import Password from 'primevue/password'
import Button from 'primevue/button'
import Sidebar from 'primevue/sidebar'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Panel from 'primevue/panel'
import Dialog from 'primevue/dialog'
import Textarea from 'primevue/textarea'
import Calendar from 'primevue/calendar'
import RadioButton from 'primevue/radiobutton'
import Checkbox from 'primevue/checkbox'
import ToastService from 'primevue/toastservice'
import Dropdown from 'primevue/dropdown'
import Menubar from 'primevue/menubar'
import Paginator from 'primevue/paginator'
import Row from 'primevue/row'
import Message from 'primevue/message'
import ColumnGroup from 'primevue/columngroup'
import Toast from 'primevue/toast'
import InputNumber from 'primevue/inputnumber'
import Fieldset from 'primevue/fieldset'
import TabView from 'primevue/tabview'
import TabPanel from 'primevue/tabpanel'
import Tag from 'primevue/tag'
import TabMenu from 'primevue/tabmenu'
import Divider from 'primevue/divider'
import Card from 'primevue/card'
import Knob from 'primevue/knob'
import ProgressSpinner from 'primevue/progressspinner'
import MultiSelect from 'primevue/multiselect'
import Menu from 'primevue/menu'
import Timeline from 'primevue/timeline'
import FileUpload from 'primevue/fileupload'
import mitt from 'mitt'
import i18n from './assets/i18n/i18n'
import App from './App.vue'
import router from './router'
import SplitButton from 'primevue/splitbutton'
import Accordion from 'primevue/accordion'
import AccordionTab from 'primevue/accordiontab'
import Breadcrumb from 'primevue/breadcrumb'
import OverlayPanel from 'primevue/overlaypanel'
import Listbox from 'primevue/listbox'

// import store from './stores/msalConfig';
import InputSwitch from 'primevue/inputswitch'
import { initializeMSAL } from './msalConfig'
import piniaPluginPersistedState from 'pinia-plugin-persistedstate'
;(async () => {
  await initializeMSAL().then((res: any) => {
    console.log('main res', res)
    // if(!res){
    //     return;
    // }
    const emitter = mitt()
    const app = createApp(App)
    // app.config.globalProperties.$msalInstance = {};
    // app.config.globalProperties.$emitter = new Emitter();
    app.directive('tooltip', Tooltip)
    // eslint-disable-next-line vue/multi-word-component-names
    app.component('Row', Row)
    app.component('ColumnGroup', ColumnGroup)
    app.component('InputText', InputText)
    app.component('Password', Password)
    // eslint-disable-next-line vue/no-reserved-component-names
    app.component('Button', Button)
    app.component('Sidebar', Sidebar)
    app.component('DataTable', DataTable)
    app.component('Column', Column)
    app.component('Panel', Panel)
    // eslint-disable-next-line vue/no-reserved-component-names
    app.component('Dialog', Dialog)
    app.component('TextArea', Textarea)
    app.component('Calendar', Calendar)
    app.component('RadioButton', RadioButton)
    app.component('Checkbox', Checkbox)
    app.component('Dropdown', Dropdown)
    app.component('Menubar', Menubar)
    app.component('Paginator', Paginator)
    app.component('TabMenu', TabMenu)
    app.component('TabView', TabView)
    app.component('TabPanel', TabPanel)
    app.component('Tag', Tag)
    app.component('Toast', Toast)
    app.use(i18n)
    app.component('InputNumber', InputNumber)
    // eslint-disable-next-line vue/no-reserved-component-names
    app.component('Fieldset', Fieldset)
    app.component('Divider', Divider)
    app.component('Card', Card)
    app.component('Steps', Steps)
    app.component('Knob', Knob)
    app.component('ProgressSpinner', ProgressSpinner)
    app.component('Timeline', Timeline)
    app.component('Accordion', Accordion)
    app.component('AccordionTab', AccordionTab)
    // app.component('Menu', Menu)
    app.component('SplitButton', SplitButton)
    app.component('Avatar', Avatar)
    app.component('MultiSelect', MultiSelect)
    app.component('Message', Message)
    app.component('InputSwitch', InputSwitch)
    app.component('Breadcrumb', Breadcrumb)
    app.component('OverlayPanel', OverlayPanel)
    app.component('Listbox', Listbox)

    app.component('Menu', Menu), app.component('FileUpload', FileUpload), app.use(ToastService)
    app.config.globalProperties.emitter = emitter
    const pinia = createPinia()

    pinia.use(piniaPluginPersistedState)
    // app.use(createPinia())
    // app.use(pinia)
    app.use(router)
    app.use(PrimeVue, { ripple: true })
    app.mount('#app')
  })
})()
// startApp();
