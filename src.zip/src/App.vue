<script lang="ts">
// import { onMounted } from 'vue';
import { RouterView } from 'vue-router'
import { LOCAL_STORAGE_VARIABLES } from './shared/constant/local-storage-variables'
// import i18n from '@/assets/i18n/i18n';
// import { initializeMSAL } from '@/msalConfig';
// import { useProxyDataStore } from '@/stores/proxy-data'
// const proxyData: any = useProxyDataStore();
// const env = new EnvironmentService();
export default {
  // created() {
  //   // 1. Before the DOM has been set up
  //   const proxyurl = "https://ol-npsitonboardingftr.innovasolutions.com:29000/ONBRD/proxyurl";
  //   axios.get(proxyurl).then((res: any) => {
  //     // console.log(location);
  //     console.log(res.data.appConfig);
  //     env.getMsalConfig(res.data.appConfig, res.data.redirectUrl);
  //   })
  // },
  // setup() {
  //   // const proxyurl = "/proxyurl"
  // },
  mounted() {
    // const dataProxy = proxyData.getProxyData();
    // console.log('dataProxy', dataProxy)
    const storedLanguage = sessionStorage.getItem('selectedLanguage')
    const selectedLanguage = storedLanguage || 'en'
    this.$i18n.locale = selectedLanguage
    //   (async () => {
    //   await initializeMSAL().then((res: any) => {
    //   console.log(res);
    // })})
  }
}
</script>

<template>
  <RouterView />
</template>

<style scoped></style>
