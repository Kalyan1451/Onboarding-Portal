import axios, { type AxiosInstance } from 'axios'
import { proxyUrl } from '@/msalConfig'
import { CONSULTANT_CONST_INFO } from './shared/constant/consultant_const_info'
import { LOCAL_STORAGE_VARIABLES } from './shared/constant/local-storage-variables'
// import EnvironmentService from './msalConfig'
// const env = new EnvironmentService();
//axios.defaults.headers.common['Authorization']=sessionStorage.getItem('jwtToken')
const apiClient: AxiosInstance = axios.create({
  // baseURL: "https://ol-npsitonboardingproxyftr.innovasolutions.com:29001/ONBRDPROXY",
  // baseURL: "https://ol-npsitonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1",
  // baseURL: "https://ol-npqaonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1",
  headers: {
    'Content-type': 'application/json'
  }
})
apiClient.interceptors.request.use(
  (config) => {
    console.log(config)
    // Modify the request config before sending it
    const token = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.JWT_TOKEN) // Replace with your token retrieval logic //'jwtToken'
    const userDetail = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //'userDetails'
    console.log('userRole', userDetail?.userRole)
    if (token) {
      const orgId = localStorage.getItem('orgId')
      config.headers.orgId = orgId
      config.headers.Authorization = token
      if (userDetail?.userRole == CONSULTANT_CONST_INFO.INNOVATEAM_ROLE) {
        //'InnovaTeam'
        config.headers.Source = 'sso'
      } else {
        // if(userDetail?.userRole == 'Consultant') {
        config.headers.Source = 'jwt'
      }
    }
    return config
  },
  (error) => {
    // Handle request errors

    console.error('Request Error Interceptor:', error)

    return Promise.reject(error)
  }
)

export default apiClient
