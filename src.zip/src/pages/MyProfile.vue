<template>
  <div>
    <div v-if="showDashBoardSteps">
      <p class="candidate-onboarding-text">{{ $t('candidateProfile') }}</p>
      <DashboardStepper />
      <!-- <Panel v-if="!showDashBoardSteps" :header="$t('overallCompletion')" class="progress">
        <div class="knob">
          <Knob readonly v-model="value" valueTemplate="{value}%" />
          <div v-if="value == 20">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <P>{{ $t('consultantSignUp') }}</P>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('createProfile') }}
              </div>
            </div>
          </div>
          <div v-if="value == 40">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <P>{{ $t('createProfile') }}</P>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('initiateOnboardingSteps') }}
              </div>
            </div>
          </div>
          <div v-if="value == 60">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <P>{{ $t('initiateOnboardingSteps') }}</P>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('submitOnboardingDocuments') }}
              </div>
            </div>
          </div>
          <div v-if="value == 80">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <P>{{ $t('submitOnboardingDocuments') }}</P>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('completeProfileCreation') }}
              </div>
            </div>
          </div>
          <div v-if="value == 100">
            <div class="pagelabel">
              <p>Current Page:</p>
              <div style="text-transform: uppercase">
                <P>{{ $t('completeProfileCreation') }}</P>
              </div>
            </div>
          </div>
        </div>
        <div class="consultant-step">
          <Steps :model="items" v-model:activeStep="active" id="parentId" />
        </div>

      </Panel> -->
    </div>

    <!-- <Panel v-if="showDashBoardSteps" header="My Profile Completion" class="progress">
        <div class="knob">
          <Knob readonly v-model="value1" valueTemplate="{value}%" />
          <div v-if="showData == 'personal-info'">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <p>{{ $t('personalInformationLabel') }}</p>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('previewLabel') }}
              </div>
            </div>
          </div>
          <div v-if="showData == 'preview'">
            <div class="pagelabel">
              <div style="text-transform: uppercase">
                <P>{{ $t('previewLabel') }}</P>
              </div>
            </div>
            <div class="pagelabel2">
              <p>Next:</p>
              <div style="text-transform: uppercase; margin-left: 10px">
                {{ $t('completeProfileCreation') }}
              </div>
            </div>
          </div>
          <div v-if="showData == 'completeProfileCreation'">
            <div class="pagelabel1">
              <div style="text-transform: uppercase">
                <P>{{ $t('completeProfileCreation') }}</P>
              </div>
            </div>
          </div>
        </div>
        <div class="vertical-steps">
          <Steps class="elevation-4" :model="items1" v-model:activeStep="active" />
        </div>
      </Panel> -->
    <!-- <Divider /> -->
  </div>

  <div v-if="showData === 'personal-info'">
    <!--<PersonalInformation @navigateToPreview="navigateToPreview" @subTaskPercentage="personalSubTaskPercentage" /> -->
    <PersonalInformation
      @navigateToPreview="navigateToPreview"
      @subTaskPercentageEducation="workPercentage"
    />
  </div>
  <!-- @navigateToEducational="navigateToEducational" -->
  <!--
        <div v-if="showData === 'education-info'">
            <EducationalInfo @navigateToWorkExp="navigateToWorkExp" @subTaskPercentageEducation="educationPercentage"
                @backToPersonalInfo="backToPersonalInfo"/>
        </div>
        <div v-if="showData === 'work-info'">
            <WorkExperience @navigateToPreview="navigateToPreview"  @subTaskPercentageEducation="workPercentage" @backToEducation="backToEducation"/>
        </div> -->
  <div v-if="showData === 'preview'">
    <Preview
      @backToPersonalInfo="backToPersonalInfo"
      @subTaskPercentagePreview="previewPercentage"
    />
  </div>
  <!-- @backToPersonalInfo="backToPersonalInfo" -->
</template>

<script lang="ts">
//import WorkExperience from '../components/WorkExperience.vue'
import PersonalInformation from '../components/PersonalInformation.vue'
import Preview from '../components/Preview.vue'
//import EducationalInfo from '../components/EducationalInfo.vue'
import onbService from '../shared/services/OnbService'
import DashboardStepper from '@/components/DashboardStepper.vue'
export default {
  props: ['data'],
  components: {
    PersonalInformation,
    Preview,
    DashboardStepper
    //EducationalInfo,
    //WorkExperience
  },
  data() {
    return {
      showDashBoardSteps: true,
      subtasks: [],
      empId: '',
      ele: '',
      subtasksStatus: [],
      active: 0,
      showData: 'personal-info',
      testEvent: 'String to change',
      dashboardDetails: [],
      taskStatuses: [],
      taskName: [],
      showPersonalinformation1: false,
      showEducation: false,
      showWorkExperience: false,
      showPreview: false,
      showDashboard: false,
      subEmployeeTasks: [],
      subEmployeeTaskStatus: [],
      value1: 0,
      items: [
        { label: this.$t('createProfile') },
        { label: this.$t('initiateOnboardingSteps') },
        { label: this.$t('submitOnboardingDocuments') }
      ],
      items1: [
        { label: this.$t('personalInformationLabel') },
        //  { label: this.$t('educationLabel') },
        //  { label: this.$t('workExperienceLabel') },
        { label: this.$t('previewLabel') },
        { label: this.$t('completeProfileCreation') }
      ],
      products: [
        { code: 'Complete Profile Creation', edit: 'Data 1' },
        { code: 'Complete Documentation', edit: 'Data 2' },
        { code: 'Complete Verification', edit: 'Data 3' },
        { code: 'Complete Educational Information', edit: 'Data 3' },
        { code: 'Submit', edit: 'Data 3' }
      ],
      activeStep: 0,
      value: 10,
      firstName: '',
      onbConsultId: null
    }
  },
  created() {
    this.emitter.on('personal-info', (evt: any) => {
      this.showData = evt.eventContent
      console.log('showPersonalinformation1', this.showData)
    })
    /*
        this.emitter.on('education-info', (evt: any) => {
            this.showData = evt.value
            console.log('showPersonalinformation1', this.showData)
        })

        this.emitter.on('work-info', (evt: any) => {
            this.showData = evt.value
            console.log('showPersonalinformation1', this.showData)
        })
        */
    this.emitter.on('preview', (evt: any) => {
      this.showData = evt.value
      console.log('showPersonalinformation1', this.showData)
    })
  },
  provide() {
    return {
      ConsultId: this.getonbConsultId()
    }
  },
  mounted() {
    if (this.$route.params.id) {
      console.log(this.$route.params.id)
      this.showData = 'preview'
      this.showDashBoardSteps = false
      this.onbConsultId = this.$route.params.id
      let consultId = parseInt(this.$route.params.id)
      console.log('Hey Show it', consultId)
      this.getDashboardData(consultId)
    }
  },

  beforeCreate() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    if (!this.$route.params.id) {
      onbService.getDashboardData(this.empId).then((res: any) => {
        // const empTask = res.data.data.employeeTaskDetails.filter((res: any) => {
        //     return res.employeeTaskId === 2
        // })
        this.value1 = res?.data?.data?.employeeTaskDetails[0]?.subTask?.percentage
        res?.data?.data?.employeeTaskDetails?.forEach((item: any) => {
          this.subEmployeeTasks.push(item?.subTask?.subEmployeeTask)
        })
        console.log(this.subEmployeeTasks)

        this.subEmployeeTasks[0]?.forEach((item: any) => {
          this.subEmployeeTaskStatus.push(item?.taskStatus?.name)
        })
        console.log(this.subEmployeeTaskStatus)
        //    this.changeProgressData()
        setTimeout(() => {
          this.ele = document.getElementsByClassName('p-steps-item')
          console.log(typeof this.ele)

          if (this.subEmployeeTaskStatus[1] == 'Completed') {
            for (let i = 0; i <= this.ele.length; i++) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.remove('p-disabled')
            }
          } else if (this.subEmployeeTaskStatus[0] == 'Completed') {
            for (let i = 0; i <= this.ele.length - 2; i++) {
              if (i == 1) {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.add('active-orange')
                this.ele[i]?.classList.remove('p-disabled')
              } else {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.remove('p-disabled')
              }
            }
          } else {
            for (let i = 0; i <= 0; i++) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.add('active-orange')
              this.ele[i]?.classList.remove('p-disabled')
            }
          }
        }, 300)

        console.log(this.ele)
        console.log(this.value1)
      })
    }
  },
  methods: {
    getonbConsultId() {
      return this.$route.params.id
    },
    personalSubTaskPercentage(eve: any) {
      this.value1 = eve
    },

    previewPercentage(evt: any) {
      this.value1 = evt
    },
    navigateToPreview(event: any) {
      this.showData = event
      // this.changeProgressData()
    },
    /*
        activeEducationInfo(event: any) {
            this.active = event
        }, 
        */
    backToPersonalInfo(event: any) {
      this.showData = event
      // this.changeProgressData()
    },

    getDashboardData(ID: any) {
      onbService.getDashboardData(ID).then((res: any) => {
        // const empTask = res.data.data.employeeTaskDetails.filter((res: any) => {
        //     return res.employeeTaskId === 2
        // })
        //this.value1 = res.data.data.employeeTaskDetails[0].subTask.percentage;
        this.value = res?.data?.data?.progress
        this.dashboardDetails = res?.data?.data?.employeeTaskDetails
        res?.data?.data?.employeeTaskDetails?.forEach((item: any) => {
          this.subEmployeeTasks.push(item?.subTask?.subEmployeeTask)
        })
        console.log(this.subEmployeeTasks)

        this.subEmployeeTasks[0].forEach((item: any) => {
          this.subEmployeeTaskStatus.push(item?.taskStatus?.name)
        })
        console.log(this.subEmployeeTaskStatus)
        this.firstName = res.data.data.firstName

        console.log(this.value1)
        this.dashboardDetails.forEach((item: any) => {
          this.taskStatuses.push(item.taskStatus.name)
          console.log(this.taskStatuses)
        })
        this.ele = document.getElementsByClassName('p-steps-item')
        if (this.taskStatuses[2] == 'Completed') {
          for (let i = 0; i <= this.ele.length; i++) {
            this.ele[i]?.classList.add('p-highlight')
            this.ele[i]?.classList.remove('p-disabled')
          }
        } else if (this.taskStatuses[1] == 'Completed') {
          for (let i = 0; i <= this.ele.length; i++) {
            if (i == 2) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.add('active-orange')
              this.ele[i]?.classList.remove('p-disabled')
            } else {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.remove('p-disabled')
            }
          }
        } else if (this.taskStatuses[0] == 'Completed') {
          for (let i = 0; i <= this.ele.length - 2; i++) {
            if (i == 1) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.add('active-orange')
              this.ele[i]?.classList.remove('p-disabled')
            } else {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.remove('p-disabled')
            }
          }
        } else {
          for (let i = 0; i <= 0; i++) {
            this.ele[i]?.classList.add('p-highlight')
            this.ele[i]?.classList.add('active-orange')
            this.ele[i]?.classList.remove('p-disabled')
          }
        }

        console.log(this.ele)
        console.log(this.value1)
      })
    }
  }
}
</script>
<style scoped>
.knob {
  float: left;
  position: relative;
  bottom: 17px;
  display: flex;
  justify-content: space-between;
}

.chart-container {
  display: flex;
}

.p-panel-content {
  padding: 35px 10px;
}

.button {
  height: 30px;
  width: 100px;
  /* background: #2096cd; */
}

.p-datatable .p-datatable-thead > tr > th {
  text-align: left;
  padding: 0.5rem 1rem;
  border: 1px solid #dee2e6;
  border-width: 0 0 1px 0;
  font-weight: 700;
  color: white;
  background: #03a9f4;
  transition: box-shadow 0.2s;
}

/* Style the progress bar container */
.step-progressbar {
  display: flex;
  list-style: none;
  padding: 0;
  margin: 0;
}

/* Style the individual steps */
.step-item {
  display: flex;
  align-items: center;
  padding: 10px;
}

/* Style the active step indicator */
.step-item.active {
  background-color: grey;
}

/* Style the step text */
.step-item span {
  font-weight: bold;
}

/* Style the progress bar */
.progress-bar {
  background-color: #ccc;
  height: 5px;
}

.step-completed {
  text-decoration: line-through;
  color: #ccc;
}

@media (max-width: 545px) {
  .design {
    display: flex;
    flex-direction: column;
  }
}

@media (max-width: 1000px) {
  .p-panel .p-panel-content {
    align-items: center;
    padding: 1rem;
    border: 1px solid #dee2e6;
    background: #ffffff;
    color: #495057;
    border-top: 0 none;
    display: flex;
    flex-direction: column;
  }
}

.p-steps .p-steps-list {
  padding: 0;
  margin: 0;
  list-style-type: none;
  display: flex;
  flex-direction: column;
}
@media (min-width: 860px) {
  .pagelabel {
    display: none;
  }
  .pagelabel2 {
    display: none;
  }
}
@media (max-width: 860px) {
  .pagelabel {
    display: flex;
    font-weight: 700;
    align-items: center;
    /* white-space: nowrap; */
  }

  .knob {
    margin-top: 10px;
    margin-bottom: -20px;
  }
  .pagelabel2 {
    font-weight: 400;
    display: flex;
    align-items: baseline;
    font-size: 14px;
  }
}

.custom-steps .p-steps-item {
  border-right: none;
}

.candidate-onboarding-text {
  font-weight: 500;
  color: #0070cd;
  font-size: 20px;
  letter-spacing: 0.2px;
  line-height: 50px;
  white-space: nowrap;
  text-align: left;
  margin-top: -20px;
}

@media only screen and (max-width: 1100px) {
  .candidate-onboarding-text {
    text-align: center;
    font-size: 15px;
  }
}
.stepper {
  margin-top: -20px;
}
</style>
