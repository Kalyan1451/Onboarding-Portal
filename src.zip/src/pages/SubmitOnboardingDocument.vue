<template>
  <div v-if="documentsData?.length && source1 != ''">
    <vue-pdf-embed :source="source1" />
  </div>
  <div v-if="!documentsData?.length > 0">
    {{ $t('noDataFound') }}
  </div>

  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
  </div>
</template>
<script lang="ts">
import OnbService from '../shared/services/OnbService'
import { proxyUrl } from '@/msalConfig'
import VuePdfEmbed from 'vue-pdf-embed'
console.log('proxyUrl', proxyUrl)

export default {
  components: {
    // pdf,
    VuePdfEmbed
  },
  data() {
    return {
      selectedDocument: '',
      source1: '',
      documentsData: [],
      empId: '',
      categoryId: '',
      loading: false,
      post: null,
      byteArrays: null,
      byteArrayPDF: null,
      viewFile: false,
      documentDetails: {},
      documentName: '',
      documentPackageId: '',
      documentId: '',
      employeeDocumentId: '',
      url: '',
      showSpinner: false
    }
  },

  beforeCreate() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
  },

  mounted() {
    console.log('proxyUrl', proxyUrl)
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    this.getOnboardingDocuments()
    // setTimeout(()=>{
    //     this.getOnboardingDocuments();
    // },2000)
  },

  methods: {
    acceptDocument() {
      let data = {}
    },
    showDocument(item: any) {
      // this.source1 = '';
      this.documentDetails = item
      this.documentName = this.documentDetails?.document?.documentName
      // this.documentPackageId = this.documentDetails.documentPackage
      console.log('this.documentDetails', this.documentDetails)
      this.viewFile = true
    },

    getOnboardingDocuments() {
      this.showSpinner = true
      OnbService.getOnboardingDocuments(this.empId)
        .then((res: any) => {
          console.log(res)
          this.documentsData = res.data.data
          this.documentsData.forEach((item, index) => {
            item.employeeDocumentsList?.filter((element, index) => {
              if (element.templatePackage?.template?.templateName == 'state_income_tax.pdf') {
                this.selectedDocument = element
                // return ;
              }
            })
          })
          console.log(this.selectedDocument)
          this.documentPackageId = this.selectedDocument?.templatePackage?.templatePackageId
          this.employeeDocumentId = this.selectedDocument?.employeeDocumentId
          this.documentId = this.selectedDocument.templatePackage?.template?.templateId
          this.documentName = this.selectedDocument.templatePackage?.template?.templateName
          this.source1 =
            proxyUrl +
            '/v2/documents/' +
            this.documentId +
            '/documentpackage/' +
            this.documentPackageId +
            '/employee/' +
            this.empId
          //this.source1 = "https://ol-npsitonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/documents/employeedocument/" + this.employeeDocumentId + "/downloadFile/" + this.documentName;
          console.log('this.documentsData', this.documentsData)
          setTimeout(() => {
            this.showSpinner = false
          }, 2000)
        })
        .catch((error) => {
          this.showSpinner = false
          console.log('Not good man :(')
        })
    }
  }
}
</script>
<style>
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
</style>
