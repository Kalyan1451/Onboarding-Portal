<template>
  <div class="stylepreview">
    <Panel :header="$t('verifyInfomation')" class="progress">
      <!-- <DashboardStepper/> -->
      <div>
        <Message v-if="viewParagraphMsg" severity="success" class="viewParagraph">{{
          $t('successInitiatory')
        }}</Message>
      </div>
      <PersonalInformation
        @firstName="firstName"
        @middleName="middleName"
        @lastName="lastName"
        @preferredName="getPreferredName"
        @prefferredLanguage="getPrefferredLanguage"
        @taxId="getTaxId"
        @taxReason="getTaxReason"
        @birthDate="getBirthDate"
        @homePhone="getHomePhone"
        @mobilePhone="getMobilePhone"
        @primaryEmail="getPrimaryEmail"
        @prefferredContact="getPrefferredContact"
        @emergencyContactName="getEmergencyContactName"
        @emergencyContactNumber="getEmergencyContactNumber"
        @streetAddress1="getStreetAddress1"
        @streetAddress2="getStreetAddress2"
        @country="getCountry"
        @county="getCounty"
        @state="getState"
        @city="getCity"
        @zip="getZip"
        @isZipInvalid="getZipValidation"
        @isHomePhoneInvalid="getHomePhoneValidation"
        :onPreviewPage="pageName"
        :isDiasbled="formValue"
        @isMobilePhoneInvalid="getisMobilePhoneInvalid"
        @isEmergencyContactInvalid="getisEmergencyContactInvalid"
        @selectedCountry="getselectedCountry"
        @isCountryCodeValid="getisCountryCodeValid"
        @selectedSecondaryPhone="getselectedSecondaryPhone"
        @isCountryCodeValidSecoundaryPhone="getisCountryCodeValidSecoundaryPhone"
        @selectedEmergencyContact="getselectedEmergencyContact"
        @isCountryCodeValidEmergencyContact="getisCountryCodeValidEmergencyContact"
      >
      </PersonalInformation>

      <!-- <EducationalInfo @updatedEducation="getEducationData"></EducationalInfo>
                <WorkExperience @updatedWorkExperince="getWorkExpData" ></WorkExperience> -->
      <div style="display: flex; justify-content: center; column-gap: 10px; margin: 15px 0">
        <Button v-if="formValue" :label="$t('editLabel')" @click="editInfo"></Button>
        <Button :label="$t('proceed')" @click="saveInitiation"></Button>
      </div>
    </Panel>
  </div>
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
  </div>
</template>
<script lang="ts">
import { useToast } from 'primevue/usetoast'
//import WorkExperience from '../components/WorkExperience.vue'
import PersonalInformation from '../components/PersonalInformation.vue'
//import EducationalInfo from '../components/EducationalInfo.vue'
import OnbService from '../shared/services/OnbService'
import moment from 'moment'
import { useAgrementStore } from '@/stores/create-agrement'
import DashboardStepper from '@/components/DashboardStepper.vue'

export default {
  setup() {
    const agrementStore = useAgrementStore()
    const agreementData = agrementStore.getDocumentData
    return {
      agrementStore,
      agreementData
    }
  },
  components: {
    PersonalInformation,
    DashboardStepper
    //EducationalInfo,
    //WorkExperience
  },
  provide() {
    return {
      isConsultantInfoPage: true
    }
  },
  data() {
    return {
      pageName: 'preview',
      viewParagraphMsg: false,
      formValue: false,
      getFname: '',
      getMname: '',
      getLname: '',
      preferredName: '',
      prefferredLanguage: '',
      taxId: '',
      birthDate: '',
      homePhone: '',
      mobilePhone: '',
      primaryEmail: '',
      prefferredContact: '',
      taxReason: '',
      emergencyContactName: '',
      emergencyContactNumber: '',
      streetAddress1: '',
      streetAddress2: '',
      isMobilePhoneInvalid: false,
      isEmergencyContactInvalid: false,
      selectedCountry: '',
      isCountryCodeValid: false,
      selectedSecondaryPhone: '',
      isCountryCodeValidSecoundaryPhone: false,
      selectedEmergencyContact: '',
      isCountryCodeValidEmergencyContact: false,
      county: '',
      city: '',
      country: '',
      state: '',
      zip: '',
      toast: useToast(),
      showSpinner: false,
      isZipInvalid: false,
      isZipValid: false,
      isHomePhoneInvalid: false,
      empId: '',
      employeeAllData: '',
      personalData: '',
      educationData: '',
      workExpData: '',
      keysToRemove: [
        'errorSchool',
        'errorDegree',
        'errorCity',
        'errorZip',
        'errorCountry',
        'errorState'
      ],
      keysToRemoveWorkExp: [
        'companyValidity',
        'fromValidity',
        'jobtitleValidity',
        'jobAndRolesvalidity',
        'statusValidity',
        'toValidity'
      ],
      client: new HelloSign({
        clientId: '1c3b71bf90f213797a51e29bd4a1b25a',
        skipDomainVerification: true,
        testMode: true
      }),
      empDocList: [],
      empDocId: ''
    }
  },
  mounted() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    this.getDashboardData()
    this.formValue = true
    this.emitter.emit('disableForm', { value: false })
    this.userDetails = userDetails
    this.empId = this.userDetails.employeeId
    OnbService.getOnboardingDocuments(this.empId).then((response: any) => {
      response.data.data.forEach((item: any) => {
        item.employeeDocumentsList.forEach((item: any) => {
          this.empDocList.push(item)
          console.log(this.empDocList)
        })
      })
      const templateId = sessionStorage.getItem('templateId')

      this.empDocList.filter((doc: any) => {
        if (doc.templatePackage.template.templateId == templateId) {
          this.empDocId = doc.employeeDocumentId
          console.log(this.empDocId)
        }
      })
    })
  },
  methods: {
    getDocument() {
      console.log('agreementdata', this.agreementData)
      const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
      this.empId = userDetails.employeeId
      const externalTemplateId = sessionStorage.getItem('externaltemplateId')
      const agreemnentName = sessionStorage.getItem('templateName')
      let payload = {
        templateId: externalTemplateId, //this.templateId,
        agreementName: agreemnentName, //this.agreementName,
        candidateDetail: {
          candidateEmail: userDetails.email,
          candidateId: userDetails.employeeId,
          firstName: userDetails.firstName,
          lastName: userDetails.lastName
        }
      }
      OnbService.createAgreement(payload, this.empDocId).then((res) => {
        if (res.data.data) {
          let signingUrl = res.data.data.signingUrl
          this.client.open(signingUrl, {
            clientId: '1c3b71bf90f213797a51e29bd4a1b25a',
            skipDomainVerification: true,
            testMode: true
            //   allowCancel :false
          })
          this.client.on(HelloSign.events.CANCEL, () => {
            OnbService.submitDocuments(this.empDocId, 2).then((res) => {
              this.$router.push('/onb/pending-documents')
            })
            this.flowMsg = 'Template creation has been cancelled'
          })
          this.client.on(HelloSign.events.SIGN, (data: any) => {
            OnbService.submitDocuments(this.empDocId, 4).then((res) => {
              this.$router.push('/onb/pending-documents')
            })

            console.log(data)
          })
          this.client.on(HelloSign.events.OPEN, (data: any) => {
            console.log(data)
          })
        }
      })
    },
    editInfo() {
      // this.isUpdate = true;
      this.formValue = false
    },
    firstName(newValue: any) {
      this.getFname = newValue
    },
    middleName(newValue: any) {
      this.getMname = newValue
    },
    lastName(newValue: any) {
      this.getLname = newValue
    },
    getPreferredName(newValue: any) {
      this.preferredName = newValue
    },
    getPrefferredLanguage(newValue: any) {
      this.prefferredLanguage = newValue
    },
    getTaxId(newValue: any) {
      this.taxId = newValue
    },
    getTaxReason(newValue: any) {
      this.taxReason = newValue
    },
    getBirthDate(newValue: any) {
      this.birthDate = newValue
    },
    getHomePhone(newValue: any) {
      this.homePhone = newValue
    },
    getMobilePhone(newValue: any) {
      this.mobilePhone = newValue
    },
    getPrimaryEmail(newValue: any) {
      this.primaryEmail = newValue
    },
    getPrefferredContact(newValue: any) {
      this.prefferredContact = newValue
    },
    getEmergencyContactName(newValue: any) {
      this.emergencyContactName = newValue
    },
    getEmergencyContactNumber(newValue: any) {
      this.emergencyContactNumber = newValue
    },
    getStreetAddress1(newValue: any) {
      this.streetAddress1 = newValue
    },
    getStreetAddress2(newValue: any) {
      this.streetAddress2 = newValue
    },
    getCountry(newValue: any) {
      this.country = newValue
    },
    getCounty(newValue: any) {
      this.county = newValue
    },
    getState(newValue: any) {
      this.state = newValue
    },
    getCity(newValue: any) {
      this.city = newValue
    },
    getZip(newValue: any) {
      this.zip = newValue
    },
    getZipValidation(newValue: any) {
      this.isZipInvalid = newValue
    },
    getEduZipValidation(newValue: any) {
      this.isZipValid = newValue
    },
    getHomePhoneValidation(newValue: any) {
      this.isHomePhoneInvalid = newValue
    },
    getDashboardData() {
      OnbService.getEmployeeData(this.empId).then((response: any) => {
        this.employeeAllData = response.data.data
      })
    },
    getisMobilePhoneInvalid(newValue: any) {
      this.isMobilePhoneInvalid = newValue
    },
    getisEmergencyContactInvalid(newValue: any) {
      this.isEmergencyContactInvalid = newValue
    },
    getselectedCountry(newValue: any) {
      this.selectedCountry = newValue
    },
    getisCountryCodeValid(newValue: any) {
      this.isCountryCodeValid = newValue
    },
    getselectedSecondaryPhone(newValue: any) {
      this.selectedSecondaryPhone = newValue
    },
    getisCountryCodeValidSecoundaryPhone(newValue: any) {
      this.isCountryCodeValidSecoundaryPhone = newValue
    },
    getselectedEmergencyContact(newValue: any) {
      this.selectedEmergencyContact = newValue
    },
    getisCountryCodeValidEmergencyContact(newValue: any) {
      this.isCountryCodeValidEmergencyContact = newValue
    },
    /*
        getEducationData(newValue:any){
           this.educationData=newValue;
           
        }  ,
        getWorkExpData(newValue:any){
            this.workExpData=newValue;
        },*/
    validateZip(field: any) {
      if (field.zipCode !== '' && field.zipCode != null) {
        if (!this.isNumber(field.zipCode)) {
          this.isZipValid = true
          field.errorZip = this.$t('ErrorMessages.zipValidationMsg')
        } else {
          field.errorZip = ''
        }
      } else {
        field.errorZip = this.$t('ErrorMessages.mandatory')
      }
    },
    isNumber(value?: string | number): boolean {
      return !isNaN(Number(value.toString()))
    },
    saveInitiation() {
      this.isZipValid = false
      var personalInfoValid = false
      if (
        this.getFname &&
        this.getLname &&
        this.birthDate &&
        this.primaryEmail &&
        this.prefferredContact &&
        this.homePhone &&
        this.streetAddress1 &&
        this.state &&
        this.country &&
        this.city &&
        this.zip &&
        !this.isZipInvalid &&
        !this.isHomePhoneInvalid &&
        !this.isMobilePhoneInvalid &&
        !this.isEmergencyContactInvalid &&
        !this.isCountryCodeValidEmergencyContact &&
        !this.isCountryCodeValidSecoundaryPhone &&
        !this.isCountryCodeValid
      ) {
        personalInfoValid = true
      }

      //if(invalidEdutype.length <= 0 && invalidWorkExptype.length <=0 && personalInfoValid){
      if (personalInfoValid) {
        this.showSpinner = true

        let payload = {
          employeeId: this.empId,
          ownerId: 1,
          createdBy: 1,
          modifiedBy: 1,
          dateOfBirth: this.birthDate
            ? moment(this.birthDate).format('MM/DD/YYYY')
            : this.employeeAllData.dateOfBirth != null && this.employeeAllData.dateOfBirth != ''
              ? this.employeeAllData.dateOfBirth
              : null,
          departmentId: null,
          locationId: null,
          organizationId: 1,
          genderId: this.employeeAllData?.genderId,
          stateId: this.state ? this.state : this.employeeAllData?.stateId,
          countryId: this.country ? this.country : this.employeeAllData?.countryId,
          county: this.county ? this.county : this.employeeAllData?.county,
          secondaryStateId: null,
          secondaryCountryId: null,
          createdDate: '11/16/2023 23:58:46.000',
          modifiedDate: '11/22/2023 23:58:46.000',
          isActive: 'Y',
          isDeleted: 'N',
          secondaryAddress1: null,
          secondaryAddress2: null,
          firstName: this.getFname ? this.getFname : this.employeeAllData?.firstName,
          middleName: this.getMname ? this.getMname : this.employeeAllData?.middleName,
          lastName: this.getLname ? this.getLname : this.employeeAllData?.lastName,
          primaryExt:this.selectedCountry ? this.selectedCountry : this.employeeAllData?.primaryExt,
          secondaryExt:this.selectedSecondaryPhone ? this.selectedSecondaryPhone : this.employeeAllData?.secondaryExt,
          emergencyExt:this.selectedEmergencyContact ? this.selectedEmergencyContact : this.employeeAllData?.emergencyExt,
          ssn: this.taxId ? this.taxId : this.employeeAllData?.ssn,
          ssnReason: this.taxReason ? this.taxReason : this.employeeAllDatai?.ssnReason,
          emergencyPersonName: this.emergencyContactName
            ? this.emergencyContactName
            : this.employeeAllData?.emergencyPersonName,
          emergencyContactNumber: this.emergencyContactNumber
            ? this.emergencyContactNumber
            : this.employeeAllData?.emergencyContactNumber,
          email: this.primaryEmail ? this.primaryEmail : this.employeeAllData?.email,
          email1: null,
          address1: this.streetAddress1 ? this.streetAddress1 : this.employeeAllData?.address1,
          address2: this.streetAddress2 ? this.streetAddress2 : this.employeeAllData?.address2,
          externalId: null,
          preferredName: this.preferredName
            ? this.preferredName
            : this.employeeAllData?.preferredName,
          phone: this.homePhone ? this.homePhone : this.employeeAllData?.phone,
          phone2: this.mobilePhone ? this.mobilePhone : this.employeeAllData?.phone2,
          city: this.city ? this.city : this.employeeAllData?.city,
          zipcode: this.zip ? this.zip : this.employeeAllData?.zipcode,
          scondaryZipcode: null,
          preferredLanguageId: this.prefferredLanguage
            ? this.prefferredLanguage
            : this.employeeAllData?.preferredLanguageId,
          preferredContactMethodId: this.prefferredContact
            ? this.prefferredContact
            : this.employeeAllData?.preferredContactMethodId,
          educationDetails: [], //modifiedEducationArray,
          employeeWorkHistory: [], //modifiedWorkExpArray,
          employeeTaskDetails: [
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[0]?.employeeTaskId
                ? this.employeeAllData?.employeeTaskDetails[0]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 2,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: '11/16/2023 21:40:52.000',
                modifiedDate: null,
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Complete Profile',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: 4,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                statusTypeId: 2,
                organizationId: 1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: 'Y',
                name: 'Completed'
              },
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: '11/17/2023 00:03:22.000',
              modifiedDate: null,
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[1]?.employeeTaskId
                ? this.employeeAllData.employeeTaskDetails[1]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 3,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: '11/16/2023 21:40:54.000',
                modifiedDate: null,
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Pending Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: 4,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                statusTypeId: 2,
                organizationId: 1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: 'Y',
                name: 'Completed'
              },
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: '11/17/2023 00:03:24.000',
              modifiedDate: null,
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            },
            {
              employeeTaskId: this.employeeAllData?.employeeTaskDetails[2]?.employeeTaskId
                ? this.employeeAllData?.employeeTaskDetails[2]?.employeeTaskId
                : '',
              employeeId: this.empId,
              organizationId: 1,
              task: {
                taskId: 4,
                taskTypeId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                parentTaskId: null,
                organizationId: 1,
                createdDate: '11/16/2023 21:40:56.000',
                modifiedDate: null,
                isActive: 'Y',
                isDeleted: 'N',
                taskName: 'Complete Onboarding Documents',
                externalId: null,
                subTask: null
              },
              taskStatus: {
                statusId: 1,
                ownerId: null,
                createdBy: 1,
                modifiedBy: null,
                statusTypeId: 2,
                organizationId: 1,
                createdDate: '11/16/2023 21:33:46.000',
                modifiedDate: null,
                isActive: 'Y',
                name: 'Open'
              },
              ownerId: null,
              createdBy: 1,
              modifiedBy: null,
              assignedTo: 1,
              createdDate: '11/17/2023 00:03:25.000',
              modifiedDate: null,
              isActive: 'Y',
              isDeleted: 'N',
              comments: null,
              externalId: null,
              subTask: null
            }
            // {
            //     "employeeTaskId": (this.employeeAllData.employeeTaskDetails[4].employeeTaskId)?this.employeeAllData.employeeTaskDetails[4].employeeTaskId:'',
            //     "employeeId": this.empId,
            //     "organizationId": 1,
            //     "task": {
            //         "taskId": 5,
            //         "taskTypeId": 1,
            //         "ownerId": null,
            //         "createdBy": 1,
            //         "modifiedBy": null,
            //         "parentTaskId": null,
            //         "organizationId": 1,
            //         "createdDate": "11/16/2023 21:40:58.000",
            //         "modifiedDate": null,
            //         "isActive": "Y",
            //         "isDeleted": "N",
            //         "taskName": "Onboarding Approved",
            //         "externalId": null,
            //         "subTask": null
            //     },
            //     "taskStatus": {
            //         "statusId": 1,
            //         "ownerId": null,
            //         "createdBy": 1,
            //         "modifiedBy": null,
            //         "statusTypeId": 2,
            //         "organizationId": 1,
            //         "createdDate": "11/16/2023 21:33:46.000",
            //         "modifiedDate": null,
            //         "isActive": "Y",
            //         "name": "Open"
            //     },
            //     "ownerId": null,
            //     "createdBy": 1,
            //     "modifiedBy": 1,
            //     "assignedTo": 1,
            //     "createdDate": "11/17/2023 00:03:26.000",
            //     "modifiedDate": null,
            //     "isActive": "Y",
            //     "isDeleted": "N",
            //     "comments": null,
            //     "externalId": null,
            //     "subTask": null
            // }
          ],
          user: null,
          progress: this.employeeAllData?.progress
        }
        //let url = 'https://ol-npqaonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/employee/save';
        OnbService.employeeSave(payload)
          .then((response: any) => {
            // this.toast.add({
            //     severity: 'success',
            //     summary: this.$t('successMessages.success'),
            //     detail: this.$t('successMessages.initiateSteps'),
            //     life: 2000
            // })
            this.viewParagraphMsg = true
            setTimeout(() => {
              const fieldJson = sessionStorage.getItem('fieldJson')

              if (JSON.parse(fieldJson).fieldData.length > 0) {
                this.$router.push('/onb/create-agreement')
              } else {
                this.getDocument()
              }
            }, 2000)
          })
          .finally(() => {
            setTimeout(() => {
              this.showSpinner = false
            }, 1000)
          })
          .catch((error) => {
            this.showSpinner = false
            console.error('There was an error!', error)
          })
      }
    }
  }
}
</script>
<style scoped>
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

.stylepreview {
  display: flex;
  flex-direction: column;
  row-gap: 10px;
}
.progress {
  margin-top: -15px;
  margin-left: -10px;
}

.stepper {
  margin-top: -15px;
  /* margin-left: -10px; */
}
.p-button {
  width: 100px;
}
/* 
.viewParagraph {
    color: red;
} */
</style>
