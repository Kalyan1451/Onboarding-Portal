<template>
  <div class="app-container">
    <div class="app-containerr">
      <div class="container">
        <div class="current_month">
          <h4 class="header">{{ $t('viewRecords') }}</h4>
          <Dropdown
            v-model="selectDays"
            :options="days"
            optionLabel="label"
            optionValue="value"
            :placeholder="$t('selectDays')"
            class="viewDropDown"
            @change="fetchData"
          />
          <!-- <RadioButton v-model="selectDays" inputId="c_month" value="" @change="fetchData" />
                  <label for="c_month">{{ $t('thisMonth') }}</label> -->
        </div>
        <div class="choose" v-if="selectDays == 0">
          <div class="select">
            {{ $t('dateLabel') }}
          </div>
          <!-- <RadioButton v-model="selectDays" inputId="choose" value="choose" @change="fetchData" /> -->
          <div class="selectlabel">
            <div class="toFromClass">
              <h4 class="from">{{ $t('from') }}</h4>
              <div>
                <Calendar
                  :maxDate="minDate"
                  :disabled="selectDays !== 0"
                  dateFormat="mm/dd/yy"
                  :class="{ 'p-invalid': isDate1Active }"
                  showToday
                  showClear
                  v-model="date1"
                  @click="selectedDate(date1)"
                  @date-select="selectedDate(date1)"
                  @input="selectedDate(date1)"
                  showIcon
                  class="small-calendar"
                  placeholder="MM/DD/YYYY"
                />
              </div>
              <div class="alignment">
                <small v-if="isDate1Active" :class="{ 'p-invalid': isDate1Active }">{{
                  $t('ErrorMessages.mandatory')
                }}</small>
              </div>
            </div>
            <!--date-select

                  -->
            <div class="toFromClass">
              <h4 class="from">{{ $t('to') }}</h4>
              <div>
                <Calendar
                  :minDate="toMinDate"
                  :disabled="selectDays !== 0"
                  dateFormat="mm/dd/yy"
                  :class="{ 'p-invalid': isDate2Active }"
                  showToday
                  showClear
                  v-model="date2"
                  @click="selectDate2(date2)"
                  @date-select="selectDate2(date2)"
                  @input="selectDate2(date2)"
                  showIcon
                  class="small-calendar"
                  placeholder="MM/DD/YYYY"
                />
              </div>
              <div class="alignment">
                <small v-if="isDate2Active" :class="{ 'p-invalid': isDate2Active }">{{
                  $t('ErrorMessages.mandatory')
                }}</small>
              </div>
            </div>

            <!-- <div class="field col-12 md:col-3 lg:col-4 mb-0 "
                                      v-show="item.currentlyWorkingHere != 1">
                                      <label :class="item.fromValidity ? 'error' : 'valid'">{{ $t('from') }}<span
                                              class="text-danger">*</span></label>
                                    <Calendar :maxDate="minDate" :class="item.fromValidity ? 'error' : 'valid'"
                                      @click="validateFrom(item)" @date-select="validateFrom(item)" showIcon lass="small-calendar" focused="true" dateFormat="mm/dd/yy"
                                          v-model="item.startDate" :disabled="disableField"  />
                                      <small v-if="item.fromValidity" class="error">{{ item.fromValidity }}</small>
                                  </div> -->

            <!-- <Calendar :minDate="toMinDate"  :disabled="selectDays !== 0"  dateFormat="mm/dd/yy"
                      showToday showClear v-model="date2" showIcon class="small-calendar"
                      @click="fetchData" /> -->
          </div>
        </div>
        <div class="view">
          <h4 class="header">{{ $t('onboardingSpecialist') }}</h4>
          <!-- <Dropdown v-model="selectedSpecialist" :options="onb_spl" optionLabel="name" placeholder="Onboarding Specialist" class="w-full md:w-8rem" @change="fetchOnbData"/> -->
          <Dropdown
            v-model="selectedSpecialist"
            :options="onb_spl"
            optionLabel="obsName"
            optionValue="userId"
            :placeholder="$t('onboardingSpecialist')"
            class="viewDropDown"
            @change="fetchDropdownData"
          />
          <!-- <div class="defaultbutton  mt-7"> -->
          <!-- </div> -->
        </div>
        <div>
          <Button
            :label="$t('defaultView')"
            class="defaultbutton"
            severity="secondary"
            @click="fetchTableDatadefault()"
          />
        </div>
      </div>
      <Card>
        <template #header>
          <div class="grid">
            <div class="col-12 md:col-6 lg:col-3">
              <Card
                class="card"
                @click="fetchTableData(5, 'N', 'card'), activateCard(5)"
                :class="{ active: isActiveCard(5) }"
              >
                <template #title>
                  <div class="onboarding">{{ $t('onboardingStatus.newOnboarding') }}</div>
                </template>
                <template #content>
                  <div class="ncount">{{ totalNewOnboarding }}</div>
                </template>
              </Card>
            </div>
            <div class="col-12 md:col-6 lg:col-3">
              <Card
                @click="fetchTableData(6, 'N', 'cardV'), activateCard(6)"
                :class="{ active: isActiveCard(6) }"
                class="card"
              >
                <template #title>
                  <div class="onboarding">{{ $t('onboardingStatus.pendingOnboarding') }}</div>
                </template>
                <template #content>
                  <div class="tcount">{{ totalPendingOnboarding }}</div>
                </template>
              </Card>
            </div>
            <div class="col-12 md:col-6 lg:col-3">
              <Card
                @click="fetchTableData(7, 'N', 'cardVi'), activateCard(7)"
                class="card"
                :class="{ active: isActiveCard(7) }"
              >
                <template #title>
                  <div class="onboarding">{{ $t('onboardingStatus.submittedOnboarding') }}</div>
                </template>
                <template #content>
                  <div class="rcount">{{ submittedOnboardings }}</div>
                </template>
              </Card>
            </div>
            <div class="col-12 md:col-6 lg:col-3">
              <Card
                @click="fetchTableData(8, 'N', 'cardView'), activateCard(8)"
                class="card"
                :class="{ active: isActiveCard(8) }"
              >
                <template #title>
                  <div class="onboarding">{{ $t('onboardingStatus.approvedOnboarding') }}</div>
                </template>
                <template #content>
                  <div class="acount">{{ approvedOnboardings }}</div>
                </template>
              </Card>
            </div>
          </div>
        </template>
        <!-- <Panel :header="$t('consultantInformation')"> -->
        <template #content>
          <DataTable
            :value="userData"
            v-if="userData"
            showGridlines
            dataKey="id"
            :first="offset"
            :rows="limit"
            :rowsPerPageOptions="[25, 50, 100]"
            removableSort
            lazy
            paginator
            :emptyMessage="'No records found'"
            paginatorTemplate=" FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink RowsPerPageDropdown"
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            tableStyle="min-width: 50rem"
            @page="paginate($event)"
            @sort="handleSort"
            :totalRecords="totalRecords"
            :sortField="defaultSortField"
            :sortOrder="defaultSortOrder"
          >
            <!-- paginatorTemplate=" FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink RowsPerPageDropdown" -->
            <a
              ><Column
                key="index"
                field="consultant_id"
                :sortable="true"
                :sortField="'consultant_Id'"
              >
                <template #header>
                  <div class="p-d-flex p-jc-between sortableColumn" @click.stop>
                    <span class="headersObs">{{ $t('headers.consultantId') }}</span>
                    <MultiSelect
                      filter
                      icon="pi pi-search"
                      :options="consultantIdDropDownData"
                      :placeholder="$t('all')"
                      v-model="consultantIdd"
                      @filter="handleFilter($event, 'consultantId')"
                      @change="fetchTableData(null, 'Y')"
                      class="inputtext1 md:w-10rem"
                      :maxSelectedLabels="2"
                    />
                  </div>
                </template>
                <template #body="slotProps">
                  <a class="candidate" @click="OpenPreview(slotProps)">
                    {{ slotProps.data.consultant_id }}
                  </a>
                </template>
              </Column>
            </a>
            <Column
              key="index"
              field="consultant_name"
              :sortable="true"
              :sortField="'consultant_name'"
            >
              <template #header>
                <div class="p-d-flex p-jc-between" @click.stop>
                  <span class="headersObs">{{ $t('headers.consultantName') }}</span>
                  <MultiSelect
                    filter
                    icon="pi pi-search"
                    :options="consultantNameDropDownData"
                    :placeholder="$t('all')"
                    v-model="consultantName"
                    @filter="handleFilter($event, 'consultantName')"
                    @change="fetchTableData(null, 'Y')"
                    class="inputtext"
                  />
                </div>
              </template>
            </Column>
            <Column key="index" field="HomeLocation" :sortable="true" :sortField="'Home_location'">
              <template #header>
                <div class="p-d-flex p-jc-between" @click.stop>
                  <span class="headersObs">{{ $t('headers.homeLocation') }}</span>
                  <MultiSelect
                    filter
                    icon="pi pi-search"
                    :options="homeLocationDropDownData"
                    :placeholder="$t('all')"
                    v-model="homeLocationn"
                    @filter="handleFilter($event, 'homeLocation')"
                    @change="fetchTableData(null, 'Y')"
                    class="inputtext"
                  />
                </div>
              </template>
            </Column>
            <Column
              key="index"
              field="clientEngagement"
              :sortable="true"
              :sortField="'client_engagement_name'"
            >
              <template #header>
                <div class="p-d-flex p-jc-between" @click.stop>
                  <span class="headersObs">{{ $t('headers.clientEngagement') }}</span>
                  <MultiSelect
                    filter
                    icon="pi pi-search"
                    :options="clientEngagementDropDownData"
                    :placeholder="$t('all')"
                    v-model="clientEngagementt"
                    @filter="handleFilter($event, 'clientEngagement')"
                    @change="fetchTableData(null, 'Y')"
                    class="inputtext"
                  />
                </div>
              </template>
            </Column>
            <Column
              key="index"
              field="LastModifiedOn"
              :sortable="true"
              :sortField="'modified_date'"
            >
              <template #header>
                <div class="p-d-flex p-jc-between" @click.stop>
                  <span class="headersObs">{{ $t('headers.lastModifiedOn') }}</span>
                  <!-- <MultiSelect  icon="pi pi-search" filter placeholder="All"
                                      @change="filterData($event, col.key)" class="inputtext" /> -->
                </div>
              </template>
            </Column>
            <Column key="index" field="status" :sortable="true" :sortField="'status'">
              <template #header>
                <div class="p-d-flex p-jc-between" @click.stop>
                  <span class="headersObs">{{ $t('headers.status') }}</span>
                  <MultiSelect
                    :options="statusData"
                    @change="fetchTableData(null, 'Y')"
                    v-model="statuses"
                    filter
                    icon="pi pi-search"
                    :placeholder="$t('all')"
                    class="inputtext"
                  />
                </div>
              </template>
            </Column>
            <template #empty>
              <div class="p-text-center" style="margin: 20px">{{ this.$t('emptyRecord') }}</div>
            </template>
            <Column
              field="edit"
              :header="$t('actions')"
              class="custom-column"
              :style="{ width: '150px' }"
              :frozen="true"
            >
              <template #body="slotProps">
                <div class="button-containerr">
                  <div class="table-icon">
                    <i
                      class="pi pi-eye eyeicon"
                      :title="$t('viewDetails')"
                      data-placement="top"
                      @click="OpenPreview(slotProps)"
                    />

                    <Button
                      type="button"
                      class="style-button"
                      icon="pi pi-ellipsis-v"
                      @click="toggle($event, slotProps)"
                      aria-haspopup="true"
                      aria-controls="overlay_menu"
                    />
                    <Menu ref="menu" id="overlay_menu" :model="items" :popup="true" />
                  </div>
                </div>
              </template>
            </Column>
          </DataTable>
        </template>
      </Card>
      <!-- </Panel> -->
    </div>
  </div>
  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
  </div>

  <Toast />
</template>

<script lang="ts">
import { globalUtilfunction } from '../../src/components/utils/globalfunctions'
import Calendar from 'primevue/calendar'
import { useToast } from 'primevue/usetoast'
import OnbService from '../shared/services/OnbService'
import axios from 'axios'
import { log } from 'console'
import moment from 'moment'
// import { ref } from 'vue';
// const menu = ref();
const globalUtilfun = new globalUtilfunction()
export default {
  components: {
    Calendar
  },
  data() {
    return {
      defaultSortField: undefined as string | undefined,
      defaultSortOrder: undefined as number | undefined,
      userDetails: '',
      isSideBar: false,
      columnName: '',
      empid: null,
      activeCard: null,
      sortBy: 'modified_date',
      sortOrder: 'DESC',
      offset: 0,
      limit: 25,
      selectDate: false,
      homeLocationn: [],
      consultantName: [],
      isDate1Active: false,
      isDate2Active: false,
      consultantId: '',
      consultantIdd: [],
      minDate: new Date(),
      toMinDate: new Date(),
      homeLocation: '',
      clientEngagement: '',
      totalRecords: '',
      lastModifiedOn: '',
      lastModifiedTime: '',
      originalUserData: [],
      totalNewOnboarding: 0,
      totalPendingOnboarding: 0,
      submittedOnboardings: 0,
      approvedOnboardings: 0,
      showSpinner: false,
      selectDays: 30,
      menu: '',
      date1: null,
      date2: null,
      selectedSpecialist: null,
      loggedId: null,
      employeeDocumentIdList: [],
      employeeDocumentData: [],
      employeeDocumentData1: [],
      userData: [],
      storeConsultantId: [],
      onboardingDocumentsTableData: [],
      status: null,
      previewDataTable: [],
      options: [
        { name: 'New Onboarding' },
        { name: 'Pending Onboarding' },
        { name: 'Submitted Onboarding' },
        { name: 'Approved Onboarding' }
      ],

      onb_spl: [],
      days: [
        { label: this.$t('days.days35'), value: 30 },
        { label: this.$t('days.days45'), value: 45 },
        { label: this.$t('days.days60'), value: 60 },
        { label: this.$t('days.days90'), value: 90 },
        { label: this.$t('days.days180'), value: 180 },
        { label: this.$t('days.days365'), value: 365 },
        { label: this.$t('days.daysCustom'), value: 0 }
      ],
      filterValue: {},
      toast: useToast(),
      storeOnboardingStatusData: [],
      statusData: [],
      clientEngagementt: [],
      multiSelectDropDownData: [],
      statuses: [],
      consultantIdDropDownData: [],
      consultantNameDropDownData: [],
      homeLocationDropDownData: [],
      clientEngagementDropDownData: [],
      isCardSelected: false,
      onbSplId: '',
      consultantData: {},
      param: null,
      pendingOnboardingStatus: [],
      newOnboardingStatus: [],
      approvedOnboardingStatus: [],
      submittedOnboardingStatus: [],
      storeAllStatusData: [],
      items: [
        {
          label: this.$t('sendEmail'),
          icon: 'pi pi-envelope',
          command: () => {
            this.resendEmail(this.empid)
          }
        },
        {
          label: this.$t('sendReminder'),
          icon: 'pi pi-clock',
          command: () => {
            this.sendCompletionReminder(this.empid)
          }
        },
        {
          label: this.$t('resendNotification'),
          icon: 'pi pi-send',
          command: () => {
            this.resendOnbDOc(this.empid)
          }
        },
        {
          label: this.$t('blockConsultant'),
          icon: 'pi pi-ban',
          command: () => {
            this.blockConsultant(this.empid)
          }
        }
      ]

      //dataId: this.$route.params.id
    }
  },
  watch: {
    date1: 'fetchData',
    date2: 'fetchData',
    searchResult: 'performFuzzySearch'
  },
  methods: {
    fetchDropdownData() {
      this.homeLocationn = []
      this.consultantName = []
      this.statuses = []
      this.consultantIdd = []
      this.clientEngagementt = []
      this.homeLocation = ''
      this.clientEngagement = ''
      this.consultantId = ''
      this.statusData = []
      this.fetchWidgetCount()
      this.fetchTableData(null, 'Y')
    },
    toggle(event: any, rowData: any) {
      this.empid = rowData.data.consultant_id
      console.log('employe Id clicked is', this.empid)
      this.$refs.menu.toggle(event)
    },

    paginate(event: any) {
      if (this.userData) {
        this.limit = event.rows
        this.offset = event.first
      } else {
        this.limit = 0
        this.offset = 0
      }
      console.log('Event', event)
      this.fetchData()
    },
    OpenPreview(rowData: any) {
      console.log('rowData', rowData)
      let consultantId = rowData.data.consultant_id

      //router.push({ path: 'my-profile', params: { consultantId } })
      this.$router.push({ path: 'my-profile-data/' + consultantId, params: { consultantId } })
    },

    sendCompletionReminder(consultantId: any) {
      this.showSpinner = true
      OnbService.getsendRemainderEmail(consultantId, this.loggedId)
        .then((response) => {
          if (response.data.success) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.remainderEmailSuccessfully'),
              life: 3000
            })
          } else {
            this.toast.add({
              severity: 'error',
              summary: this.$t('ErrorMessages.error'),
              detail: this.$t('ErrorMessages.failedRemainder'),
              life: 3000
            })
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
    },
    resendOnbDOc(consultantId: any) {
      this.showSpinner = true
      let payload = {
        employeeId: consultantId,
        employeeDocumentsId: [],
        createdBy: this.loggedId
      }
      OnbService.resendOnboardingDocuments(payload)
        .then((response) => {
          if (response.data.success) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.resendOnbDocSuccessfully'),
              life: 3000
            })
          } else {
            this.toast.add({
              severity: 'error',
              summary: this.$t('ErrorMessages.error'),
              detail: this.$t('ErrorMessages.failedOnbdoc'),
              life: 3000
            })
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
          this.toast.add({
            severity: 'error',
            summary: this.$t('ErrorMessages.error'),
            detail: this.$t('ErrorMessages.failedOnbdoc'),
            life: 3000
          })
        })
    },
    blockConsultant(consultantId: any) {
      this.showSpinner = true
      OnbService.blockCandidate(consultantId, this.loggedId)
        .then((response) => {
          if (response.data.success) {
            this.toast.add({
              severity: 'success',
              summary: this.$t('successMessages.success'),
              detail: this.$t('successMessages.candidateDeleted'),
              life: 3000
            })
            this.fetchData()
          } else {
            this.toast.add({
              severity: 'error',
              summary: this.$t('ErrorMessages.error'),
              detail: this.$t('ErrorMessages.failedtocandidateDeleted'),
              life: 3000
            })
          }
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
          this.toast.add({
            severity: 'error',
            summary: this.$t('ErrorMessages.error'),
            detail: this.$t('ErrorMessages.failedtocandidateDeleted'),
            life: 3000
          })
        })
    },
    getMessage(Data: any) {
      if (Data.success) {
        this.toast.add({
          severity: 'success',
          summary: this.$t('successMessages.success'),
          detail: this.$t('successMessages.resendEmailSuccessfully'),
          life: 3000
        })
      } else {
        this.toast.add({
          severity: 'error',
          summary: this.$t('ErrorMessages.error'),
          detail: this.$t('ErrorMessages.failedEmailsent'),
          life: 3000
        })
      }
    },
    resendEmail(employeId: any) {
      this.showSpinner = true
      let consultantId = employeId
      let resendData: any
      OnbService.getresendEmail(consultantId, this.loggedId)
        .then((response) => {
          resendData = response.data
          this.getMessage(resendData)
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
          this.toast.add({
            severity: 'error',
            summary: this.$t('ErrorMessages.error'),
            detail: this.$t('ErrorMessages.failedEmailsent'),
            life: 3000
          })
        })
    },
    activateCard(id) {
      // Update the active card when clicked
      this.activeCard = id
    },
    isActiveCard(id) {
      // Check if the card is active
      return this.activeCard === id
    },
    handleSort(event: any) {
      //if (event.originalEvent.target.classList.contains('p-sortable-column-icon') || event.originalEvent.target.dataset.pcSection === "sort" || event.originalEvent.target.ownerSVGElement == 'svg.p-icon.p-sortable-column-icon') {
      const multiSortMeta = event.multiSortMeta

      if (multiSortMeta && multiSortMeta.length > 0) {
        // For multi-column sorting, use the information from the first item in multiSortMeta
        this.sortBy = multiSortMeta[0].field
        this.sortOrder = multiSortMeta[0].order
        this.sortOrder = multiSortMeta[0].order === 1 ? 'ASC' : 'DESC'
      } else {
        // For single-column sorting
        this.sortBy = event?.sortField ? event?.sortField : 'modified_date'
        this.sortOrder = event.sortOrder
        this.sortOrder = event.sortOrder === 1 ? 'ASC' : 'DESC'
        this.defaultSortField = event?.sortField ? event?.sortField : 'modified_date'
        this.defaultSortOrder = event.sortOrder
      }
      this.fetchData()
      // }
    },

    fetchTableDatadefault() {
      this.minDate = this.toMinDate = new Date()
      this.activeCard = null
      this.showSpinner = true
      this.isVisible = true
      let startDate: any
      let endDate: any
      this.selectDays = 30
      const userDetail: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
      this.userDetails = userDetail
      this.selectedSpecialist = this.userDetails.employeId
      this.date1 = null
      this.date2 = null
      this.isDate1Active = false
      this.isDate2Active = false
      this.sortBy = 'modified_date'
      this.sortOrder = 'DESC'
      const today = new Date()
      startDate = this.formatDate(
        new Date(today.getFullYear(), today.getMonth(), today.getDate() - this.selectDays)
      )
      endDate = this.formatDate(today)
      console.log(this.selectedSpecialist)
      this.defaultSortField = ''
      this.defaultSortOrder = -1
      //console.log("The selected Id is",uId)
      OnbService.getOnboardingCount(startDate, endDate, this.selectedSpecialist)
        .then((response) => {
          this.totalNewOnboarding = response.data.data.newOnboardings
          console.log('total Onboarding', this.totalNewOnboarding)
          this.totalPendingOnboarding = response.data.data.pendingOnboardings
          this.submittedOnboardings = response.data.data.submittedOnboardings
          this.approvedOnboardings = response.data.data.approvedOnboardings
        })
        .finally(() => {
          setTimeout(() => {
            this.emitter.emit('setWorkExpTabActive', { isVisible: true })
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
      this.homeLocationn = []
      this.consultantName = []
      this.statuses = []
      this.consultantIdd = []
      this.clientEngagementt = []
      this.homeLocation = ''
      this.clientEngagement = ''
      this.consultantId = ''
      this.statusData = []
      this.onbSplId = null

      // this.onbSplId=null

      this.fetchTableData(null, 'Y', 'defaultView')
      this.getOnboardingStatus()
    },

    shouldHighlightCard(index: any) {
      return index % 2 === 0
    },
    fetchUserData() {
      OnbService.getOnbSpecialist()
        .then((response) => {
          this.onb_spl = response.data.data
          console.log(this.onb_spl)
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
    },
    handleFilter(event: any, columnName: any) {
      if (columnName == 'consultantName' && event.value != '') {
        this.columnName = event.value
      } else if (this.consultantName != '' && event.value != '') {
        const consultantName = this.consultantName
          .map((consultantName) => `'${consultantName}'`)
          .join(',')
        this.columnName = consultantName
      } else if (columnName == 'consultantName' && event.value == '') {
        this.consultantName = []
        this.columnName = ''
      } else {
        this.columnName = ''
      }
      // else{
      //   this.columnName=''
      // }
      if (columnName == 'homeLocation' && event.value != '') {
        this.homeLocation = event.value
      } else if (this.homeLocationn != '' && event.value != '') {
        const homeLocation = this.homeLocationn.map((homeLocation) => `'${homeLocation}'`).join(',')
        this.homeLocation = homeLocation
      } else if (columnName == 'homeLocation' && event.value == '') {
        this.homeLocationn = []
        this.homeLocation = ''
      } else {
        this.homeLocation = ''
      }
      if (columnName == 'clientEngagement' && event.value != '') {
        this.clientEngagement = event.value
      } else if (this.homeLocationn != '' && event.value != '') {
        const clientEngagement = this.clientEngagementt
          .map((clientEngagement) => `'${clientEngagement}'`)
          .join(',')
        this.clientEngagement = clientEngagement
      } else if (columnName == 'clientEngagement' && event.value == '') {
        this.clientEngagementt = []
        this.clientEngagement = ''
      } else {
        this.clientEngagement = ''
      }

      if (columnName == 'consultantId' && event.value != '') {
        this.consultantId = event.value
      } else if (this.consultantIdd != '' && event.value != '') {
        const consultantId = this.consultantIdd.map((consultantId) => `${consultantId}`).join(',')
        this.consultantId = consultantId
      } else if (columnName == 'consultantId' && event.value == '') {
        this.consultantIdd = []
        this.consultantId = ''
      } else {
        this.consultantId = ''
      }
      let startDate: any
      let endDate: any
      const statusString = this.statuses.map((status) => `'${status}'`).join(',')

      if (this.selectDays === 0) {
        if (this.date1 && this.date2) {
          startDate = this.formatDate(this.date1)
          endDate = this.formatDate(this.date2)
        } else {
          this.showSpinner = false
          return
        }
      } else {
        const today = new Date()
        startDate = this.formatDate(
          new Date(today.getFullYear(), today.getMonth(), today.getDate() - this.selectDays)
        )
        endDate = this.formatDate(today)
      }
      const payload = {
        userId: this.selectedSpecialist,
        roleTypeId: 2,
        endDate: endDate,
        startDate: startDate,
        defaultView: this.isCardSelected ? 'N' : 'Y',
        onboardingStatusId: this.onbSplId ? this.onbSplId : null,
        consultantId: this.consultantId ? this.consultantId : null,
        consultantName: this.columnName ? this.columnName : null,
        homeLocation: this.homeLocation ? this.homeLocation : null,
        clientEngagement: this.clientEngagement ? this.clientEngagement : null,
        lastmodifiedon: null,
        status: statusString ? statusString : null,
        fuzzySearch: columnName
      }
      // setTimeout(() => {
      this.fetchDataFromBackend(payload)
      // }, 1500)
    },
    fetchDataFromBackend(payload: any) {
      this.showSpinner = true
      OnbService.getOnbDataByFilter(payload)
        .then((responce) => {
          console.log('Responce', responce)
          if (payload.fuzzySearch == 'consultantId') {
            const id = responce?.data?.data?.consultantId
            this.consultantIdDropDownData = id ? id.toString().split(',') : ''
          }
          // this.consultantIdDropDownData.join().split(',')
          if (payload.fuzzySearch == 'consultantName') {
            const consultantName = responce?.data?.data?.consultantName
            this.consultantNameDropDownData = consultantName
              ? consultantName.toString().split(',')
              : ''
          }
          // console.log('1222', this.consultantIdDropDownData)
          if (payload.fuzzySearch == 'homeLocation') {
            const homeLocation = responce?.data?.data?.homeLocation
            this.homeLocationDropDownData = homeLocation ? homeLocation.toString().split(',') : ''
            // console.log('1222', this.homeLocationDropDownData)
          }
          if (payload.fuzzySearch == 'clientEngagement') {
            const clientEngagement = responce?.data?.data?.clientEngagement
            this.clientEngagementDropDownData = clientEngagement
              ? clientEngagement.toString().split(',')
              : ''
            // console.log('1222', this.clientEngagementDropDownData)
          }
          this.fetchData()
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
    },

    fetchData() {
      if (this.selectDays === 0 && this.date1 == null && this.date2 == null) {
        this.userData = []
        this.totalRecords = 0
        this.totalNewOnboarding = 0
        this.totalPendingOnboarding = 0
        this.submittedOnboardings = 0
        this.approvedOnboardings = 0
        this.isDate1Active = true
        this.isDate2Active = true
      }
      this.fetchWidgetCount()
      this.fetchTableData(null, 'Y')
    },
    fetchWidgetCount() {
      this.showSpinner = true
      let startDate: any
      let endDate: any
      //let uId:any;
      if (this.selectDays === 0) {
        if (this.date1 && this.date2) {
          startDate = this.formatDate(this.date1)
          endDate = this.formatDate(this.date2)
        } else {
          this.showSpinner = false
          if ((this.date1 == '' || this.date1 == null) && this.date2) {
            this.isDate1Active = true
          }
          return
        }
      } else {
        const today = new Date()
        startDate = this.formatDate(
          new Date(today.getFullYear(), today.getMonth(), today.getDate() - this.selectDays)
        )
        endDate = this.formatDate(today)
        this.date1 = null
        this.date2 = null
        this.minDate = this.toMinDate = new Date()
      }
      console.log(this.selectedSpecialist)

      //console.log("The selected Id is",uId)
      OnbService.getOnboardingCount(startDate, endDate, this.selectedSpecialist)
        .then((response) => {
          this.totalNewOnboarding = response.data.data.newOnboardings
          console.log('total Onboarding', this.totalNewOnboarding)
          this.totalPendingOnboarding = response.data.data.pendingOnboardings
          this.submittedOnboardings = response.data.data.submittedOnboardings
          this.approvedOnboardings = response.data.data.approvedOnboardings
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
    },

    fetchTableData(onboardingStatusId: any, defaultView: any, cardView?: any) {
      if (cardView) {
        this.homeLocationn = []
        this.consultantName = []
        this.statuses = []
        this.consultantIdd = []
        this.clientEngagementt = []
        this.homeLocation = ''
        this.clientEngagement = ''
        this.consultantId = ''
        this.statusData = []
      }
      this.showSpinner = true
      let startDate: any
      let endDate: any
      if (cardView == 'card') {
        defaultView = 'N'
        this.onbSplId = onboardingStatusId
        this.isCardSelected = true
      }
      if (cardView == 'cardV') {
        defaultView = 'N'
        this.onbSplId = onboardingStatusId
        this.isCardSelected = true
      }
      if (cardView == 'cardVi') {
        defaultView = 'N'
        this.onbSplId = onboardingStatusId
        this.isCardSelected = true
      }
      if (cardView == 'cardView') {
        defaultView = 'N'
        this.onbSplId = onboardingStatusId
        this.isCardSelected = true
      }
      if (cardView == 'defaultView') {
        defaultView = 'Y'
        this.isCardSelected = false
        onboardingStatusId = null
      }
      if (onboardingStatusId == 5) {
        this.statuses = []
        this.statusData = this.storeAllStatusData.filter((item: any) => {
          return item == 'New Onboardings'
        })
        // this.storeAllStatusData=this.statusData
        console.log(this.statusData)
        //    this.statusData.push(this.storeOnboardingStatusData[0].name)
      }
      if (onboardingStatusId == 6) {
        this.statuses = []
        this.statusData = this.storeAllStatusData.filter((item: any) => {
          return item == 'Pending Onboardings'
        })
        //  this.storeAllStatusData=this.statusData
      }
      if (onboardingStatusId == 7) {
        this.statuses = []
        this.statusData = this.storeAllStatusData.filter((item: any) => {
          return item == 'Submitted Onboardings'
        })
        // this.storeAllStatusData=this.statusData
      }
      if (onboardingStatusId == 8) {
        this.statuses = []
        this.statusData = this.storeAllStatusData.filter((item: any) => {
          return item == 'Approved Onboardings'
        })
        // this.storeAllStatusData=this.statusData
      }
      console.log(cardView)
      const statusString = this.statuses.map((status) => `'${status}'`).join(',')
      const consultantId = this.consultantIdd.map((consultantId) => `'${consultantId}'`).join(',')
      const consultantName = this.consultantName
        .map((consultantName) => `'${consultantName}'`)
        .join(',')
      const homeLocation = this.homeLocationn.map((homeLocation) => `'${homeLocation}'`).join(',')
      const clientEngagement = this.clientEngagementt
        .map((clientEngagement) => `'${clientEngagement}'`)
        .join(',')
      // let UserId:any;
      console.log('The default value is', this.selectDays)
      if (this.selectDays === 0) {
        if (this.date1 && this.date2 && defaultView) {
          startDate = this.formatDate(this.date1)
          endDate = this.formatDate(this.date2)
        } else {
          this.showSpinner = false
          return
        }
      } else {
        const today = new Date()
        startDate = this.formatDate(
          new Date(today.getFullYear(), today.getMonth(), today.getDate() - this.selectDays)
        )
        endDate = this.formatDate(today)
        this.date1 = null
        this.date2 = null
      }
      let Payload = {
        userId: this.selectedSpecialist,
        startDate: startDate,
        endDate: endDate,
        roleTypeId: 2,
        defaultView: !this.isCardSelected ? defaultView : 'N',
        sortBy: this.sortBy ? this.sortBy : 'modified_date',
        sortOrder: this.sortOrder,
        offset: this.offset,
        size: this.limit,
        onboardingStatusId: !this.isCardSelected ? onboardingStatusId : this.onbSplId,
        consultantId: consultantId ? consultantId : null,
        consultantName: consultantName ? consultantName : null,
        clientEngagement: clientEngagement ? clientEngagement : null,
        homeLocation: homeLocation ? homeLocation : null,
        lastmodifiedon: null,
        status: statusString ? statusString : null
      }

      OnbService.getOnboardingData(Payload)
        .then((response) => {
          this.userData = response?.data?.data?.details
          this.totalRecords = response?.data?.data?.totalRecords
          // converting time to respective usertime zone
          this.userData = this.userData.map((user) => ({
            ...user,
            LastModifiedOn: user.LastModifiedOn
              ? globalUtilfun.getCurrentDateTimeByUTC(user.LastModifiedOn)
              : ''
          }))
          this.originalUserData = response?.data?.data?.details
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
    },
    selectedDate(date: any) {
      console.log('The date is', date)
      if (this.date1 == null && this.selectDays == 0) {
        this.isDate1Active = true
        // console.log("Entered If condiation")
      } else if (this.date2 == null) {
        this.isDate2Active = true
        this.toMinDate = date
        this.date1 = date
        this.isDate1Active = false
      } else {
        this.toMinDate = date
        this.date1 = date
        this.isDate1Active = false
        // console.log("Entered else condiation")
      }
    },
    selectDate2(date: any) {
      console.log('The date is', date)
      if (this.date2 == null && this.selectDays == 0) {
        if (this.date1 == null && this.selectDays == 0) {
          this.isDate2Active = true
          this.isDate1Active = true
        } else {
          this.isDate2Active = true
        }
        this.isDate2Active = true
        //console.log("Entered If condiation")
      } else {
        if (this.date2 == null && this.selectDays == 0) {
          this.isDate2Active = true
        }
        // this.toMinDate=date;
        this.date2 = date
        this.isDate2Active = false
        //console.log("Entered else condiation")
        this.fetchData()
      }
    },
    filterData(event: any, field: any) {
      // Apply the filter to the data
      const filterValue = event.target.value.toLowerCase()
      this.userData = this.originalUserData.filter((user) => {
        const cellValue = user[field]
        return cellValue.toString().toLowerCase().includes(filterValue)
      })
    },
    filterDataa(field: any) {
      // Apply the filter to the data
      const filterValue = this.filterValue[field].toLowerCase()
      this.userData = this.originalUserData.filter((user: any) => {
        const cellValue = user[field].toString().toLowerCase()
        return cellValue.includes(filterValue)
      })
    },
    formatDate(date: any) {
      const dd = String(date.getDate()).padStart(2, '0')
      const mm = String(date.getMonth() + 1).padStart(2, '0')
      const yyyy = date.getFullYear()
      return `${mm}/${dd}/${yyyy}`
    },

    getOnboardingStatus() {
      OnbService.getOnboardingStatuses().then((response) => {
        this.storeOnboardingStatusData = response?.data?.data[0]?.status
        // console.log("Status responce",this.storeOnboardingStatusData)
        this.storeOnboardingStatusData.map((name: any) => {
          this.statusData.push(name.name)
          this.storeAllStatusData = this.statusData
          //  console.log('Status',this.statusData)
        })
        console.log('Status', this.statusData)
      })
    }
  },
  mounted() {
    const userDetail: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.userDetails = userDetail
    this.selectedSpecialist = this.userDetails.employeId
    this.loggedId = this.selectedSpecialist
    console.log('Fetched Uid of specialist', this.loggedId)
    this.emitter.emit('setWorkExpTabActive', { isVisible: (this.isSideBar = !this.isSideBar) })
    this.fetchUserData()
    this.fetchWidgetCount()
    this.fetchTableData(null, 'Y')
    this.getOnboardingStatus()
    // this.fetchUserData(null,'Y')
  }
}
</script>

<style lang="scss" scoped>
.card.active {
  /* Add your styles for the active card here */
  border: 2px solid rgb(83, 185, 225);
}

.app-container {
}
.header {
  font-family: 'Poppins', Helvetica;
  font-weight: 500;
  color: #000000;
  font-size: 16px;
  letter-spacing: 0.16px;
  /* letter-spacing: 0.16px;
    line-height: 50px; */
  white-space: nowrap;
}

.app-containerr {
  /* position: relative; */
}

.container {
  /* margin-left: -12.1rem; */
  display: flex;
  align-items: flex-end;
  gap: 25px;
  justify-content: flex-start;
  float: center;
  padding: 4px;
  margin-bottom: 2rem;
  /* flex-wrap: wrap; */
}
.viewDropDown {
  height: 30px;
  width: 200px;
  margin-right: 50px;
  border: 0px;
}

@media (max-width: 1100px) {
  /* margin-left: -12.1rem; */
  .container {
    display: flex;
    align-items: center;
    gap: 30px;
    float: center;
    flex-wrap: wrap;
    flex-direction: row;
    align-content: flex-start;
  }
}

/* .button {
      margin-left: auto;
      height: 42px;
      width: 149px;
  } */
/* .table-icon{
      display: flex;
      align-items: center;
      justify-content: center;
      align-items: center;
  } */

.choose {
  display: flex;
  align-items: flex-start;
  margin-right: 10px;
  gap: 5px;
  flex-direction: column;
}
.modificatoin {
  white-space: nowrap;
}
.headersObs {
  font-family: 'Poppins', Helvetica;
  font-weight: 650;
  color: #000000;
  font-size: 13px;
  text-align: center;
  letter-spacing: 0.5px;
  line-height: 35px;
  white-space: nowrap;
}
.pi-ban {
  cursor: not-allowed;
}
.pi-eye {
  cursor: pointer;
}
.pi-clock {
  cursor: not-allowed;
}
.from {
  margin-right: 10px;
  font-family: 'Poppins', Helvetica;
  font-weight: 300;
  color: #000000;
  font-size: 14px;
}
/* .eyeicon{
    padding: 5px 5px;
    width: auto;
    background-color: #03a9f4;
    font-size: 13px;
    box-shadow: none;
    border: solid 1px #0288D1;
    color: #fff;
    margin-right: 10px;
    border-radius: 3px;
    margin-left: 10px;


  } */
/* .eyeicon:hover{
  background: #ccc;
  color: #000;
  } */
.pi-refresh {
  cursor: not-allowed;
}
.label,
span {
  margin-right: 5px;
  margin-right: 5px;
  display: flex;
  justify-content: center;
}
.inputtext[data-v-0be5a92f] {
  width: 229px;
  height: 30px;
}

.small-calendar :deep {
  .p-button {
    padding: 6px 10px !important;
    /* width: 100px;height: 100px; */
  }
}
.selectlabel {
  display: flex;
  flex-direction: row;
}
.pi-envelope {
  cursor: pointer;
}

.card {
  border-radius: 5px !important;
  height: 82px;
  text-align: left;
  border-radius: 3px;
  overflow: hidden;
  margin: 1.3rem 0rem 1rem 0rem;
  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
}

.card .content {
  padding: 1rem;
}

.card .footer {
  background-color: rgba(255, 255, 255, 0.8);
  padding: 0.5rem;
}
.current_month {
  /* padding: 0px 110px; */
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 200px;

  h4 {
    margin-top: 0px;
    margin-bottom: 10px;
  }
}

.card:hover {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
  transform: translateY(-2px);
  transition:
    transform 0.2s,
    box-shadow 0.2s;
}

.card:nth-child(even) {
  background-color: #f5f5f5;
}

.card:nth-child(odd) {
  background-color: #ffffff;
}

.tcount {
  font-size: 26px;
  font-weight: 500;
  margin-left: 72px;
  line-height: normal;
  margin-top: 1rem;
  color: #e5760b;
}
.acount {
  font-size: 26px;
  font-weight: 500;
  margin-left: 72px;
  color: green;
  line-height: normal;
  margin-top: 1rem;
}
.ncount {
  font-size: 26px;
  font-weight: 500;
  margin-left: 72px;
  /* margin: -18px 51px 0px 70px; */
  color: #03a9f4;
  line-height: normal;
  margin-top: 1rem;
}
.view {
  width: 200px;
  display: flex;
  justify-content: flex-start;
  flex-direction: column;
  align-items: flex-start;
}
h4 {
  margin-top: 0px;
  margin-bottom: 10px;
}
.rcount {
  font-size: 26px;
  font-weight: 500;
  margin-left: 72px;
  line-height: normal;
  margin-top: 1rem;
  color: #757070;
}
.stext {
  text-transform: uppercase;
  color: #777;
  font-weight: 600;
}

.onboarding {
  font-family: 'Poppins', Helvetica;
  font-weight: 600;
  color: #000000;
  font-size: 12px;
  letter-spacing: 0.6px;
  line-height: 0px;
  white-space: nowrap;
  text-align: center;
}

.p-datatable {
  margin-top: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.p-datatable .p-datatable-thead > tr > th {
  text-align: left;
  padding: 1rem;
  border: 1px solid #e9ecef;
  border-width: 0 0 1px 0;
  font-weight: 600;
  color: #333;
  background: #f8f9fa;
  transition: box-shadow 0.2s;
}

.p-datatable .p-datatable-thead > tr > th:hover {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.p-datatable .p-datatable-tbody > tr > td {
  border-width: 0 0 1px 1px;
  border: 1px solid #e9ecef;
  padding: 0.7rem;
}
.p-datatable .p-datatable-tbody > tr > td {
  border-width: 0 0 1px 1px;
  border: 1px solid #e9ecef;
  padding: 0.7rem;
}

.inputtext {
  width: 150px;
  height: 30px;
}

.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

@media (max-width: 1000px) {
  .p-toggleable-content {
    overflow: scroll !important;
    display: flex;
  }
}
.p-datatable .p-datatable-thead > tr > th {
  text-align: left;
  /* padding: 1rem; */
  border: 1px solid #e9ecef;
  border-width: 0 0 1px 0;
  font-weight: 600;
  color: #333;
  background: #f8f9fa;
  transition: box-shadow 0.2s;
}
.defaultbutton {
  width: 131px;
  height: 32px;
  font-size: 11px;
  /* margin-right: 50px; */
  background: #0070cd;
  border-radius: 4px;
  border: 1px solid #0070cd;
}
/* .button-containerr {
      display: flex;
      justify-content: space-between;

  } */
.p-invalid {
  color: red;
}
.candidate {
  color: rgb(3, 177, 246);
  text-decoration: underline;
}
.inputtext1 {
  /* width: 100%; */
  height: 1.875rem;
  padding: 0px 10px !important;
  box-shadow: none;
  font-size: 14px !important;
  font-weight: 400 !important;
}

@media (max-width: 1000px) {
  .p-toggleable-content {
    overflow: scroll !important;
    display: flex !important;
  }
}

.grid {
  display: flex;
  flex-wrap: wrap;
  margin-right: 0rem;
  margin-left: 0rem;
}

@media (max-width: 984px) {
  .grid {
    /* margin-top: 7rem; */
  }
}

@media (max-width: 738px) {
  .grid {
    /* margin-top: 10rem; */
  }
}

@media (max-width: 468px) {
  .grid {
    /* margin-top: 12rem; */
  }

  .choose {
    display: flex;
    align-items: center;
    margin-right: 10px;
  }
}

/* @media (max-width: 397px) {
      .container {
          margin-top: 3rem;
      }

      .grid {
          margin-top: 13rem;
      }
  } */
/* 
      .p-panel .p-panel-content {
          align-items: stretch;
          padding: 1rem;
          border: 1px solid #dee2e6;
          background: #ffffff;
          color: #495057;
          border-top: 0 none;
          display: contents;
      } */
@media (max-width: 1000px) {
  .p-panel .p-panel-content {
    align-items: stretch;
    padding: 1rem;
    border: 1px solid #dee2e6;
    background: #ffffff;
    color: #495057;
    border-top: 0 none;
  }
}
.menu-design {
  padding: 3px 0px 3px 0px;
  border: 1px solid #03a9f4;
}
.menu-design:hover {
  background: #ccc;
  color: #000;
}
.style-button {
  background: none;
  border: none;
  color: black;
}
.card {
  cursor: pointer;
}
/* .p-panel .p-panel-content:last-child {
      border-bottom-right-radius: 3px;
      border-bottom-left-radius: 3px;
  } */

.select {
  font-family: 'Poppins', Helvetica;
  font-weight: 500;
  color: #000000;
  font-size: 16px;
  letter-spacing: 0.16px;
  /* letter-spacing: 0.16px;
    line-height: 50px; */
  white-space: nowrap;
  margin-bottom: 5px;
}
.toFromClass {
  position: relative;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}

.alignment {
  position: absolute;
  top: 40px;
}
</style>
