<template>
  <div v-if="dashboardDetails?.length">
    <div style="width: -webkit-fill-available">
      <div class="dashboard-knob">
        <Knob
          readonly
          v-model="progressValue"
          textColor="#0070cd"
          valueColor="#0070cd"
          valueTemplate="{value}%"
          :strokeWidth="2"
        />
      </div>
      <p class="candidate-dashboard-text">{{ $t('candidateDashboard') }}</p>
      <DashboardStepper />
      <h2 v-if="taskNameArr.length" style="text-align: left" class="text-above-taskstable">
        {{ $t('completeOnboardingProcess') }}
      </h2>
      <div v-if="taskNameArr.length" class="data-table-tasks custom-scroll-bar">
        <DataTable
          :value="taskNameArr"
          tableStyle="width: 100%"
          class="data-table candidate-dashboard-table"
          scrollable
        >
          <Column :header="$t('headers.nextStep')">
            <template #body="slotProps">
              <div
                style="font-weight: 300; color: #000000; font-size: 16px; letter-spacing: 0.16px"
              >
                {{ taskNameArr[slotProps.index]?.taskName }}
                {{ taskNameArr[slotProps.index]?.templateName }}
              </div>

              <div>
                <Button
                  :disabled="!!slotProps.index"
                  @click="handleStarClick(slotProps)"
                  size="small"
                  :class="taskStatus[slotProps.index] === 'RESUME TASK' && 'italics-font'"
                  >{{ $t(taskStatus[slotProps.index]) }}</Button
                >
              </div>
            </template>
          </Column>
        </DataTable>
      </div>
    </div>
  </div>
  <!-- <Dialog
    v-model:visible="welcomeBack"
    :style="{ width: '55vw' }"
    :modal="true"
    :draggable="false"
    class="welcomeDialog"
    
    :breakpoints="{ '2992': '50vw', '1100px': '75vw', '575px': '75vw','575px': '70vh' }"
  >
    <div class="total-card">
      <div class="card-responsive">
        <div class="card-text">
          <div>
            <div class="rectangle"></div>
            <div style="margin-top:115px">
              <h2 class="welcomeBackText " >{{ $t('welcomeBack') }}</h2>
              <div class="userName">{{userName}}</div>
              <p class="textClass">{{ $t('textMessage') }}</p>
            </div>
          </div>

          <div  class="card-setup">
            <div class="vertical-stepper">
              <div class="heading_stepper">
                <div class="circle">
                  <img src="../assets/vector-26.svg">
                </div>
                <div class="myProfile">
                  {{ $t('myProfileLabel') }}
                </div>
              </div>
              <div class="middle_section">
                <div class="vertical_line">
                  <div><img src="../assets/images/vector-27.svg" height="50px"></div>
                  <div class="success_line" ><img src="../assets/images/vector-28.svg" height="107px"> <span class="dark_circle"></span> </div>
                  </div>
                <div  v-if="value=='33'" class="whole_box flex align-items-center">
                  <div><img src="../assets/images/polygon-3.svg"></div>
                  <div class="message_box">
                    <b>{{value}}% </b><br>
                    {{ $t('Complete') }}
                  </div>
                </div>
              </div>
              <div class="heading_stepper">
                <div class="circle">
                  <img  v-if="value=='66'" src="../assets/vector-26.svg">
                </div>
                <div class="myProfile">
                  {{ $t('pendingOnboarding') }}<br/>
                  {{ $t('documents') }}
                </div>
              </div>
              <div class="middle_section">
                <div class="vertical_line2">
                  <div><img src="../assets/images/vector-27.svg" height="80px"></div>
                  <div  v-if="value=='66'" class="success_line" ><img src="../assets/images/vector-28.svg" height="107px"> <span class="dark_circle"></span> </div>
                  </div>
                <div  v-if="value=='66'" class="whole_box flex align-items-center">
                  <div><img src="../assets/images/polygon-3.svg"></div>
                  <div  class="message_box">
                    <b>{{value}}% </b><br>
                    {{ $t('Complete') }}
                  </div>
                </div>
              </div>
              <div class="heading_stepper">
                <div class="circle">
                  <img>
                </div>
                <div class="myProfile">
                  {{ $t('myOnboardingLabel') }}<br/>
                  {{ $t('documents') }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Dialog> -->
</template>

<script lang="ts">
import onbService from '../shared/services/OnbService'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import DashboardStepper from '@/components/DashboardStepper.vue'
import { sidebarStore } from '@/stores/side-bar'
import { computed, ref } from 'vue'
export default {
  setup() {
    const sidebarStoreData: any = sidebarStore()
    const progress = ref(0)
    // logUrls.value = proxyDataStore.getLogos;
    // loginLogo.value = logUrls.value.filter((el: any) => el.imageName == 'loginLogo');
    // logUrls = proxyDataStore.logoUrls;
    // console.log("loginLogo", loginLogo.value);
    // console.log("getLogos", logUrls);
    const progressValue = computed(() => sidebarStoreData.$state.progress)
    return {
      sidebarStoreData,
      progressValue,
      progress
    }
  },
  components: { DashboardStepper },
  data() {
    return {
      empId: '',
      ele: '',
      active: 0,
      activeStep: 0,
      loggedEmpId: null,
      dashboardDetails: [],
      taskNameArr: [],
      btnIndex: 1,
      taskStatuses: [],
      userName: '' as string | null,
      welcomeBack: false,
      products: [
        { code: this.$t('completeProfileCreation'), edit: this.$t('data1') },
        { code: this.$t('completeDocumentation'), edit: this.$t('data2') },
        { code: this.$t('completeVerification'), edit: this.$t('data3') },
        { code: this.$t('completeEducationalInformation'), edit: this.$t('data3') }
      ],

      notificationData: [
        { code: this.$t('notificationData'), edit: this.$t('data1') },
        { code: this.$t('notificationData'), edit: this.$t('data2') },
        { code: this.$t('notificationData'), edit: this.$t('data3') },
        { code: this.$t('notificationData'), edit: this.$t('data4') },
        { code: this.$t('notificationData'), edit: this.$t('data5') }
      ],
      //items:[],
      items: [
        { label: this.$t('createProfile') },
        { label: this.$t('initiateOnboardingSteps') },
        { label: this.$t('submitOnboardingDocuments') }
      ],
      // items1: [
      //         { label:this.taskName[0] },
      //         { label:this.taskName[1]},
      //         { label:this.taskName[2] },
      //         { label:this.taskName[3]},
      //         { label:this.taskName[4]}
      //     ],
      value: 0,
      taskStatus: []
    }
  },
  beforeCreate() {
    const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.empId = userDetails.employeeId
    onbService
      .getDashboardData(this.empId)
      .then((res: any) => {
        this.dashboardDetails = res?.data?.data?.employeeTaskDetails

        let ownArr = []
        ownArr = res.data.data.employeeTaskDetails.filter((item) => {
          return item.taskStatus.name != 'Completed'
        })
        ownArr.forEach((item) => {
          if (item.task.taskId != 3 && item.task.taskId != 4) {
            this.taskNameArr.push(item.task)

            if (item.taskStatus.name == 'Open') {
              this.taskStatus.push('startTask')
            } else {
              this.taskStatus.push('resumeTask')
            }
          }
        })

        this.dashboardDetails.forEach((item: any) => {
          this.taskStatuses.push(item.taskStatus.name)
        })
        this.value = res?.data?.data?.progress
        // this.sidebarStoreData.$patch({progress: this.value})
        this.sidebarStoreData.setProgress(this.value)
        if (this.value > 0 && this.value < 99) {
          // this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
          this.welcomeBack = true
        } else {
          this.welcomeBack = false
        }

        onbService.getOnboardingDocuments(res.data.data.employeeId).then((res: any) => {
          this.taskNameArr = []
          this.taskStatus = []
          const arr = res.data.data
            .map((item) => {
              return item.employeeDocumentsList
            })
            .map((res: any, index: any) => {
              res.map((doc: any, index: any) => {
                if (doc?.statusId != 4) {
                  this.taskNameArr.push(doc.templatePackage.template)
                }
                if (doc?.statusId == null || doc?.statusId == 1) {
                  this.taskStatus.push('startTask')
                } else if (doc?.statusId == 2) {
                  this.taskStatus.push('resumeTask')
                }
                // else{
                //     this.taskStatus.push(doc?.statusId)
                // }
              })
            })
          //this.taskNameArr=this.sortedArray(this.taskNameArr);
        })

        setTimeout(() => {
          this.ele = document.getElementsByClassName('p-steps-item')
          if (this.taskStatuses[2] == 'Completed') {
            for (let i = 0; i <= this.ele.length; i++) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.remove('p-disabled')
            }
          } else if (this.taskStatuses[1] == 'Completed') {
            for (let i = 0; i <= this.ele.length; i++) {
              if (i == 2) {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.add('active-orange')
                this.ele[i]?.classList.remove('p-disabled')
              } else {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.remove('p-disabled')
              }
            }
          } else if (this.taskStatuses[0] == 'Completed') {
            for (let i = 0; i <= this.ele.length - 2; i++) {
              if (i == 1) {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.add('active-orange')
                this.ele[i]?.classList.remove('p-disabled')
              } else {
                this.ele[i]?.classList.add('p-highlight')
                this.ele[i]?.classList.remove('p-disabled')
              }
            }
          } else {
            for (let i = 0; i <= 0; i++) {
              this.ele[i]?.classList.add('p-highlight')
              this.ele[i]?.classList.add('active-orange')
              this.ele[i]?.classList.remove('p-disabled')
            }
          }
        }, 300)
      })

      .catch((error: any) => {
        console.log(error)
      })
  },
  mounted() {
    const userDetail: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
    this.loggedEmpId = userDetail.employeeId
    this.userName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME)
  },
  methods: {
    sortedArray(array: any[]) {
      return array.slice().sort(function (a, b) {
        return a.documentName > b.documentName ? 1 : -1
      })
    },
    isHidePreview() {
      return this.togglepreview
    },
    isButtonDisabled(index: any) {
      return index >= this.btnIndex
    },
    handleStarClick(index: any) {
      let taskName
      if (index.data.taskName) {
        taskName = index.data.taskName //If it is complete Profile the it will assign
      } else {
        taskName = index.data.templateName //If it is not complete profile it will assign corresponding document name
      }
      onbService
        .startTaskRemainderEmail(this.loggedEmpId, taskName)
        .finally(() => {
          setTimeout(() => {}, 1000)
        })
        .catch((error) => {
          console.error(error)
        })
      if (index.data.templateId || index.data.taskName == 'Pending Onboarding Documents') {
        this.$router.push('/onb/initiate-info')
        sessionStorage.setItem('externaltemplateId', index.data.extTemplateId)
        sessionStorage.setItem('fieldJson', index.data.templateFieldMapping.fieldJson)
        sessionStorage.setItem('templateName', index.data.templateName)
        sessionStorage.setItem('templateId', index.data.templateId)
      }
      if (index.data.taskName == 'Complete Profile') {
        this.$router.push('/onb/my-profile')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-knob {
  display: none;
}

.preview {
  display: none;
}
.btn {
  text-transform: uppercase;
  width: 100px;
  position: sticky;
}

.knob {
  float: left;
  position: relative;
  bottom: 17px;
}
/* @media(max-width:550px){
.p-datatable-table{
width: 5rem;
}
} */
.chart-container {
  display: flex;
  margin-left: 10px;
}
.chart {
  width: 100%;
}

.p-panel-content {
  padding: 35px 10px;
}

.sidebar {
  position: relative;
}

.menu {
  display: flex;
  column-gap: 20px;
  margin-right: 30px;
}
@media (max-width: 1260px) {
  .chart-container {
    display: flex;
    flex-direction: column;
    margin-left: 8px;
  }
}
.p-datatable-wrapper {
  width: 100%;
}
/* .chart>DataTable{
  min-width: 55rem !important;
}} */
@media (max-width: 1500px) {
  .sidebar {
    position: relative;
    background: white;
  }
}

.p-panel .p-panel-content {
  padding: 1rem;
  border: 1px solid #dee2e6;
  background: #c91717;
  color: #495057;
  border-top: 0 none;
}
@media (max-width: 860px) {
  .p-steps .p-steps-list {
    padding: 0;
    margin: 0;
    list-style-type: none;
    /* display: none; */
    flex-direction: column;
    align-items: left;
    align-items: stretch;
  }
}
@media (min-width: 860px) {
  .pagelabel {
    display: none;
  }
  .pagelabel2 {
    display: none;
  }
}
@media (max-width: 860px) {
  .pagelabel {
    display: flex;
    font-weight: 700;
    align-items: center;
    /* white-space: nowrap; */
  }
  .pagelabel2 {
    font-weight: 400;
    display: flex;
    align-items: baseline;
    font-size: 14px !important;
  }
  .knob {
    margin-top: 10px;
    margin-bottom: -20px;
  }
}

.knob {
  float: left;
  position: relative;
  bottom: 17px;
  display: flex;
  justify-content: space-between;
}
.heading_stepper {
  display: flex;
  align-items: center;
}
.circle {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border: 1px solid #0070cd;
  margin-right: 24px;
}
.circle img {
  margin: 8px 4px;
}
.total-card {
  margin: 20px 65px;
}
.middle_section {
  display: flex;
  flex-direction: row;
}
.vertical_line {
  display: flex;
  margin: 4px 0 4px 13px;
}
.vertical_line2 {
  display: flex;
  margin: 4px 0 4px 16px;
  /* border:1px solid gray */
}
.message_box {
  width: 112px;
  height: 64px;
  background-color: #0070cd;
  border-radius: 20px;
  color: #fff;
  text-align: center;
  align-items: center;
  padding: 10px;
}
.success_line {
  display: flex;
  flex-direction: column;
  margin-left: -6px;
}
.dark_circle {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #0070cd;
}
.loginsso {
  width: 235px;
  margin-top: 2rem;
}
.rectangle {
  width: 65px;
  position: absolute;
  top: 0px;
  height: 140px;
  background: #0070cd;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
}
.vertical-stepper {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* {
min-width: 40rem !important;
 
} */
.candidate-dashboard-text {
  margin: 0;
  font-weight: 500;
  color: #0070cd;
  font-size: 20px;
  letter-spacing: 0.2px;
  line-height: 50px;
  white-space: nowrap;
  text-align: left;
  margin-top: -21px;
}

.text-above-taskstable {
  font-weight: 400;
  color: #000000;
  font-size: 20px;
  letter-spacing: 0.2px;
  line-height: 50px;
  white-space: break-spaces;
  line-height: 1.5rem;
}

@media only screen and (max-width: 750px) {
  .text-above-taskstable {
    font-size: 15px;
  }

  .data-table-tasks {
    margin-top: 50px;
  }
}
@media only screen and (max-width: 520px) {
  .candidate-dashboard-text {
    text-align: center;
    font-size: 15px;
  }
}

.data-table-tasks:deep {
  .p-datatable-wrapper {
    overflow-x: hidden !important;
    max-height: 100px;
  }

  .p-datatable {
    .p-datatable-tbody > tr > td {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .p-datatable-tbody > tr {
      // line-height: 5;
    }
  }

  @media (max-width: 700px) {
    .p-datatable {
      .p-datatable-tbody {
        > tr > td {
          flex-direction: column;
        }
      }
      .p-datatable-tbody > tr {
        line-height: 3;
      }
    }
    .candidate-dashboard-table {
      .p-button {
        width: 100% !important;
        height: 30px;
      }
    }
  }

  @media (max-width: 2600px) {
    .p-datatable-wrapper {
      max-height: 400px;
    }
  }

  @media (max-width: 2000px) {
    .p-datatable-wrapper {
      max-height: 300px;
    }
  }

  @media (max-width: 1700px) {
    .p-datatable-wrapper {
      max-height: 400px;
    }
  }

  @media (max-width: 1300px) {
    .p-datatable-wrapper {
      max-height: 300px;
    }
  }

  @media (max-width: 600px) {
    .p-datatable-wrapper {
      max-height: 400px;
    }
  }
}

.candidate-dashboard-table :deep {
  .p-datatable-table {
    padding-right: 20px;
  }
  .p-datatable-thead {
    display: none;
  }

  .p-button {
    // vertical-align: middle;
    // width: 200px;
    // padding: 10px 15px;
    // justify-content: center;
    // height: fit-content;
    // background-color: #0070cd;
    font-size: 13px;
    text-transform: uppercase;
  }
}
@media (max-width: 1100px) {
  .dashboard-knob {
    display: block;
  }
  .candidate-dashboard-text {
    text-align: center;
    font-size: 15px;
  }
}
</style>
