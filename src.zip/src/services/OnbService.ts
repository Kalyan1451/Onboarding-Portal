import http from '../http-common'
import { proxyUrl } from '@/msalConfig'

// const proxyUrl = "https://ol-npsitonboardingsvcsftr.innovasolutions.com:42000/onboarding";
import urls from '../assets/url-parameters.json'
class OnbService {
  appTrackUrl(url: any, key: any) {
    const appTrackData = JSON.parse(localStorage.getItem('AppTrackData') || '{}')
    const userDetails: any = JSON.parse(localStorage.getItem('userDetails') || '{}')
    const empId = userDetails.employeeId
    if (appTrackData && appTrackData[key] == 'Y') {
      return url + '&eventkey=' + key + '&eventUserId=' + empId
    } else {
      return url
    }
  }
  getTrackerList(): Promise<any> {
    const url = proxyUrl + '/USER-TRACK/onbrd/eventtracking'
    return http.get(url)
  }
  getCountryList(): Promise<any> {
    const url = proxyUrl + urls.CountryList
    const configUrl = this.appTrackUrl(url, 'CountryList')
    return http.get(configUrl)
  }
  getEmployeeData(id: any): Promise<any> {
    const url = proxyUrl + urls.EmployeeData + id + '/tasktype/1'
    const configUrl = this.appTrackUrl(url, 'EmployeeData')
    return http.get(configUrl)
  }
  getPreferredContact(): Promise<any> {
    const url = proxyUrl + urls.PreferredContact
    const configUrl = this.appTrackUrl(url, 'PreferredContact')
    return http.get(configUrl)
  }
  getLanguages(): Promise<any> {
    const url = proxyUrl + urls.Languages
    const configUrl = this.appTrackUrl(url, 'Languages')
    return http.get(configUrl)
  }
  getStatus(): Promise<any> {
    const url = proxyUrl + urls.Status
    const configUrl = this.appTrackUrl(url, 'Status')
    return http.get(configUrl)
  }
  getDashboardData(id: any): Promise<any> {
    const url = proxyUrl + urls.DashboardData + id + '/tasktype/1'
    const configUrl = this.appTrackUrl(url, 'DashboardData')
    return http.get(configUrl)
  }
  login(loginPayload: any): Promise<any> {
    const url = proxyUrl + urls.Login
    const configUrl = this.appTrackUrl(url, 'Login')
    return http.post(configUrl, loginPayload)
  }
  employeeSave(empPayload: any): Promise<any> {
    const url = proxyUrl + urls.SaveEmployee
    const configUrl = this.appTrackUrl(url, 'SaveEmployee')
    return http.post(configUrl, empPayload)
  }
  getOnboardingData(payload: any): Promise<any> {
    const url = proxyUrl + urls.obsDashboard
    const configUrl = this.appTrackUrl(url, 'obsDashboard')
    return http.post(configUrl, payload)
  }
  getOnbSpecialist(): Promise<any> {
    const url = proxyUrl + urls.OnbSpecialist
    const configUrl = this.appTrackUrl(url, 'OnbSpecialist')
    return http.get(configUrl)
  }
  getOnbSpecialistUserId(payload: any): Promise<any> {
    const url = proxyUrl + urls.ObsSpecilaistValidation
    const configUrl = this.appTrackUrl(url, 'ObsSpecilaistValidation')
    return http.put(configUrl, payload)
  }
  getOnboardingCount(startDate: any, endDate: any, uId: any): Promise<any> {
    const url =
      proxyUrl +
      urls.OnboardingCount +
      '?userId={{uId}}&roleType=2&startDate={{startDate}}&endDate={{endDate}}'
    const configUrl = url
      .replace('{{startDate}}', startDate)
      .replace('{{endDate}}', endDate)
      .replace('{{uId}}', uId)
    const finalUrl = this.appTrackUrl(configUrl, 'OnboardingCount')
    return http.get(finalUrl)
  }

  getOnboardingDocuments(empId: any): Promise<any> {
    const url = proxyUrl + urls.OnboardingDocuments + empId + '/category/1'
    const configUrl = this.appTrackUrl(url, 'OnboardingDocuments')
    return http.get(configUrl)
  }

  submitDocuments(docId: any, categoryId: any): Promise<any> {
    // /v1/documents/employeedocument/{employeeDocumentId}/status/{statusId}
    const url = proxyUrl + urls.EmployeeDocument + docId + '/status/' + categoryId
    const configUrl = this.appTrackUrl(url, 'EmployeeDocument')
    return http.get(configUrl)
  }
  getOnbDataByFilter(payload: any): Promise<any> {
    const url = proxyUrl + urls.OnbDataByFilter
    const configUrl = this.appTrackUrl(url, 'OnbDataByFilter')
    return http.post(configUrl, payload)
  }
  getOnboardingStatuses(): Promise<any> {
    const url = proxyUrl + urls.OnboardingStatuses
    const configUrl = this.appTrackUrl(url, 'OnboardingStatuses')
    return http.get(configUrl)
  }
  getResetPasswordLink(email: any): Promise<any> {
    const url = proxyUrl + urls.ResetPasswordLink + email
    const configUrl = this.appTrackUrl(url, 'ResetPasswordLink')
    return http.get(configUrl)
  }
  tokenValidation(userId: any, token: any): Promise<any> {
    const url = proxyUrl + urls.tokenValidation + userId + '/token/' + token
    const configUrl = this.appTrackUrl(url, 'tokenValidation')
    return http.get(configUrl)
  }
  saveResetPassword(payload: any): Promise<any> {
    const url = proxyUrl + urls.saveResetPassword
    const configUrl = this.appTrackUrl(url, 'saveResetPassword')
    return http.post(configUrl, payload)
  }
  getToken(email: any): Promise<any> {
    const url = '/jwttoken/' + email
    return http.get(url)
  }
  addOnboardingDocumentsData(empId: any): Promise<any> {
    const url = proxyUrl + urls.OnboardingDocumentsData + empId + '/notpresent/category/1'
    const configUrl = this.appTrackUrl(url, 'OnboardingDocumentsData')
    return http.get(configUrl)
  }
  sendOnboardingDocumentsData(payload: any): Promise<any> {
    const url = proxyUrl + urls.AddNewEmployeedocument
    const configUrl = this.appTrackUrl(url, 'AddNewEmployeedocument')
    return http.post(configUrl, payload)
  }
  getresendEmail(consultantId: any, userId: any): Promise<any> {
    const url = proxyUrl + urls.WelcomeEmail + '?employeeId={{employeeId}}&createdBy={{createdBy}}'
    const configUrl = url.replace('{{employeeId}}', consultantId).replace('{{createdBy}}', userId)
    const finalUrl = this.appTrackUrl(configUrl, 'WelcomeEmail')
    return http.post(finalUrl, {})
  }
  getsendRemainderEmail(consultantId: any, userId: any): Promise<any> {
    const url = proxyUrl + urls.RemainderMail + '?candidateId={{employeeId}}&userId={{userId}}'
    const configUrl = url.replace('{{employeeId}}', consultantId).replace('{{userId}}', userId)
    const finalUrl = this.appTrackUrl(configUrl, 'RemainderMail')
    return http.get(finalUrl)
  }
  blockCandidate(consultantId: any, userId: any) {
    const url = proxyUrl + urls.blockCandidate + '?candidateId={{employeeId}}&userId={{userId}}'
    const configUrl = url.replace('{{employeeId}}', consultantId).replace('{{userId}}', userId)
    const finalUrl = this.appTrackUrl(configUrl, 'blockCandidate')
    return http.get(finalUrl)
  }
  resendOnboardingDocuments(payload: any): Promise<any> {
    const url = proxyUrl + urls.resendOnbDocuments
    const configUrl = this.appTrackUrl(url, 'resendOnbDocuments')
    return http.post(configUrl, payload)
  }
  deleteOnboardingDocuments(empDocumentId: any, userId: any): Promise<any> {
    const url = proxyUrl + urls.DeleteOnbDocuments + '{{employeeDocumentId}}/userid/{{userId}}'
    const configUrl = url
      .replace('{{employeeDocumentId}}', empDocumentId)
      .replace('{{userId}}', userId)
    const finalUrl = this.appTrackUrl(configUrl, 'DeleteOnbDocuments')
    return http.delete(finalUrl)
  }
  openPreviewDataTable(empId: any) {
    const url = proxyUrl + urls.PreviewData + empId + '/category/1'
    const configUrl = this.appTrackUrl(url, 'PreviewData')
    return http.get(configUrl)
  }
}
export default new OnbService()
