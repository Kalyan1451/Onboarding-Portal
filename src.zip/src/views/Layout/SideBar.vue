<template>
  <div class="menu">
    <card class="sidebarcard">
      <template #content>
        <div v-if="userRole == 'Consultant'">
          <Knob readonly v-model="sidebarStoreData.getProgress" textColor="#0070cd"  valueColor="#0070cd" valueTemplate="{value}%" :strokeWidth="12" />
                </div>
        <div class="sidebar">
          <PanelMenu v-if="userRole == 'Consultant'" :model="items">
            <template #item="{ item }">
              <!-- <span  v-if="item.icon" class="menu-icons-content">
            <i :class="item.icon"></i>
          </span> -->
              <!-- <span > {{ item.label }} </span> -->
              <div :class="[isIconActive(item) === item.label ? 'icon-border': null]">
              <span v-if="item.icon" :class="['menu-icons-content', isIconActive(item) === item.label ? 'icon-highlight': null]">
                    <i  :class="item.icon"></i>
                  </span>
              <router-link v-if="item.routePath" v-slot="{ href, navigate }" :to="item.routePath">
                <a v-ripple :href="href" @click="navigate">                  
                  <span>{{ item.label }}</span>
                </a>
              </router-link>
              <a v-else v-ripple :href="item.url" :target="item.target">
                <span v-if="!item.routeUrl" :class="currentUrlRoute==='pending-documents' || currentUrlRoute==='complete-documents' ? 'active-header' : null">{{ item.label }}</span>
                <span v-if="item.routeUrl" >
                  <router-link :to="item.routeUrl">
                    {{ item.label }}
                  </router-link>
                </span>            
              </a>
              </div>
            </template>
          </PanelMenu>
          <!-- <PanelMenu :model="items" /> -->
          <PanelMenu v-if="userRole == 'InnovaTeam'" :model="onbItems">
            <template #item="{ item }">
              <!-- <span v-if="item.icon" class="menu-icons-content">
                <i :class="item.icon"></i>
              </span>
              {{ item.label }} -->
              <div :class="[isIconActiveonb(item) === item.label ? 'icon-border': null]">
              <span v-if="item.icon" :class="['menu-icons-content', isIconActiveonb(item) === item.label ? 'icon-highlight': null]">
                    <i :class="item.icon"></i>
                  </span>
              <router-link v-if="item.routePath" v-slot="{ href, navigate }" :to="item.routePath">
                <a v-ripple :href="href" @click="navigate">                  
                  <span>{{ item.label }}</span>
                </a>
              </router-link>
              <a v-else v-ripple :href="item.url" :target="item.target">
                <span v-if="!item.routeUrl">{{ item.label }}</span>
                <span v-if="item.routeUrl">
                  <router-link :to="item.routeUrl">
                    {{ item.label }}
                  </router-link>
                </span>            
                <!-- <span>{{ item.label }}</span> -->
              </a>
              </div>
              <!-- <span :class="{'menu-item-sidebar' : item.active}" @click="resetMenuItemActiveClass(items)"> {{ item.label }} </span> -->
              <!-- <span :class="[item.focused, 'menu-item-sidebar']" > {{ item.label }} </span> -->
            </template>
          </PanelMenu>
        </div>
      </template>
    </card>
  </div>
  <div v-if="isSidebarVisible" class="sidebarphone">
    <PanelMenu v-if="userRole == 'Consultant'" :model="items2">
      <template #item="{ item }">
        {{ item.label }}
        <div :class="['menu-item', { active: isActiveItem(item) }, item.icon]" @click="handleClick(item.label)" />
      </template>
    </PanelMenu>
 
    <PanelMenu v-if="userRole == 'InnovaTeam'" :model="onbItems" class="onb-sidebar" />
  </div>
</template>
 
<script lang="ts">
import PanelMenu from 'primevue/panelmenu'
// import NavBar from './NavBar.vue'
import onbService from '../../shared/services/OnbService'
import { LOCAL_STORAGE_VARIABLES } from '../../shared/constant/local-storage-variables'
import { FILE_PATH } from '../../shared/constant/file-path'
import { CONSULTANT_CONST_INFO } from '../../shared/constant/consultant_const_info'
import { sidebarStore } from '@/stores/side-bar'
import { computed, ref } from 'vue'
export default {
  setup() {
    const sidebarStoreData: any = sidebarStore()
    const progress = ref(0)
    const progressValue = computed(() => sidebarStoreData.$state.progress)
    return {
      sidebarStoreData,
      progressValue,
      progress
    }
  },
  components: {
    PanelMenu
  },
  props: ['isSidebarVisible'],
  data() {
    return {
      previewDisable: true,
      personalDisable: false,
      activeItem: null,
      showSideBar: true,
      taskPercentage: '',
      subEmployeeTasks: [],
      subEmployeeTaskStatus: [],
      userRole: '',
      userDetails: {},
      currentUrlRoute: 'onb/consultant-dashboard',
      // isDashboards: '',
      items: [
        {
          label: this.$t('dashboardLabel'),
          active: false,
          icon: 'pi pi-th-large',
          class: '  ',
          routePath: '/onb/consultant-dashboard',
          // focused:true,
          // disabled: true,
          command: () => {
            // this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD) //'/onb/consultant-dashboard'
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.add('p-highlight')
            }
          }
        },
        //{
        //  label: 'Create Template',
        //  command: () => {
        //    this.$router.push('/onb/create-template')
        //  }
        // },
        {
          label: this.$t('myProfileLabel'),
          active: false,
          icon: 'pi pi-user-edit',
          routePath: '/onb/my-profile',
          // active: this.$route.name == 'my-profile' ? true : false,
          // class: this.currentRouteName() == 'onb/my-profile'? 'menu-item-sidebar': '',
          command: () => {
            // this.$router.push('/onb/my-profile')
            // this.$emit('personalInfo', 'personal-info')
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.remove('p-highlight')
            }
          },
          // icon: 'pi pi-chevron-down',
          items: [
            // {
            //   events: [
            {
              label: this.$t('personalInformationLabel'),
              // disabled: this.personalDisable,
              // active:true,
              focused: true,
              command: () => {
                this.emitter.emit('myProfile', { value: 0 })
                // this.$emit('myProfile', 'personal-info')
              }
            },
            {
              label: this.$t('contactInformation'),
              // disabled: this.personalDisable,
              command: () => {
                this.emitter.emit('myProfile', { value: 1 })
                // this.$emit('myProfile', 'contact-info')
              }
            },
            {
              label: this.$t('EmergencyContact'),
              // disabled: this.personalDisable,
              command: () => {
                this.emitter.emit('myProfile', { value: 2 })
                // this.$emit('myProfile', 'emergency-info')
              }
            },
            {
              label: this.$t('homeAddress'),
              // disabled: this.personalDisable,
              command: () => {
                this.emitter.emit('myProfile', { value: 3 })
                // this.$emit('myProfile', 'home-info')
              }
            },
            // {
            //   label: this.$t('previewLabel'),
            //   disabled: this.previewDisable
            // }
          ]
          //   }
          // ]
        },
        {
          label: this.$t('myOnboardingLabel'),
          icon: 'pi pi-server',
          class: 'onbstyle-candidate',
          command: () => {
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.remove('p-highlight')
            }
          },
          items: [
            {
              label: this.$t('pendingonbordingdocuments'),
              routeUrl: '/onb/pending-documents',
              class:'pending-onb',
              disabled: false,
              // routerLink: ["onb/pending-documents"]
              command: () => {
                // this.$router.push('/onb/pending-documents')
              }
            },
            // {
            //   label: this.$t('verifyInfomation'),
            //   disabled: false,
            //   command: () => {
            //     this.$emit('verifyInfomation', 'verify-Infomation')
            //   }
            // },
            {
              label: this.$t('completeonbdocuments'),
              disabled: false,
              class:'pending-onb',
              routeUrl: '/onb/complete-documents',
              command: () => {
                // this.$router.push('/onb/complete-documents')
              }
            }
 
            // {
            //   label: this.$t('submitOnboarding'),
            //   disabled: true,
            //   command: () => {
            //     this.$router.push('submit-onboarding-docs')
            //   }
            // }
          ]
        }
      ],
 
      items2: [
        {
          label: this.$t('dashboardLabel'),
          icon: 'pi pi-th-large',
          command: () => {
            this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD) //'/onb/consultant-dashboard'
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.add('p-highlight')
            }
            this.$emit('closeSideBar')
          }
        },
        //{
        //  label: 'Create Template',
        //  command: () => {
        //    this.$router.push('/onb/create-template')
        //  }
        // },
        {
          label: this.$t('myProfileLabel'),
          icon: 'pi pi-user-edit',
          command: () => {
            // this.$router.push('/onb/my-profile')
            this.$emit('personalInfo', 'personal-info')
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.remove('p-highlight')
            }
          },
          // icon: 'pi pi-chevron-down',
          items: [
            // {
            //   events: [
            {
              label: this.$t('personalInformationLabel'),
              // disabled: this.personalDisable,
              command: () => {
                // this.$emit('personalInfo', 'personal-info')
                this.$emit('closeSideBar'), this.emitter.emit('myProfile', { value: 'personal-info' })
              }
            },
            {
              label: this.$t('contactInformation'),
              disabled: this.personalDisable,
              command: () => {
                // this.$emit('personalInfo', 'personal-info')
                this.$emit('closeSideBar'), this.emitter.emit('myProfile', { value: 'contact-info' })
              }
            },
            {
              label: this.$t('EmergencyContact'),
              disabled: this.personalDisable,
              command: () => {
                // this.$emit('personalInfo', 'personal-info')
                this.$emit('closeSideBar'), this.emitter.emit('myProfile', { value: 'emergency-info' })
              }
            },
            {
              label: this.$t('homeAddress'),
              disabled: this.personalDisable,
              command: () => {
                // this.$emit('personalInfo', 'personal-info')
                this.$emit('closeSideBar'), this.emitter.emit('myProfile', { value: 'home-info' })
              }
            }
 
          ]
          //   }
          // ]
        },
        {
          label: this.$t('myOnboardingLabel'),
          class: 'onbstyle',
          icon: 'pi pi-server',
 
          // icon: 'pi pi-chevron-down',
          command: () => {
            const element = document.getElementsByClassName('p-panelmenu-header')
            for (let i = 0; i <= 0; i++) {
              element[i]?.classList.remove('p-highlight')
            }
          },
          items: [
            {
              label: this.$t('pendingonbordingdocuments'),
              disabled: false,
              command: () => {
                this.$router.push('/onb/pending-documents'),
                  this.$emit('closeSideBar')
              }
            },
            // {
            //   label: this.$t('verifyInfomation'),
            //   disabled: false,
            //   command: () => {
            //     this.$emit('verifyInfomation', 'verify-Infomation')
            //   }
            // },
            {
              label: this.$t('completeonbdocuments'),
              disabled: false,
              // class: onbstyle,
              command: () => {
                this.$router.push('/onb/complete-documents'),
                  this.$emit('closeSideBar')
              }
            }
 
            // {
            //   label: this.$t('submitOnboarding'),
            //   disabled: true,
            //   command: () => {
            //     this.$router.push('submit-onboarding-docs')
            //   }
            // }
          ]
        },
        {
          label: this.$t('logout'),
          icon: 'pi pi-sign-out',
          class: 'logoutclass',
          command: () => {
            sessionStorage.clear()
            this.$router.push(FILE_PATH.LOGIN) // '/login'
          }
        }
      ],
 
      // User: [
      //   {
      //     label: this.userName,
      //     icon: 'pi pi-user'
      //   }
      // ],
      Userss: [
        {
          label: this.$t('logOut'),
          icon: 'pi pi-sign-out',
          command: () => {
            sessionStorage.clear()
            this.$router.push(FILE_PATH.LOGIN) // '/login'
          }
        }
      ],
      onbItems: [
        {
          label: this.$t('dashboardLabel'),
          active: true,
          disabled: false,
          class:'dash-temponb',
          icon: 'pi pi-th-large',
          routePath: '/onb/onb-spl',
          command: () => {
            // this.$router.push(FILE_PATH.ONB_SPL) //'/onb/onb-spl'
            if (this.$route.path.includes(FILE_PATH.ONB_SPL)) {
              //'/onb/onb-spl'
              // window.location.reload()
            }
          }
        },
        {
          label: this.$t('createTemplate'),
          icon: 'pi pi-book',
          disabled: false,
          class:'create-temponb',
          routePath: '/onb/create-template',
          command: () => {
            // this.$router.push('/onb/create-template')
          }
        }
      ]
    }
  },
  computed: {
    isOnbSplRoute() {
      return this.$route.path.includes(FILE_PATH.ONB_SPL) //'/onb/onb-spl'
    },
    isActiveItem() {
      return (item: any) => this.activeItem === item.label
    },
    // currentRouteName() {
    //   console.log("this.$route.name", this.$route.name)
    //     return this.$route.name;
    // }
  },
 
  watch: {
    $route(to, from) {
      console.log("to, from", to)
      // this.show = false;
      if (to) {
        this.currentUrlRoute = to.name
      } else {
        const routeUrl: any = this.$route.name
        this.currentUrlRoute = routeUrl
      }
    }
  },
 
  methods: {
    isIconActive(iconative: any){
      console.log('iconative',iconative)
      if(this.currentUrlRoute == 'consultant-dashboard'){
        return this.$t('dashboardLabel')
      }
      else if(this.currentUrlRoute == 'my-profile'){
        return this.$t('myProfileLabel')
      }
      else if(this.currentUrlRoute == 'complete-documents' || this.currentUrlRoute == 'pending-documents'){
        return this.$t('myOnboardingLabel')
      }
    },
    isIconActiveonb(iconativeOnb: any){
      console.log('iconativeOnb',iconativeOnb)
      console.log('current',this.currentUrlRoute)

      if(this.currentUrlRoute == 'onbspl'){
        return this.$t('dashboardLabel')
      }
      else if(this.currentUrlRoute == 'create-template'){
        return this.$t('createTemplate')
      }
    },
    checkClick(){
      return false;
    },
    currentRouteName() {
      console.log("this.$route.name", this.$route.name)
      const route: any = this.$route.name;
      this.currentUrlRoute = route;
      // return this.$route.name;
    },
    resetMenuItemActiveClass(event: any) {
      console.log("event", event)
      event.some((ele: any) => {
        ele.active = false
      })
      return event.active = true;
    },
    emitEvents(evt: any) {
 
    },
    /*
    makeeducationDisable(event: any) {
      this.educationDisable = event
    },
    */
    displaySideBar() {
      this.showSideBar = true
    },
 
    //emits the screens & sub-screens based on the clicks on the sidebar menu options
    handleClick(events: any) {
      if (events === this.$t('dashboardLabel')) {
        this.$router.push({ name: 'consultant-dashboard' })
        this.activeItem = events
      } else {
        this.activeItem = events
      }
      if (events == this.$t('personalInformationLabel')) {
        this.$emit('personalInfo', 'personal-info')
      } else if (events == this.$t('previewLabel')) {
        this.$emit('preview', 'preview')
      }
      this.activeItem = events
    },
 
    onComponentLoad() {
      this.previewDisable = true
      this.personalDisable = false
      const userDetails: any = JSON.parse(
        sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
      ) //sessionStorage.getItem('userDetails')
      const userLoggedName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME) //sessionStorage.getItem('loggedInUserName')
      // this.userName = userLoggedName
 
      // The service gives the Candidate status details and used to make changes in the stepper values.
      const empId = userDetails.employeeId
      // onbService.getDashboardData(empId).then((res: any) => {
      //   if (res.data.data) {
      //     this.taskPercentage = res?.data?.data?.employeeTaskDetails[0]?.subTask?.percentage
      //     res?.data?.data?.employeeTaskDetails?.forEach((item: any) => {
      //       this.subEmployeeTasks.push(item?.subTask?.subEmployeeTask)
      //     })
 
      //     this.subEmployeeTasks[0]?.forEach((item: any) => {
      //       this.subEmployeeTaskStatus.push(item?.taskStatus?.name)
      //     })
      //     const element = document.getElementsByClassName('p-panelmenu-header')
      //     for (let i = 0; i <= element.length; i++) {
      //       if (i == 0) {
      //         element[i]?.classList.add('p-highlight')
      //       } else {
      //         element[i]?.classList.remove('p-highlight')
      //       }
      //     }
 
      //     this.items.map((resp: any) => {
      //       if (resp.label == this.$t('myProfileLabel')) {
      //         //By defalut personal enable
      //         const ele = document.getElementsByClassName('p-timeline-event-marker')
      //         const ele1 = document.getElementsByClassName('p-timeline-event-connector')
      //         if (this.subEmployeeTaskStatus[0] == CONSULTANT_CONST_INFO.STATUS_OPEN) {
      //           // 'Open'
      //           for (let i = 0; i <= 0; i++) {
      //             ele[i]?.classList.add('active-orange')
      //           }
      //           for (let j = 0; j <= 0; j++) {
      //             ele1[j]?.classList.add('active-orange')
      //           }
      //         }
      //         if (this.subEmployeeTaskStatus[0] == CONSULTANT_CONST_INFO.STATUS_COMPLETE) {
      //           //'Completed'
      //           resp.items[0].events[1].disabled = false
      //           for (let i = 0; i <= ele.length - 1; i++) {
      //             if (i == 1) {
      //               ele[i]?.classList.add('active-orange')
      //             } else {
      //               ele[i]?.classList.add('active-green')
      //             }
      //           }
      //           for (let j = 0; j <= ele1.length - 1; j++) {
      //             if (j == 1) {
      //               ele1[j]?.classList.add('active-orange')
      //             } else {
      //               ele1[j]?.classList.add('active-green')
      //             }
      //           }
      //         }
      //         if (this.subEmployeeTaskStatus[1] == CONSULTANT_CONST_INFO.STATUS_COMPLETE) {
      //           //'Completed'
      //           for (let i = 0; i <= ele.length; i++) {
      //             ele[i]?.classList.add('active-green')
      //           }
      //           for (let j = 0; j <= ele1.length - 1; j++) {
      //             ele1[j]?.classList.add('active-green')
      //           }
      //         }
      //       }
      //     })
      //   }
      // })
    },
    setActiveMenu() {
      const currentPath = this.$route.path;
      const activeItem = this.items.find((item) => item.to === currentPath);
      this.items.every((item) => item.active === false);
      // console.log("activeItem", activeItem)
      console.log("activeItem1", this.items)
      if (activeItem) {
        activeItem.active = true;
      }
    }
  },
 
  mounted() {
    this.currentRouteName()
    this.setActiveMenu()
    this.$router.afterEach(() => {
      this.setActiveMenu();
    });
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.userDetails = userDetails;
    this.userRole = userDetails.userRole
    // console.log("Sidebar userDetails", this.progress)
    this.onComponentLoad();
  },
 
  created() {
    this.emitter.on('setPreviewTabActive', (evt: any) => {
      this.items.map((res: any) => {
        if (res.label == this.$t('myProfileLabel')) {
          res.items[0].events[1].disabled = false
        }
      })
      this.previewDisable = false
    })
    // this.emitter.on('setWorkExpTabActive', (evt: any) => {
    //   this.showSideBar = true
    // })
  }
}
</script>
 
<style lang="scss" scoped>
.sidebar {
  border: none;
  width: 17rem;
}

.pending-onb{
  a.active {
    color: #0070cd !important;
    font-weight: 600;
    margin-left: 0px;
}}

a.active {
    color: #0070cd !important;
    font-weight: 600;
}
a.active  {
  a{
    span{
      color: #0070cd !important;
    font-weight: 600;
    }
  }

}

a{
    span{
      color: #000 !important;
    font-weight: 200;
    a{
      color: #000 !important;

    }
    }
  }
 
.p-panelmenu-header-content > a :active {
  color: orange;
}
// .p-submenu-list > li .p-menuitem{
//   color: #0070cd;
// }
// .myknob :deep{
//   .p-knob-text{
//     letter-spacing: 0.18px;
//     font-size: 0.7rem;
//     text-align: center;
//     display: flex;
//     flex-direction: column-reverse;
//     flex-wrap: nowrap;
//   }
// }
@media (max-width: 1100px) {
  .sidebar {
    padding: 5px 0px 0px 5px;
    border: none;
    border-right: solid 1px #ced4da;
    width: 207px;
    background-color: white;
    z-index: 10;
    position: absolute;
  }
}
 
/* .p-panelmenu .p-panelmenu-header .p-panelmenu-header-content{
    border: none;
    border-bottom: none;
    background-color: white;
    border-radius: 0%;
    padding: 10px;
    font-weight: 300;
} */
 
.menu {
  /* background-color: #fff; */
  height: 82vh;
  width: 22rem;
  display: flex;
  column-gap: 20px;
}
 
@media (max-width: 1100px) {
  .sidebarcard {
    display: none;
  }
 
  .menu {
    width: 0px;
    height: 0vh !important;
  }
 
  .sidebarphone {
    display: flex;
    margin-left: 1rem;
    margin-top: 6rem;
  }
}
 
.sidebar :deep {

  .active-header{
    color: #0070cd !important;
  }
  .p-panelmenu .p-panelmenu-panel {
    letter-spacing: 1.2px;
  }
 
  .p-panelmenu-header-content {
    // color: #000;
    // margin-left: 56px;;
    cursor: pointer;


 
   .router-link-exact-active :active{
      color: orange;
    }
  }
 
  // .p-panelmenu .p-panelmenu-header:not(.p-disabled).p-highlight .p-panelmenu-header-content {
  //   font-weight: 600;
  //   letter-spacing: 0.7px;
  //   padding-left: 4rem;
  //   cursor: pointer;
  //   color: #0070cd;
  //   border-left: 3px solid #0070cd;
 
  // }
 
  .p-panelmenu .p-panelmenu-content .p-menuitem>.p-menuitem-content {
    // white-space: nowrap;
    text-align: -webkit-left;
    color: #000;
    font-size: 13px;
    cursor: pointer;
 
  }
 
  .p-panelmenu .p-panelmenu-content .p-panelmenu-root-list {
    outline: 0 none;
    padding-left: 4rem;
  }
}
 
@media (min-width: 1101px) {
  .sidebarphone {
    display: none;
  }
}
 
.sidebarphone :deep {
  .p-panelmenu-header .p-panelmenu-header-content {
    font-size: 16px;
    position: relative;
    width: 27rem;
    height: 6vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #305faf;
    margin-left: 14rem;
    // margin-right: 15px;
    color: #fff;
    font-weight: 100;
    letter-spacing: 1px;
  }
 
  .p-panelmenu .p-panelmenu-header:not(.p-disabled).p-highlight .p-panelmenu-header-content {
    background-color: white;
    color: #fff;
    border: none;
    padding: 10px;
    /* padding: 11px; */
    font-weight: bold;
    letter-spacing: 1px;
  }
 
  .p-panelmenu .p-panelmenu-panel {
    margin: 1px;
  }
 
  .p-panelmenu-content .p-menuitem>.p-menuitem-content {
    background: #305faf;
  }
 
  .p-panelmenu .p-panelmenu-content .p-menuitem>.p-menuitem-content {
    background: #305faf !important;
    margin-left: 24rem;
    border: 6px solid #305faf;
    color: #eee;
    white-space: nowrap;
    letter-spacing: 1.1px;
    height: 5vh;
  }
 
  .p-panelmenu-header:not(.p-disabled).p-highlight .p-panelmenu-header-content {
    background: #305faf !important;
  }
 
  .p-panelmenu .p-panelmenu-content {
    padding: 0px;
    background: #305faf;
    margin-bottom: 1rem;
  }
 
  .p-panelmenu .onbstyle {
    .p-panelmenu-header-content {
      margin-left: 15.3rem !important;
    }
  }
 
  .p-panelmenu .logoutclass {
    .p-panelmenu-header-content {
      display: flex;
      flex-direction: row-reverse;
      align-items: flex-start;
      /* margin-left: 14rem; */
      padding-left: 10px;
 
      .pi-sign-out {
        margin-right: 10px;
      }
    }
  }
}
 
@media (min-width: 960px) {
  .hideUser {
    display: none;
    line-height: 1;
    border: none;
    background-color: red;
    color: black;
    cursor: pointer;
    font-weight: 400;
    padding: 0px;
  }
}
 
// .p-panelmenu .p-panelmenu-header:not(.p-disabled).p-highlight .p-panelmenu-header-content {
/* background-color: #03a9f4; */
/* color: #0070cd; */
/* padding: 11px; */
 
.selecte-color {
  background-color: white;
  color: #0070cd;
}
 
.p-panelmenu-header-action {
  padding: 5px;
}
 
@media (max-width: 1101px) {
  .sidebarcard {
    padding: 0px;
    margin: 0px;
  }
 
  .sidebarcard {
    // background: #fff !important;
  }
 
  .menu {
    /* background-color: #fff; */
    height: 82vh;
    width: -1rem !important;
    display: flex;
    column-gap: 20px;
  }
}
 
.menu-item-sidebar {
  font-weight: 600;
  letter-spacing: 0.7px;
  padding-left: 4rem;
  background-color: white;
  color: #0070cd;
  border-left: 3px solid #0070cd;
}
 
// .p-panelmenu .p-panelmenu-header:not(.p-disabled).p-highlight .p-panelmenu-header-content {
//   background-color: white;
//   color: #0070cd !important;
//   border-left: 3px solid #0070cd;
//   padding: 10px;
//  }
.icon-highlight{
  color: #0070cd !important;
  font-size: 7rem;
}
 
.menu-icons-content {
  align-items: center;
  border: 1px solid var(--surface-border);
  border-radius: var(--border-radius);
  display: inline-flex;
  height: 2rem;
  justify-content: center;
  margin-right: .5rem;
  transition: all .2s;
  width: 2rem;
  margin-left: 56px;
}
.icon-border{
 border-left: 3px solid #0070cd;

}</style>