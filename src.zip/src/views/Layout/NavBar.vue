<template>
  <Toast class="toastdesign" />
  <div class="layout-topbar">
    <div class="card">
      <div class="align-part1 col-6 md:col-6 lg:col-8">
        <!-- <Button class="button-container" icon="pi pi-bars" @click="displaySideBar" /> -->
        <Button
          style="background: #305faf; border: none"
          class="button-container1"
          icon="pi pi-bars"
          @click="displaySideBar"
        />

        <img class="imagenavbar" :src="getLogoPath(navLogoUrl)" />
        <span class="app-name">{{ $t('onboarding') }}</span>
      </div>
      <div class="align-part2 col-6 md:col-6 lg:col-3">
        <div class="style-logout">
          <Avatar
            @mouseover="toggle"
            @mouseleave="toggle"
            class="mr-2 designavatar"
            size="small"
            style="background-color: #5587da; color: #ffffff"
            shape="circle"
            >{{ firstName }}{{ lastName }}</Avatar
          >
          <i class="pi pi-sign-out mr-2 mt-2" @click="dialogClose()"></i>
          <OverlayPanel ref="op" class="overlay-navstyle">
            <Menu :model="items" class="preview-menu" />
          </OverlayPanel>
        </div>
        <div>
          <p class="last-login">
            {{
              lastloginDetailsObs
                ? $t('lastLogin') + lastloginDetailsObs
                : $t('lastLogin') + lastloginDetails
            }}
          </p>
        </div>
      </div>
      <!-- <Menubar class="design" :model="navBarItems">
        <template #start> -->
      <!-- <Button class="button-container" icon="pi pi-bars" @click="displaySideBar" /> -->
      <!-- <Button class="button-container1" icon="pi pi-chevron-right" @click="displaySideBar" /> -->

      <!-- <span class="layout-topbar-logo"> -->
      <!-- <img src="@/assets/logo.png" /> -->
      <!-- <img src="../../assets/logo.png" /> -->
      <!-- <img :src="getLogoPath(navLogoUrl)" /> -->
      <!-- <img :src="getLogoPath(navLogoUrl)" /> -->
      <!-- <img :src="'../..'+proxyDataStore.getNavLogo" /> -->
      <!-- </span>
          
          <span class="app-name">{{ $t('onboarding') }}</span>
          <Avatar icon="pi pi-user" class="mr-2" size="large" style="background-color: #2196f3; color: #ffffff" shape="circle" />

        </template>
      </Menubar> -->
    </div>
  </div>
  <Dialog
    :showHeader="false"
    v-model:visible="logoutDialog"
    :style="{ width: '23rem' }"
    :position="position"
    :modal="true"
    class="logout-popup"
    :closable="false"
    :draggable="false"
    :breakpoints="{ '468px': '18rem' }"
  >
    <div class="w-full flex flex-column align-items-center justify-content-center gap-4 py-3">
      <div class="logout-text">
        <b>{{ $t('logoutAlert') }}</b>
      </div>

      <div class="dialogcontent">
        {{ $t('logoutPopupAlert') }}
      </div>
      <div>
        <Button :label="$t('close_msg')" @click="close" severity="danger" class="close-btn mr-2" />
        <Button
          class="close-btn ml-2"
          :label="$t('logOut_Close')"
          @click="logOut"
          severity="danger"
        />
      </div>
    </div>
  </Dialog>
</template>
<script lang="ts">
import { globalUtilfunction } from '../../components/utils/globalfunctions'
import { CONSULTANT_CONST_INFO } from '../../shared/constant/consultant_const_info'
import { FILE_PATH } from '../../shared/constant/file-path'
import { LOCAL_STORAGE_VARIABLES } from '../../shared/constant/local-storage-variables'
import { useProxyDataStore } from '@/stores/proxy-data'
import { useToast } from 'primevue/usetoast'
import { computed, ref } from 'vue'
import moment from 'moment'
// import OnbService from '../../services/OnbService';
const globalUtilfun = new globalUtilfunction()
export default {
  setup() {
    const proxyDataStore: any = useProxyDataStore()
    const logUrls = ref([])
    const loginLogo = ref(null)
    logUrls.value = proxyDataStore.getLogos
    // loginLogo.value = logUrls.value.filter((el: any) => el.imageName == 'loginLogo');
    // logUrls = proxyDataStore.logoUrls;
    // console.log("loginLogo", loginLogo.value);
    // console.log("getLogos", logUrls);
    const navLogoUrl = computed(() => proxyDataStore.$state.navLogo)
    return {
      proxyDataStore,
      logUrls,
      loginLogo,
      navLogoUrl
    }
  },
  name: 'NavBar',
  data() {
    return {
      toast: useToast(),
      logoutDialog: false,
      isInnovaTeam: true,
      menuVisible: false,
      isSideBar: false,
      lastloginDetails: '',
      lastloginDetailsObs: '',
      userEmail: '',
      obsEmail: '',
      firstName: '',
      lastName: '',
      items: [
        { label: 'Email:' + this.userEmail, icon: 'pi pi-user' },
        { label: 'Settings', icon: 'pi pi-cog' }
      ],
      navBarItems: [
        this.lastloginDetailsObs
          ? {
              icon: 'pi pi-bell',
              class: 'notification-icon',
              badge: '1',
              disabled: true
            }
          : null,
        {
          label: this.userName,
          icon: 'pi pi-user',
          class: 'p-disabled'
        },
        {
          label: this.lastloginDetailsObs
            ? this.$t('lastLogin') + this.lastloginDetailsObs
            : this.$t('lastLogin') + this.lastloginDetails,
          icon: 'pi pi-clock',
          class: 'p-disabled'
        },
        {
          // label: this.$t('logOut'),
          icon: 'pi pi-sign-out',
          command: () => {
            this.dialogClose()
          },
          class: 'menu-logout'
        }
      ].filter(Boolean),
      userName: ''
    }
  },
  beforeCreate() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.userEmail = userDetails.email
    console.log('Consultant', this.userEmail) ///consultant

    //To fetch userEmail name for Obs email for place in login circle
    const userDetails2: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')
    this.obsEmail = userDetails2.username
    if (this.obsEmail) {
      this.userEmail = this.obsEmail
    }

    //     const userDetails: any = JSON.parse(
    //       sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    //     ) //sessionStorage.getItem('userDetails')
    // this.userEmail=userDetails.username
    //     const userLoggedName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME) //sessionStorage.getItem('loggedInUserName')
    //    console.log(userLoggedName);
    //     const names =userLoggedName.split(',');
    //     console.log(names);
    //     this.firstName = names[0]?.trim().charAt(0);
    //     this.lastName = names[1]?.trim().charAt(0);
    //       console.log("firstName",this.firstName);
    //       console.log("lastName",this.lastName);

    //     const userLoggedNameObs =
    //       sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.OBS_LAST_LOGIN_DETAILS) != 'undefined'
    //         ? JSON.parse(sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.OBS_LAST_LOGIN_DETAILS)) //sessionStorage.getItem('lastLogindetailsObs')
    //         : ''
    //     this.lastloginDetailsObs = userLoggedNameObs
    //     this.userName = userLoggedName
    //     this.lastloginDetails = userDetails.lastLoginDetails
  },

  methods: {
    toggle(event: any) {
      this.$refs.menu.toggle(event)
    },

    logOut() {
      this.logoutDialog = true
      const userDetails: any = JSON.parse(
        sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
      ) //sessionStorage.getItem('userDetails')
      if (userDetails.userRole == CONSULTANT_CONST_INFO.INNOVATEAM_ROLE) {
        //'InnovaTeam'
        sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.ROUTE_INNOVA_TEAM, JSON.stringify(true)) //sessionStorage.setItem('routeInnovaTeam')
      }
      //this.$router.push(FILE_PATH.LOGIN) //'/login'
      // console.log("kNFVKfbk kbvfu;k bskb");
      // if(this.logoutDialog){
      //   console.log("kNFVKfbk kbvfu;k bskb");

      //   this.toast.add({
      //     severity: 'success',
      //     summary: this.$t('successMessages.success'),
      //     detail: this.$t('successMessages.logout_msg'),
      //     life: 3000,
      //   })
      // }
      this.toast.add({
        severity: 'success',
        summary: this.$t('successMessages.success'),
        detail: this.$t('successMessages.logout_msg'),
        life: 3000
      })
      setTimeout(() => {
        if (userDetails.userRole == CONSULTANT_CONST_INFO.INNOVATEAM_ROLE) {
          sessionStorage.clear()
          this.$router.push(FILE_PATH.ONB_SPL_LOGIN)
        } else {
          sessionStorage.clear()
          this.$router.push(FILE_PATH.LOGIN)
        }
      }, 1000)
      // this.$router.push(FILE_PATH.LOGIN)
    },

    getLogoPath(img: string): string {
      const defaultLogoUrl: string = '/innova/navBarLogo.png'
      img = img ? img : defaultLogoUrl
      return img ? new URL(img, import.meta.url).href : ''
    },

    displaySideBar() {
      console.log('this.isSideBar1', this.isSideBar)
      this.emitter.emit('setWorkExpTabActive', { isVisible: (this.isSideBar = !this.isSideBar) })
      console.log('this.isSideBar2', this.isSideBar)
    },

    // This is for the logout icon in NavBar
    close() {
      this.logoutDialog = false
    },

    // This is used at the logout dialog box.
    dialogClose() {
      this.logoutDialog = true
    },
    toggle(event: any) {
      this.$refs.op.toggle(event)
      console.log('yaahhoo')
    }
  },
  mounted() {
    const userDetails: any = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) || '{}'
    ) //sessionStorage.getItem('userDetails')

    const userLoggedName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME) //sessionStorage.getItem('loggedInUserName')
    console.log(userLoggedName)
    const names = userLoggedName.split(' ')
    console.log(names)
    this.firstName = names[0]?.trim().charAt(0)
    this.lastName = names[1]?.trim().charAt(0)
    console.log('firstName', this.firstName)
    console.log('lastName', this.lastName)
    const userLoggedNameObs =
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.OBS_LAST_LOGIN_DETAILS) != 'undefined'
        ? JSON.parse(sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.OBS_LAST_LOGIN_DETAILS)) //sessionStorage.getItem('lastLogindetailsObs')
        : ''
    this.lastloginDetailsObs = userLoggedNameObs
    this.userName = userLoggedName
    this.lastloginDetails = userDetails.lastLoginDetails
    // this.lastloginDetails = new Date().toLocaleDateString() + " " + new Date().toLocaleTimeString();
    // this.lastloginDetailsObs = new Date('2024-01-18 14:57:01' + " UTC").toLocaleDateString() +" " + new Date('2024-01-18 14:57:01' + " UTC").toLocaleTimeString();
    //The time is modified into respective Timezone time
    if (userDetails?.userRole == 'InnovaTeam') {
      this.lastloginDetailsObs = moment(this.lastloginDetailsObs, 'MM/DD/YYYY HH:mm:ss').format(
        'YYYY-MM-DD HH:mm:ss'
      )
      this.lastloginDetailsObs = globalUtilfun.getCurrentDateTimeByUTC(this.lastloginDetailsObs)
    } else {
      this.lastloginDetails = moment(this.lastloginDetails, 'MM/DD/YYYY HH:mm:ss').format(
        'YYYY-MM-DD HH:mm:ss'
      )
      this.lastloginDetails = globalUtilfun.getCurrentDateTimeByUTC(this.lastloginDetails)
    }
    document.getElementsByClassName('content-area')[0].addEventListener('click', () => {
      // this.isSideBar = true
      // this.emitter.emit('setWorkExpTabActive', { isVisible: true })
    })
  }
}
</script>
<style lang="scss" scoped>
.close-btn {
  background-color: red;
}

.p-menuitem .changemenu {
  background: red;
  font-size: 60px;
}

@media (max-width: 960px) {
  .button-container {
    display: none;
    margin-top: 3rem;
  }
}

@media (min-width: 1101px) {
  .button-container1 {
    display: none;
    margin-top: 3rem;
    background: #305faf !important;
  }
}

// .button-container1 :deep{
//   .p-button{
//     background: #305faf !important;

//   }
// }
.close-btn {
  background: #0070cd;
  width: 6rem;
  font-size: 10px;
  border-radius: 4px;
  border: 1px solid #0070cd;
}
.layout-topbar {
  background: #305faf;
}
.card {
  /* background: #305faf; */
  margin-top: 10px;
  /* background: #305faf; */
  height: 10rem;
  display: flex;
  justify-content: space-around;
  align-items: baseline;
  align-items: flex-start;
}
.imagenavbar {
  width: 130px;
  /* padding: 15px */
}
.pi-sign-out {
  color: #fff;
  font-size: 18px;
}
.align-part1 {
  display: flex;
  margin-left: 5rem;
  align-items: center;
  justify-content: flex-start;
}
@media (max-width: 990px) {
  .align-part1 {
    margin-left: 10rem;
  }
}

.align-part2 {
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  margin-right: 10rem;
  flex-direction: column-reverse;
}
.designavatar {
  font-size: 14px;
}
.last-login {
  letter-spacing: 0.1px;
  // line-height: 12px;
  color: #ffffff;
  font-size: 9px;
  white-space: nowrap;
  font-family: 'Poppins', Helvetica;
  font-weight: 300;
  line-height: 20px;
  margin: -5px 0px 10px 0px;
}
.style-logout {
  display: flex;
  column-gap: 20px;
  // justify-content: space-between;
}
</style>
