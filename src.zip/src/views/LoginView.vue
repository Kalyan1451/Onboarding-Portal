<template>
  <!-- <div>
    <Menubar :model="menuItems" class="custom-header" />
  </div> -->

  <!-- <TabMenu :model="items" /> -->
  <div class="background-card">
    <Toast class="toastdesign" />
    <div :class="[invalidPassword || invalidEmail ? 'show-error-message' : null, 'total-card']">
      <!-- <h1>{{ proxyDataStore.getLogos }}</h1> -->
      <div class="language">
        <SplitButton
          class="mr-3 splitButton"
          :label="$t('selectLanguage')"
          icon="pi pi-language"
          :model="item"
        />
        <!-- Translate -->
        <!-- <select v-model="selectedLanguage" @change="changeLanguage">
          <option :value="null" disabled hidden>ln</option>
          <option value="en">English</option>
          <option value="es">Spanish</option>
        </select> -->
      </div>
      <div>
        <Card class="login-card">
          <template #content>
            <div class="flex flex-column md:flex-row">
              <div>
                <!-- <img class="login-logo" src="@/assets/innova/loginLogo.png" /> -->
                <img class="login-logo" :src="getLogoPath(logoUrl)" />
                <h2 class="welcomeText">{{ $t('welcome') }}</h2>
                <h1 class="onboardingText">{{ $t('onboardingPortal') }}</h1>
                <!-- <h1>{{ $t('onboardingPortal') }}</h1> -->
              </div>
              <div class="w-full md:w-1">
                <img
                  src="../assets/images/line-10.svg"
                  class="hidden md:flex"
                  alt=""
                  width="1.5%"
                  height="98%"
                />
                <!-- <Divider layout="vertical" type="dashed" class="hidden md:flex"></Divider> -->
                <Divider
                  layout="horizontal"
                  type="dashed"
                  class="flex md:hidden"
                  align="center"
                ></Divider>
              </div>

              <div
                v-if="!isSsoLogin"
                class="w-full md:w-8 flex flex-column align-items-center justify-content-center gap-4 py-5"
              >
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <i
                      class="pi pi-user absolute top-2/4 -mt-2 ml-2 text-surface-400 dark:text-surface-600"
                    />
                    <InputText
                      class="login-input"
                      type="email"
                      pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
                      required
                      :title="$t('fillFeild')"
                      maxlength="200"
                      v-model="emailAddress"
                      :placeholder="$t('placeholder')"
                    ></InputText>
                  </span>
                </div>
                <div class="flex flex-wrap justify-content-center align-items-center gap-2">
                  <span class="p-input-icon-left">
                    <span class="p-input-icon-right">
                      <i
                        class="pi pi-lock absolute top-2/4 -mt-2 ml-2 text-surface-400 dark:text-surface-600"
                      />
                      <i v-if="showEye" class="pi pi-eye" @click="switchVisibility"></i>
                      <i v-if="showSlash" class="pi pi-eye-slash" @click="switchVisibility"></i>
                      <InputText
                        class="login-input"
                        :type="passwordFieldType"
                        required
                        :title="$t('fillFeild')"
                        v-model="password"
                        @keyup.enter="getToken()"
                        :placeholder="$t('placeholders')"
                      />
                    </span>
                  </span>
                </div>
                <div>
                  <!-- <div class="card ml-2 mr-3 flex align-remember flex-wrap justify-content-between gap-3"> -->
                  <!-- <div class="flex items-center">
                      <Checkbox v-model="pizza" inputId="ingredient1" class="remember-check" name="pizza" value="remember me" />
                      <label  for="ingredient1" class="ml-2 mt-1 remember">{{ $t('remember') }}</label>
                  </div> -->

                  <div class="reset-pswd mb-4 mr-3" @click="OnResetPswd">
                    {{ $t('forgotpassword') }}
                  </div>
                  <!-- </div> -->
                  <div class="mr-2">
                    <Button
                      class="login-button"
                      :disabled="!emailAddress || !password"
                      :label="$t('LOGIN')"
                      @click="getToken()"
                      severity="secondary"
                    />
                  </div>
                </div>
              </div>
              <div
                v-if="isSsoLogin"
                class="w-full md:w-8 flex flex-column align-items-center justify-content-center gap-4 py-5"
              >
                <div>
                  <Button
                    class="login-button"
                    :label="$t('loginWithSSO')"
                    @click="SignIn()"
                    severity="secondary"
                  />
                </div>
              </div>
            </div>

            <!-- <b>{{ $t('oR') }}</b> -->
            <!-- <div class="icons">
                    <i class="pi pi-google" v-tooltip.bottom="'Google'"></i>
                    <i class="pi pi-facebook" v-tooltip.bottom="'Facebook'"></i>
                    <i class="pi pi-linkedin" v-tooltip.bottom="'LinkedIn'"></i>
                </div> -->
          </template>
        </Card>
        <div v-if="invalidEmail || invalidPassword" class="forgot-password-error-message">
          <Message
            severity="error"
            @close="invalidEmail = false, invalidPassword = false"
          >
            <div class="error-header">
              {{ invalidEmail ? $t('loginAlert') : $t('incorrectPassword') }}
            </div>
            <div class="error-message">
              {{ invalidEmail ? $t('invalidErrorPopUpObs') : $t('passwordAlert') }}
            </div>
          </Message>
        </div>
      </div>
    </div>
  </div>

  <!-- <Dialog
    v-model:visible="invalidEmail"
    :position="position"
    :modal="true"
    :closable="false"
    :draggable="false"
  >
    <template #header>
      <div>
        <i style="margin: 10px" class="pi pi-exclamation-triangle"></i><b>{{ $t('loginAlert') }}</b>
      </div>
    </template>
    <div class="dialogcontent">
      {{ $t('invalidErrorPopUpObs') }}
    </div>

    <template #footer>
      <Button :label="$t('close')" icon="pi pi-times" @click="goToLogin" severity="danger" />
    </template>
  </Dialog>

  <Dialog
    v-model:visible="invalidPassword"
    :position="position"
    :modal="true"
    :closable="false"
    :draggable="false"
  >
    <template #header>
      <div><i class="pi pi-exclamation-triangle"></i> {{ $t('loginAlert') }}</div>
    </template>
    <p>
      {{ $t('passwordAlert') }}
    </p>
    <template #footer>
      <Button :label="$t('close')" icon="pi pi-times" @click="goToLogin" severity="danger" />
    </template>
  </Dialog> -->

  <Dialog
    v-model:visible="raiseReq"
    :style="{ width: '35rem' }"
    :position="position"
    :modal="true"
    :closable="false"
    :draggable="false"
  >
    <template #header>
      {{ $t('incidentCreated') }}
    </template>
    <p>
      {{ $t('invalidErrorPopUpConsulatant') }}
    </p>
    <template #footer>
      <Button :label="$t('close')" icon="pi pi-times" @click="goToLogin" severity="danger" />
    </template>
  </Dialog>
  <Dialog
    v-model:visible="userSsoActive"
    :style="{ width: '35rem' }"
    :position="position"
    :modal="true"
    :closable="false"
    :draggable="false"
  >
    <template #header>
      <div><i class="pi pi-exclamation-triangle"></i> {{ $t('loginAlert') }}</div>
    </template>
    <p>
      {{ $t('autorizationAlert') }}
      <!-- The entered email address is not registered. Please contact your Onboarding Specialist. -->
    </p>
    <template #footer>
      <Button label="Close" icon="pi pi-times" @click="closeErrorDialog" severity="danger" />
    </template>
  </Dialog>
  <!-- <Dialog
    v-model:visible="resetPassword"
    :modal="true"
    :draggable="false"
    class="reset-dialog"
    :closable="false"
  >
    <template #header>
      <span
        ><i class="pi pi-exclamation-triangle" />
        Reset Password
      </span>
    </template>
    <div>
      <span class="p-input-icon-left">
        <i class="pi pi-user absolute top-2/4 -mt-2 ml-2 text-surface-400 dark:text-surface-600" />
        <InputText
          class="reset-input"
          type="email"
          pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"
          required
          :title="$t('fillFeild')"
          maxlength="200"
          v-model="resetEmailAddress"
          :placeholder="$t('placeholder')"
        />
      </span>
    </div>
    <template #footer>
      <Button :label="$t('sendresetlink')" @click="sendresetLink" :disabled="!resetEmailAddress" />
      <Button
        :label="$t('close')"
        icon="pi pi-times"
        @click="closePopup"
        severity="danger"
        class="close-btn"
      />
    </template>
  </Dialog> -->

  <div class="progress-spinner" v-if="showSpinner">
    <ProgressSpinner style="width: 50px; height: 50px"></ProgressSpinner>
  </div>
</template>
<script lang="ts">
import axios from 'axios'
import OnbService from '../shared/services/OnbService'
// import { msalInstance } from '@/msalInstance';
// import { PublicClientApplication, type Configuration } from '@azure/msal-browser';
import { msalInstance, proxyUrl } from '../msalConfig'
import SplitButton from 'primevue/splitbutton'
import { useToast } from 'primevue/usetoast'
import { LOCAL_STORAGE_VARIABLES } from '../shared/constant/local-storage-variables'
import { FILE_PATH } from '../shared/constant/file-path'
import { CONSULTANT_CONST_INFO } from '../shared/constant/consultant_const_info'
import { useProxyDataStore } from '@/stores/proxy-data'
import { computed, ref } from 'vue'
import { useCounterStore } from '@/stores/counter'
const storeEmail = useCounterStore()
export default {
  setup() {
    const proxyDataStore: any = useProxyDataStore()
    const loginLogo = ref(null)
    // logUrls.value = proxyDataStore.getLogos;
    // loginLogo.value = logUrls.value.filter((el: any) => el.imageName == 'loginLogo');
    // logUrls = proxyDataStore.logoUrls;
    // console.log("loginLogo", loginLogo.value);
    // console.log("getLogos", logUrls);
    const logoUrl = computed(() => proxyDataStore.$state.loginLogo)
    return {
      proxyDataStore,
      logoUrl,
      loginLogo
    }
  },
  data() {
    return {
      passwordFieldType: 'password',
      firstLogin: '',
      showEye: false,
      showSlash: true,
      currentTheme: 'soho-light',
      account: {},
      uId: null,
      welcomeBack: false,
      showSpinner: false,
      isLoginRoute: true,
      isInnovaRoute: true,
      invalidEmail: false,
      invalidPassword: false,
      selectedLanguage: '',
      resetPassword: false,
      resetEmailAddress: '',
      raiseReq: false,
      userSsoActive: false,
      registeredEmail: '',
      toast: useToast(),
      position: 'top' as 'top',
      password: '',
      showPassword: false,
      showPasswordIcon: false,
      isLoginWithCandidate: false,
      emailAddress: '',
      requestPayload: {},
      loginTab: 'consultant',
      lastLogindetails: '',
      lastLogindetailsObs: '',
      isSsoLogin: false,
      displayedUserName: '',
      userName: '',
      percentageValue: 0,

      item: [
        {
          label: 'English',
          command: ($event: any) => {
            this.changeLanguage('en')
          }
        },
        {
          label: 'Spanish (español) ',
          command: ($event: any) => {
            this.changeLanguage('sp')
          }
        },
        {
          label: 'Francais (French)',
          command: ($event: any) => {
            this.changeLanguage('fr')
          }
        }
      ],

      menuItems: [
        {
          label: 'Theme',
          items: [
            {
              label: 'soho-light',
              id: 'theme-link',
              command: () => {
                this.changetheme(0)
              }
            },
            {
              label: 'soho-dark',
              id: 'theme-link',
              command: () => {
                this.changetheme(1)
              }
            }
          ]
        }
      ],
      items: [
        {
          label: this.$t('consultant'),
          command: () => {
            this.isLoginRoute = true
            this.isInnovaRoute = false
          }
        },
        {
          label: this.$t('innova'),
          command: () => {
            this.isLoginRoute = false
            this.isInnovaRoute = true
          }
        }
      ]
    }
  },
  mounted() {
    // const proxyDataStore: any = useProxyDataStore();
    // console.log("proxyDataStore", proxyDataStore.getLogos)
    const loginType = this.$route.query.userType
    if (loginType == 'innovaTeam') {
      this.isSsoLogin = true
    } else {
      this.isSsoLogin = false
    }
    console.log('Mounted', this.$route.query.userType)
  },
  methods: {
    switchVisibility() {
      this.passwordFieldType = this.passwordFieldType === 'password' ? 'text' : 'password'
      if (this.passwordFieldType === 'password') {
        this.showSlash = true
        this.showEye = false
      } else {
        this.showEye = true
        this.showSlash = false
      }
    },
    // changes the theme into dark mode & light mode.
    changetheme(themeIndex: any) {
      console.log(this.themeItems[0].items)
      console.log('changetheme')
      let newTheme = this.themeItems[0].items[themeIndex]
      this.$primevue.changeTheme(this.currentTheme, newTheme.label, 'theme-link', () => {})
      this.currentTheme = newTheme.label
      console.log(this.currentTheme)
    },
    showUserList() {
      this.themeItems = this.themeItems.filter((key) => {
        return key.label != 'Theme'
      })
    },
    showpasswordIcon() {
      this.showPasswordIcon = true
    },
    togglePasswordVisibility() {
      this.showPassword = !this.showPassword
    },
    validate() {
      if (this.uId) {
        sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_ID, this.uId) //sessionStorage.setItem('loggedInUserId'
        this.$router.push(FILE_PATH.ONB_SPL) // '/onb/onb-spl'
      } else {
        this.userSsoActive = true
        this.$router.push(FILE_PATH.LOGIN) // '/login'
      }
    },
    closeErrorDialog() {
      this.userSsoActive = false
    },

    // The service validates the Obs specialist details.
    getEmployeId(mail: any) {
      let payload = {
        email: mail
      }
      OnbService.getOnbSpecialistUserId(payload)
        .then((response) => {
          this.uId = response?.data?.data?.employeeId
          this.lastLogindetailsObs = response?.data?.data?.loginTime
          sessionStorage.setItem(
            LOCAL_STORAGE_VARIABLES.OBS_LAST_LOGIN_DETAILS,
            JSON.stringify(this.lastLogindetailsObs)
          ) //sessionStorage.setItem('lastLogindetailsObs'
          this.account.employeId = this.uId
          this.account.employeeId = this.uId
          sessionStorage.removeItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS) //sessionStorage.removeItem('userDetails')
          sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS, JSON.stringify(this.account)) //sessionStorage.removeItem('userDetails')
          sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME, this.account.name) //sessionStorage.setItem('loggedInUserName'
          this.validate()
        })
        .finally(() => {
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          console.error(error)
          this.showSpinner = false
        })
    },

    // async login() {
    //   try {
    //     const response = await msalInstance.loginPopup()
    //     console.log('Login Response:', response)
    //   } catch (error) {
    //     console.error('Login Error:', error)
    //   }
    // },

    // getTokenForBackendApi(){
    //     const reqObj: any = requestObjForApi;
    //     msalInstance ?.acquireTokenPopup(reqObj).then((res)=> {
    //         sessionStorage.setItem('jwtToken', res.accessToken);
    //     })
    // },

    async SignIn() {
      // await msalInstance.initialize();
      await msalInstance
        .loginPopup()
        .then(() => {
          const myAccounts = msalInstance.getAllAccounts()
          this.account = myAccounts[0]
          this.account.userRole = CONSULTANT_CONST_INFO.INNOVATEAM_ROLE //'InnovaTeam'
          sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.JWT_TOKEN, this.account.idToken) //sessionStorage.setItem('jwtToken'
          sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.USER_DETAILS, JSON.stringify(this.account)) //sessionStorage.setItem('userDetails'
          this.getEventTrackerDetails()
        })
        .catch((error) => {
          console.error(`error during authentication: ${error}`)
        })
    },
    async SignOut() {
      await msalInstance
        .logout({})
        .then(() => {})
        .catch((error) => {
          console.error(error)
        })
    },
    swithToTab(tabName: any) {
      this.loginTab = tabName
    },

    changeLanguage(event: any) {
      console.log('event-change', event)
      this.$i18n.locale = event
      sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.SELECTED_LANGUAGE, event) //'selectedLanguage'
    },

    //The method brings the login screen after the Alert pop ups are closed
    goToLogin() {
      this.invalidEmail = false
      this.invalidPassword = false
      this.raiseReq = false
      this.password = ''
      this.$router.push(FILE_PATH.LOGIN) //'/login'
    },

    //The service captures user last login details.
    getEventTrackerDetails() {
      OnbService.getTrackerList()
        .then((res: any) => {
          if (!res['errorCode']) {
            sessionStorage.setItem(
              LOCAL_STORAGE_VARIABLES.APPTRACKDATA,
              JSON.stringify(res.data['List'])
            ) //sessionStorage.setItem('AppTrackData'
          }
        })
        .finally(() => {
          if (this.isLoginWithCandidate) {
            this.loginWithPassword()
          } else {
            this.getEmployeId(this.account.username)
          }
        })
    },

    //To get JWT token.
    async getToken() {
      const reqUrl = proxyUrl + '/jwttoken/' + this.emailAddress
      axios.get(reqUrl).then((res: any) => {
        this.isLoginWithCandidate = true
        sessionStorage.setItem(LOCAL_STORAGE_VARIABLES.JWT_TOKEN, res.data.access_token)
        this.getEventTrackerDetails()
      })
    },

    // The service is validating the Candidate details.
    async loginWithPassword() {
      this.showSpinner = true

      console.log('mskaslkslka', this.percentageValue)
      let payload = {
        emailId: this.emailAddress,
        password: this.password
      }
      this.requestPayload = payload
      //let url = 'https://ol-npsitonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/candidate/login';
      OnbService.login(payload)
        .then((response: any) => {
          if (response?.data?.message == 'User not exist') {
            this.invalidPassword = false
            this.invalidEmail = true
            //   this.toast.add({
            //   severity: 'error',
            //   summary: this.$t('invalidErrorPopUpObs'),
            //   // detail: this.$t('successMessages.sendresetlinks'),
            //   life: 3000
            // })
          }
          if (response?.data?.message == 'Password Not Match') {
            this.invalidEmail = false
            this.invalidPassword = true
            //   this.toast.add({
            //   severity: 'error',
            //   summary: this.$t('passwordAlert'),
            //   // detail: this.$t('successMessages.sendresetlinks'),
            //   life: 3000
            // })
          }
          if (response?.data?.data && response?.data?.message == 'Login Success') {
            this.lastLogindetails = response?.data?.data?.lastLoginDetails?.loginTime
            console.log('this.lastLogindetails', this.lastLogindetails)
            this.firstLogin = response?.data?.data?.user?.firstLogin
            if (this.firstLogin == 'Y') {
              let email = this.emailAddress
              storeEmail.email = email
              this.$router.push({ path: '/change-password/' + 'reset' })
            } else {
              this.account = response.data.data
              this.account.userRole = CONSULTANT_CONST_INFO.CONSULTANT_ROLE //'Consultant'
              this.account.lastLoginDetails = this.lastLogindetails
              sessionStorage.setItem(
                LOCAL_STORAGE_VARIABLES.USER_DETAILS,
                JSON.stringify(this.account)
              ) //sessionStorage.setItem('userDetails'
              const loggedInUserName =
                response.data.data.firstName + ' ' + response.data.data.lastName
              const maxUsernameLength = 30
              this.displayedUsername =
                loggedInUserName.length > maxUsernameLength
                  ? loggedInUserName.substring(0, maxUsernameLength) + '...'
                  : loggedInUserName

              sessionStorage.setItem(
                LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME,
                this.displayedUsername
              )
              const userDetails: any = JSON.parse(sessionStorage.getItem('userDetails') || '{}')
              this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
              this.empId = userDetails.employeeId
            }
            OnbService.getDashboardData(this.empId).then((res: any) => {
              this.percentageValue = res?.data?.data?.progress
            })
            // if(this.percentageValue ==0){
            //   this.$router.push('/onb/welcome-item')
            // }
            // else{
            //   this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
            // }
            //sessionStorage.setItem('loggedInUserName'
            //this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD) //'/onb/consultant-dashboard'
            // this.$router.push('/welcome-item')
          }
        })
        .finally(() => {
          // if(!this.lastLogindetails){
          //   let email=this.emailAddress
          //   storeEmail.email=email
          //   this.$router.push({ path:'/change-password/'+123 })
          //     // this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
          // }
          // else if(this.percentageValue ==0){
          //   this.$router.push('/onb/welcome-item')
          // }
          // else{
          // this.$router.push(FILE_PATH.CONSULTANT_DASHBOARD)
          // }

          // this.$router.push('/onb/welcome-item')
          setTimeout(() => {
            this.showSpinner = false
          }, 1000)
        })
        .catch((error) => {
          this.invalidEmail = true
          this.showSpinner = false
          console.error('There was an error!', error)
        })
      this.userName = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.LOGGED_IN_USER_NAME)
    },

    // The service tracks the last login details of the candidate, For first time login users, the raiseReq is updated.
    raiseRequest() {
      //let url = 'https://ol-npqaonboardingsvcsftr.innovasolutions.com:42000/onboarding/v1/candidate/login';
      OnbService.login(this.requestPayload).then((response: any) => {
        if (response.data.message == 'User not exist') {
          this.raiseReq = true
        }
      })
    },

    // To Reset password by the Candidate.
    OnResetPswd() {
      // this.resetPassword = true
      this.$router.push('/forgot-password')
    },
    sendresetLink() {
      this.resetPassword = false
      OnbService.getResetPasswordLink(this.resetEmailAddress).then((res: any) => {
        if (res.data.data == 'User is not registered in Employee table') {
          this.toast.add({
            severity: 'error',
            summary: this.$t('ErrorMessages.error'),
            detail: this.$t('ErrorMessages.userNotRegister'),
            life: 3000
          })
        } else {
          this.toast.add({
            severity: 'success',
            summary: this.$t('successMessages.success'),
            detail: this.$t('successMessages.sendresetlinks'),
            life: 3000
          })
        }
      })
      this.resetEmailAddress = ''
    },
    closePopup() {
      this.resetPassword = false
      this.resetEmailAddress = ''
    },
    getLogoPath(img: string): string {
      const defaultLogoUrl: string = '/innova/loginLogo.png'
      // img = defaultLogoUrl
      img = img ? img : defaultLogoUrl
      return img ? new URL(img, import.meta.url).href : ''
    }
  },
  created() {
    const storedLanguage = sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.SELECTED_LANGUAGE) //sessionStorage.getItem('selectedLanguage')
    this.selectedLanguage = storedLanguage || 'en'
    const routeInnovaTeam = JSON.parse(
      sessionStorage.getItem(LOCAL_STORAGE_VARIABLES.ROUTE_INNOVA_TEAM)
    ) //sessionStorage.getItem('routeInnovaTeam')
    if (routeInnovaTeam) {
      this.isLoginRoute = false
      this.isInnovaRoute = true
      this.swithToTab(CONSULTANT_CONST_INFO.INNOVATEAM_ROLE) //'InnovaTeam'
    }
  }
}
</script>

<style scoped lang="scss">
/* .p-dialog .p-dialog-header {
    border-bottom: 0 none;
    background: #ffffff;
    color: #495057;
    padding: 5px !important;
} */
/* .p-splitbutton{
  background:#fffffff2;
  color:red;
} */
.progress-spinner {
  position: fixed;
  z-index: 999;
  height: 2em;
  width: 2em;
  overflow: show;
  margin: auto;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
.myProfile {
  font-family: 'Poppins', Helvetica;
  font-weight: 300;
  color: #000000;
  font-size: 22px;
  letter-spacing: 0.26px;
  line-height: 40px;
  white-space: nowrap;
}

/* Transparent Overlay */
.progress-spinner:before {
  content: '';
  display: block;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.53);
}

/* .p-inputtext.login-input {
  padding: 0;
  margin-left: 10px;
} */
.heading_stepper {
  display: flex;
  align-items: center;
}
.circle {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border: 1px solid #0070cd;
  margin-right: 24px;
}
.circle img {
  margin: 8px 4px;
}
.total-card {
  margin: 20px 65px;
}
.middle_section {
  display: flex;
  flex-direction: row;
}
.vertical_line {
  display: flex;
  margin: 4px 0 4px 13px;
}
.vertical_line2 {
  display: flex;
  margin: 4px 0 4px 16px;
  /* border:1px solid gray */
}
.message_box {
  width: 112px;
  height: 64px;
  background-color: #0070cd;
  border-radius: 20px;
  color: #fff;
  text-align: center;
  align-items: center;
  padding: 10px;
}
.success_line {
  display: flex;
  flex-direction: column;
  margin-left: -6px;
}
.dark_circle {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #0070cd;
}
.loginsso {
  width: 235px;
  margin-top: 2rem;
}
.rectangle {
  width: 65px;
  position: absolute;
  top: 0px;
  height: 140px;
  background: #0070cd;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
}
.vertical-stepper {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.custom-steps {
  flex-direction: row;
}

/* .language {
  position: absolute;
  top: -13px;
  left:600px;
    margin-top: 15px;
} */

.reset-button {
  border: none;
  width: 50%;
  height: 30%;
}
.p-inputtext.reset-input {
  border-bottom: solid 2px #ced4da;
  width: 275px;
}
.pi-user {
  color: #180583;
}
.pi-lock {
  color: #180583;
}
/* .p-checkbox{
.
  width: 10px !important;
  height: 10px !important;
  border-radius: 3px;
} */

::placeholder {
  color: #144698;
  font-size: 14px;
  font-weight: 500;
}

a {
  color: #2096cd;
  text-decoration: underline;
}
.p-button.splitbutton {
  background: red;
}
.icons {
  display: flex;
  justify-content: center;
  column-gap: 40px;
  text-align: center;
}
.p-card .p-card-content {
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 1rem;
}
.icons i {
  font-size: 30px;
}
.close-btn {
  background-color: red;
  border: red;
}
.p-card .p-card-body {
  padding: 2.2rem;
  border-radius: 20px;
  box-shadow: 0px 9px 30px 5px #00000026;
}

.p-invalid {
  color: red;
}

.dialogcontent {
  font-size: 14px;
}
.pi-eye {
  color: #180583;
}
.pi-eye-slash {
  color: #180583;
}

.forgot-password-error-message {
  margin: 0 10px;

  .error-header {
    display: flex;
    justify-content: center;
    margin-bottom: 15px;
    font-weight: 600;
    color: #cd0000;
    letter-spacing: 0.2px;
  }

  .error-message {
    display: flex;
    justify-content: center;
    color: black;
    margin-bottom: 1.75rem;
    font-size: 16px;
  }
}

.forgot-password-error-message :deep {
  .p-message.p-message-error .p-message-close {
    color: #000000;
    margin-top: 30px;
    margin-right: 10px;
    height: 15px;
    width: 15px;
  }

  .p-message .p-message-text {
    width: 100%;
  }

  .p-message {
    margin: 0;
    border-radius: 0 0 20px 20px;
  }
  .p-message .p-message-wrapper {
    height: auto;
    width: 100%;
    padding-right: 0.1rem;
    padding-bottom: 0.1rem;
    background-color: #fbcece;
    border-radius: 0 0 20px 20px;
  }
  .p-message .p-icon:not(.p-message-close-icon) {
    display: none;
  }

  .p-message.p-message-error {
    border: none;
  }
}
.show-error-message :deep {
  .p-card {
    border-radius: 20px 20px 0 0;
    margin-bottom: 0px;
  }
}
</style>
