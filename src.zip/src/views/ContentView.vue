<template>
  <div class="menuu">
    <NavBar v-if="!this.$route.path.includes('/onb/welcome-item')" />
    <div class="second-cont">
      <div class="sidebar-content">
        <SideBar
          v-if="
            !this.$route.path.includes('/onb/welcome-item') &&
            !this.$route.path.includes('/onb/my-profile-data')
          "
          :isSidebarVisible="isSidebarVisible"
          @closeSideBar="closeSideBar"
          @personalInfo="showPersonalinformation"
          @preview="showPreviewDetails"
          @verifyInfomation="verifyInfomation"
        />
      </div>

      <div
        class="content-area"
        v-if="
          !this.$route.path.includes('/onb/my-profile-data') &&
          !this.$route.path.includes('/onb/welcome-item') &&
          !this.$route.path.includes('/onb/onb-spl')
        "
      >
        <Card class="customclass">
          <template #content>
            <div class="container">
              <RouterView />
            </div>
          </template>
        </Card>

        <!-- <div class="container">
          <RouterView />
      <div class=""><RouterView /></div>
    </div> 
      <div class="background"><RouterView /></div> -->
      </div>
      <div class="content-area" v-if="this.$route.path.includes('/onb/onb-spl')">
        <Card class="onbcustomclass">
          <template #content>
            <div class="container">
              <RouterView />
            </div>
          </template>
        </Card>
      </div>
    </div>

    <div class="content-area" v-if="this.$route.path.includes('/onb/my-profile-data')">
      <RouterView />
    </div>

    <div v-if="this.$route.path.includes('/onb/welcome-item')">
      <RouterView />
    </div>
  </div>
</template>

<script lang="ts">
import { FILE_PATH } from '../shared/constant/file-path'
import NavBar from '../views/Layout/NavBar.vue'
import SideBar from '../views/Layout/SideBar.vue'
//import SideBar from '../../src/views/Layout/SideBar.vue';
//import NavBar from '../../src/views/Layout/NavBar.vue';

export default {
  components: {
    NavBar,
    SideBar
  },
  data() {
    return {
      isSidebarVisible: false
    }
  },
  methods: {
    closeSideBar() {
      this.isSidebarVisible = false
    },
    showPersonalinformation() {
      this.$router.push(FILE_PATH.MY_PROFILE) // '/onb/my-profile'
      this.emitter.emit('personal-info', { eventContent: 'personal-info' })
    },
    showPreviewDetails() {
      this.$router.push(FILE_PATH.MY_PROFILE) //'/onb/my-profile'
      this.emitter.emit('preview', { value: 'preview' })
    },
    verifyInfomation() {
      this.$router.push(FILE_PATH.INITIATE_INFO) //'/onb/initiate-info'
    }
  },
  created() {
    this.emitter.on('setWorkExpTabActive', ({ isVisible }) => {
      this.isSidebarVisible = isVisible
    })
  }
}
</script>
<style>
@media (max-width: 1100px) {
  .menuu {
    overflow-x: hidden;
  }
}
.menuu {
  display: flex;
  flex-direction: column;
  background: #eeedf3;
  height: 100vh;
  overflow-x: hidden;
}

/* box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  width: 60vw;
  height: 80vh;
  display: flex;
  overflow: hidden;
  margin: 2rem 2rem 2rem 1rem;
  border-radius: 20px;
  padding: 1.5rem; */

.button-container {
  background-color: #2096cd;
  width: 10px;
  margin-left: -5px;
  margin-right: 12px;
}
.button-container1 {
  background-color: #2096cd;
  width: 10px;
  margin-left: -5px;
  margin-right: 12px;
}
.cardview {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
}
@media (max-width: 1100px) {
  .sidebar-content {
    background: #305faf;
  }
}
/* Add some padding inside the card container */
.container {
}
.customclass {
  background: #fff;
  width: 68vw;
  max-height: 80vh;
  min-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}
.onbcustomclass {
  background: #eeedf3;
  width: 68vw;
  max-height: 80vh;
  min-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
}

.customclass::-webkit-scrollbar {
  width: 0em;
}

.customclass::-webkit-scrollbar-thumb {
  background-color: transparent; /* Set the thumb color to transparent */
}

.customclass::-webkit-scrollbar-track {
  background-color: transparent; /* Set the track color to transparent */
}

.second-cont {
  margin: -5rem 1rem 1rem 1rem;
  display: flex;
  justify-content: space-evenly;
}
/* ---------------scrollbar============== */
::-webkit-scrollbar {
  width: 2px;
}

::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px grey;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb {
  background: #305faf;
  border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: #305faf;
}

@media (max-width: 1100px) {
  .second-cont {
    display: flex;
    justify-content: center;
  }
  .customclass {
    width: 100vw;
    margin: 0px;
  }
  .onbcustomclass {
    width: 100vw;
    margin: 0px;
  }
}
@media (max-width: 480px) {
  .customclass {
    width: 100vw;
    margin: 0px;
    /* height: 99vh; */
  }
  .onbcustomclass {
    width: 100vw;
    margin: 0px;
    /* height: 99vh; */
  }
}
</style>
